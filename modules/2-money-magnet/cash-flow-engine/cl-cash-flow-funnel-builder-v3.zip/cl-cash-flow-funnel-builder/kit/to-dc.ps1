# PowerShell port of v2/scripts/to_dc.py for the demo pages in Funnel-templates (7 kits embedded + demo bar).
# Keeps the Ember kit (the board's sample look) + the page CSS, drops the other kits, the demo bar and every script.
param([string]$Src, [string]$Out, [string]$Title, [int]$W, [int]$H)
$doc = [IO.File]::ReadAllText($Src)
$kit = [regex]::Match($doc, '(?s)<style class="cfe-kit" data-kit="ember">(.*?)</style>').Groups[1].Value
$main = ''
foreach ($m in [regex]::Matches($doc, '(?s)<style>(.*?)</style>')) { if ($m.Groups[1].Value -notmatch '#cfe-demo') { $main += $m.Groups[1].Value + "`n" } }
if (-not $main) { throw "styles not found in $Src" }   # a client build has its kit inside the one page style; a demo page has 7 kits + the page style
$css = $kit + "`n" + $main
$fonts = [regex]::Matches($css, '@import url\("([^"]+)"\);') | ForEach-Object { $_.Groups[1].Value } | Select-Object -Unique
$css = [regex]::Replace($css, '@import url\([^)]*\);', '')
$body = [regex]::Match($doc, '(?s)<body[^>]*>(.*)</body>').Groups[1].Value
$body = [regex]::Replace($body, '(?s)<script\b.*?</script>', '')
$body = [regex]::Replace($body, '(?s)<!--.*?-->', '')
$body = [regex]::Replace($body, '(?s)<div id="cfe-demo".*?</div>', '')
$body = [regex]::Replace($body, '(?s)<style>#cfe-demo.*?</style>', '')
$links = ($fonts | ForEach-Object { '<link rel="stylesheet" href="' + [Net.WebUtility]::HtmlEncode($_) + '">' }) -join "`n"
$t = [Net.WebUtility]::HtmlEncode($Title)
$dc = @"
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>$t</title>
<script src="./support.js"></script>
</head>
<body>
<x-dc>
<helmet>
$links
<style>
body{margin:0}
$css
</style>
</helmet>
<div class="cfe-page" style="width: 100%; min-height: 100%;">
$body
</div>
</x-dc>
<script type="text/x-dc" data-dc-script data-props='{"`$preview":{"width":$W,"height":$H}}'>
class Component extends DCLogic {
renderVals() { return {}; }
}
</script>
</body>
</html>
"@
[IO.File]::WriteAllText($Out, $dc, [Text.UTF8Encoding]::new($false))
"{0}  {1:N0} bytes" -f (Split-Path $Out -Leaf), (Get-Item $Out).Length
