/* Cash Flow Engine™ funnel behaviour — popup + countdowns. No dependencies.
   Popup:     <a href="#register" data-open="register">  +  <div class="cl-modal" id="register" hidden>
   Countdown: <div class="cl-countdown" data-deadline="2026-11-12T09:00:00+11:00">   (fixed date)
              <div class="cl-countdown" data-evergreen="15">                         (minutes, per visitor)
              Units inside: <span class="cl-countdown__n" data-u="d|h|m|s"> */
(function () {
  document.addEventListener('click', function (e) {
    var o = e.target.closest('[data-open]');
    if (o) { var m = document.getElementById(o.getAttribute('data-open')); if (m) { e.preventDefault(); m.hidden = false; var f = m.querySelector('input'); if (f) f.focus(); } return; }
    var c = e.target.closest('[data-close]');
    if (c || e.target.classList.contains('cl-modal')) { var mm = e.target.closest('.cl-modal'); if (mm) mm.hidden = true; }
  });
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape') document.querySelectorAll('.cl-modal').forEach(function (m) { m.hidden = true; }); });

  /* mobile sticky CTA: on once the hero button has scrolled away */
  var bar = document.querySelector('.cl-stickycta'), heroCta = document.querySelector('[data-cfe-cta=hero]');
  if (bar && heroCta && 'IntersectionObserver' in window) {
    new IntersectionObserver(function (en) {
      var past = !en[0].isIntersecting && en[0].boundingClientRect.top < 0;
      bar.classList.toggle('is-on', past); bar.setAttribute('aria-hidden', past ? 'false' : 'true');
      var a = bar.querySelector('a'); if (a) a.tabIndex = past ? 0 : -1;
    }).observe(heroCta);
  }

  /* exit intent (desktop): once per visitor, never after the registration popup has opened */
  var exit = document.getElementById('exit'), seen = false;
  function store(k, v) { try { if (v === undefined) return sessionStorage.getItem(k); sessionStorage.setItem(k, v); } catch (x) {} }
  document.addEventListener('click', function (e) { if (e.target.closest('[data-open=register], a[href="#checkout"]')) { store('cfe-reg', '1'); if (exit) exit.hidden = true; } });
  if (exit && window.matchMedia('(pointer: fine) and (min-width: 900px)').matches) {
    document.addEventListener('mouseout', function (e) {
      if (seen || e.relatedTarget || e.clientY > 10) return;
      if (store('cfe-reg') || store('cfe-exit')) return;
      if (document.querySelector('.cl-modal:not([hidden])')) return;
      seen = true; store('cfe-exit', '1'); exit.hidden = false;
    });
  }

  var timers = document.querySelectorAll('.cl-countdown[data-deadline], .cl-countdown[data-evergreen]');
  timers.forEach(function (t, i) {
    var end;
    if (t.dataset.deadline) end = Date.parse(t.dataset.deadline);
    else {
      var mins = +t.dataset.evergreen, key = 'cfe-eg-' + location.pathname + '-' + mins;   /* every timer on the page shares one deadline */
      try { end = +localStorage.getItem(key); } catch (x) {}
      if (!end || end < Date.now() - 864e5) { end = Date.now() + mins * 6e4; try { localStorage.setItem(key, end); } catch (x) {} }
    }
    if (isNaN(end)) return;
    function tick() {
      var s = Math.max(0, Math.floor((end - Date.now()) / 1000)), v = { d: Math.floor(s / 86400), h: Math.floor(s % 86400 / 3600), m: Math.floor(s % 3600 / 60), s: s % 60 };
      t.querySelectorAll('[data-u]').forEach(function (n) { n.textContent = String(v[n.dataset.u]).padStart(2, '0'); });
    }
    tick(); setInterval(tick, 1000);
  });
})();
