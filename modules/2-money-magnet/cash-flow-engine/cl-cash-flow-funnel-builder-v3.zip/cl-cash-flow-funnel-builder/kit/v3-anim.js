/* CFE V3 · v3-anim.js — the page's only animation script (sections fade up, panels play once, in view).
   No script = everything shows finished, so a page builder that strips scripts loses nothing but the motion. */
(function () {
  var d = document.documentElement;
  if (!('IntersectionObserver' in window) || matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  var els = [].slice.call(document.querySelectorAll('.cfe-v3 .cl-section:not(.cl-hero) > .cl-container > *, .v3-anim'));
  if (!els.length) return;
  d.classList.add('v3-js');
  var io = new IntersectionObserver(function (es) {
    es.forEach(function (e) { if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); } });
  }, { threshold: 0, rootMargin: '0px 0px -12% 0px' });
  els.forEach(function (e) { io.observe(e); });
  setTimeout(function () { els.forEach(function (e) { e.classList.add('in'); }); }, 20000); /* failsafe */
})();
