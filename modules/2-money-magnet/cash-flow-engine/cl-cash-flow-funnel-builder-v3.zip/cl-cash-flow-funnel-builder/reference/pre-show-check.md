# The pre-show check — run it on every page before the operator sees it

Every finding is a **question for the operator**, never a silent fix. List them in the build report; fix only what the
client's own files settle.

## A · The facts agree (V2's consistency checks, written out)

1. **Length** — every mention of the event's length matches `DURATION` ("4-hour", "90 minutes"). A session length in
   an agenda, or a promise like "within 24 hours", is fine.
2. **Event type** — the page never calls the event two things (workshop vs masterclass vs challenge vs webinar). Never
   the word "webinar" at all.
3. **Date** — `EVENT_DATE`'s weekday matches `EVENT_START_ISO`; written short (`Thu 12 Nov`); `EVENT_TIME` is the START
   time only with its zone (`10am AEDT`), never a from–to range. `*_ISO` slots are full ISO with offset.
4. **Recording (free pages)** — a free page never promises a recording or replay to keep (that's VIP), and never says
   "no replay" (a timed replay goes out — say "live only").
5. **Stack maths** — `TOTAL_VALUE` = the sum of `STACK_n_VALUE`; `VIP_TOTAL_VALUE` = the five VIP values (minus any
   switched off); `OFFER_TOTAL_VALUE` = the offer items + deposit bonus; deposit + balance = `OFFER_PRICE`.
6. **Headlines** — a hero headline stays within 3 lines on desktop (about 120 characters, fixed words included).
   `HERO_HOOK` fits the hero picture in 2–3 lines.
7. **Names** — every coined name is written the same way everywhere (™ / ® / none, spelling).
8. **One ticket price** — no early-bird, "price goes up", or second price anywhere (decision 9).
9. **No upsell countdowns** — no "offer expires / closes in" timer on any upsell page (decision 12). The event
   countdown (to the real start time) stays on registration and confirmations.
10. **Promises are results** — every headline and big promise states the result, never the pain (decision 10).

## B · Nothing invented

No price, value, number, testimonial, result, credential, guarantee or scarcity that isn't in the client's files.
No "sample" testimonial. Founder figures for Coach Launch only as CLAUDE.md allows them. Gaps show
`[CLIENT TO SUPPLY: SLOT]` and are on the report.

## C · The no-example-left scan (the build fails until it's clean)

Search every page's text AND its attributes, image sources and alt text for anything from an example:

- **Names**: Dana, Dana Cole, Holly, Holly Baskin, Erin, Ember, Sample Clinic, Sample Clinic Growth Co., Full Calendar,
  "patients" / "clinic" (unless the client is a clinic) — and Coach Launch, Matthew, Sarah, Sniper Close™, Roadmap
  (unless the client IS Coach Launch).
- **Photos / files**: `host-avatar-62ef0fe9`, `host-action-2bf1bda7`, `party-face-*` (allowed ONLY in the VIP Party
  mockup), `holly-*`, `matthew-*`, `/_blob/…` ids copied from another board, `demo-photos`.
- **Leftovers**: `{{` (other than `{{contact.…}}`), `@note`, `@panel`, `@product-shot`, `data-cfe-entry`,
  `data-cfe-unless`, `v3-slot` on a filled image, `CLIENT-TO-SUPPLY` in a link the client has given.

## D · Look at it

Open the registration page, the VIP page and the close in a browser (1280 wide and phone width):
- the hero reads at a glance, the photo face is in frame, the tool is the client's real image;
- paid: the video sits full width under the headline; free: no video anywhere on page 1;
- the panels and product shot are the client's own words; every icon matches its row;
- upsell pages: nothing above the video but the header and one headline; one-click (paid) or cart (free VIP);
- no broken layout, no empty grey box that has a file waiting for it.
