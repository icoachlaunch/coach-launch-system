| Slot | Pages |
|---|---|
| `AFTER_1` | registration |
| `AFTER_2` | registration |
| `AFTER_3` | registration |
| `AFTER_4` | registration |
| `APPLICATION_FRAME` | application |
| `ATTENDEE_1` | replay |
| `ATTENDEE_1_NAME` | replay |
| `ATTENDEE_1_SOURCE` | replay |
| `ATTENDEE_2` | replay |
| `ATTENDEE_2_NAME` | replay |
| `ATTENDEE_2_SOURCE` | replay |
| `ATTENDEE_3` | replay |
| `ATTENDEE_3_NAME` | replay |
| `ATTENDEE_3_SOURCE` | replay |
| `AUDIENCE_QUALIFIER` | registration |
| `AUTHORITY_MARKER_1` | registration |
| `AUTHORITY_MARKER_2` | registration |
| `AUTHORITY_MARKER_3` | registration |
| `AVATAR` | application · deposit · membership · pass-close |
| `BALANCE_AMOUNT` | deposit |
| `BALANCE_TERMS` | deposit |
| `BALANCE_TERMS_SHORT` | deposit |
| `BEFORE_1` | registration |
| `BEFORE_2` | registration |
| `BEFORE_3` | registration |
| `BEFORE_4` | registration |
| `BIG_PROMISE` | registration |
| `CALENDAR_REASON` | ask-campaign · seat-confirmed · thank-you · vip-confirmation |
| `CALENDAR_URL` | ask-campaign · seat-confirmed · thank-you · vip-confirmation |
| `CALL_FILTER_LINE` | application |
| `CALL_LENGTH` | application |
| `CALL_NAME` | application |
| `CALL_PLATFORM` | application |
| `CALL_QUALIFY_1` | application |
| `CALL_QUALIFY_2` | application |
| `CALL_QUALIFY_3` | application |
| `CALL_SLOT_REASON` | application |
| `CALL_SLOTS` | application |
| `CALL_TESTIMONIAL_1` | application |
| `CALL_TESTIMONIAL_1_NAME` | application |
| `CALL_TESTIMONIAL_1_SOURCE` | application |
| `CALL_TESTIMONIAL_2` | application |
| `CALL_TESTIMONIAL_2_NAME` | application |
| `CALL_TESTIMONIAL_2_SOURCE` | application |
| `CALL_TESTIMONIAL_3` | application |
| `CALL_TESTIMONIAL_3_NAME` | application |
| `CALL_TESTIMONIAL_3_SOURCE` | application |
| `CLOSE_URL` | replay |
| `COHOST_NAME` | registration |
| `COMMUNITY_GUIDES_TAB` | seat-confirmed · thank-you · vip-confirmation |
| `COMMUNITY_NAME` | seat-confirmed · thank-you · vip-confirmation |
| `COMMUNITY_PITCH` | ask-campaign · seat-confirmed · thank-you · vip-confirmation |
| `COMMUNITY_PLATFORM` | ask-campaign · seat-confirmed · thank-you · vip-confirmation |
| `COMMUNITY_URL` | ask-campaign · seat-confirmed · thank-you · vip-confirmation |
| `COMPANY` | application · ask-campaign · deposit · event-gate · membership · pass-close · pass-upsell · registration · replay · seat-confirmed · thank-you · upsell-2 · vip-confirmation · vip-downsell · vip-upsell · vip-upsell-long |
| `COMPANY_INITIALS` | ask-campaign · pass-upsell · seat-confirmed · upsell-2 · vip-confirmation · vip-downsell · vip-upsell · vip-upsell-long |
| `COMPLIANCE_FINE_PRINT` | registration |
| `DELIVERABLE_1` | registration |
| `DELIVERABLE_1_DESC` | registration |
| `DELIVERABLE_2` | registration |
| `DELIVERABLE_2_DESC` | registration |
| `DELIVERABLE_3` | registration |
| `DELIVERABLE_3_DESC` | registration |
| `DELIVERABLE_4` | registration |
| `DELIVERABLE_4_DESC` | registration |
| `DEPOSIT_AMOUNT` | deposit |
| `DEPOSIT_BONUS_DESC` | deposit |
| `DEPOSIT_BONUS_NAME` | deposit |
| `DEPOSIT_BONUS_VALUE` | deposit |
| `DEPOSIT_CTA_SUB` | deposit |
| `DEPOSIT_DEADLINE_ISO` | deposit |
| `DEPOSIT_GUARANTEE_NAME` | deposit |
| `DEPOSIT_REFUND_TERMS` | deposit |
| `DEPOSIT_RESULT_1` | deposit |
| `DEPOSIT_RESULT_1_NAME` | deposit |
| `DEPOSIT_RESULT_1_SOURCE` | deposit |
| `DEPOSIT_RESULT_2` | deposit |
| `DEPOSIT_RESULT_2_NAME` | deposit |
| `DEPOSIT_RESULT_2_SOURCE` | deposit |
| `DEPOSIT_RESULT_3` | deposit |
| `DEPOSIT_RESULT_3_NAME` | deposit |
| `DEPOSIT_RESULT_3_SOURCE` | deposit |
| `DEPOSIT_STEP_1_DESC` | deposit |
| `DEPOSIT_STEP_2` | deposit |
| `DEPOSIT_STEP_2_DESC` | deposit |
| `DEPOSIT_STEP_3_DESC` | deposit |
| `DEPOSIT_URGENCY_LINE` | deposit |
| `DESIRED_RESULT` | application · vip-upsell-long |
| `DISCLAIMER_URL` | application · ask-campaign · deposit · event-gate · membership · pass-close · pass-upsell · registration · replay · seat-confirmed · thank-you · upsell-2 · vip-confirmation · vip-downsell · vip-upsell · vip-upsell-long |
| `DOWNSELL_ANCHOR_PRICE` | vip-downsell |
| `DOWNSELL_INCLUDE_1` | vip-downsell |
| `DOWNSELL_INCLUDE_2` | vip-downsell |
| `DOWNSELL_INCLUDE_3` | vip-downsell |
| `DOWNSELL_INCLUDE_4` | vip-downsell |
| `DOWNSELL_INCLUDE_5` | vip-downsell |
| `DOWNSELL_NAME` | vip-downsell |
| `DOWNSELL_PRICE` | vip-downsell |
| `DOWNSELL_WHY` | vip-downsell |
| `DURATION` | registration · replay |
| `EVENT_DATE` | ask-campaign · event-gate · registration · seat-confirmed · thank-you · vip-confirmation |
| `EVENT_MAGNET_NAME` | registration · vip-upsell · vip-upsell-long |
| `EVENT_MAGNET_PROMISE` | registration |
| `EVENT_NAME` | ask-campaign · event-gate · registration · replay · seat-confirmed · thank-you · vip-confirmation · vip-upsell · vip-upsell-long |
| `EVENT_PLATFORM` | event-gate |
| `EVENT_START_ISO` | ask-campaign · event-gate · registration · seat-confirmed · thank-you · vip-confirmation |
| `EVENT_TIME` | ask-campaign · event-gate · registration · seat-confirmed · thank-you · vip-confirmation |
| `EVENT_TYPE_WORD` | ask-campaign · event-gate · registration · replay · seat-confirmed · thank-you · vip-confirmation · vip-upsell · vip-upsell-long |
| `EXIT_FORM_URL` | registration |
| `FAQ_4_A` | registration |
| `FAQ_4_Q` | registration |
| `FAQ_5_A` | registration |
| `FAQ_5_Q` | registration |
| `FAQ_REPLAY` | registration |
| `FAQ_SELLING` | registration |
| `FAQ_WHY_FREE` | registration |
| `FAQ_WHY_SO_LOW` | registration |
| `FINAL_CLOSE_HEADLINE` | registration |
| `GATE_FORM_URL` | event-gate |
| `HERO_EVENT_BLURB` | registration |
| `HERO_EVENT_TITLE` | registration |
| `HERO_HOOK` | registration |
| `HERO_SUB` | registration |
| `HERO_TAG` | registration |
| `HOME_URL` | application · ask-campaign · deposit · event-gate · membership · pass-close · pass-upsell · registration · replay · seat-confirmed · thank-you · upsell-2 · vip-confirmation · vip-downsell · vip-upsell · vip-upsell-long |
| `HONEST_DISQUALIFIER` | registration |
| `HOST_BIO` | registration |
| `HOST_FIRST_NAME` | ask-campaign · pass-upsell · registration · seat-confirmed · upsell-2 · vip-confirmation · vip-downsell · vip-upsell · vip-upsell-long |
| `HOST_HEADLINE_CREDENTIAL` | registration |
| `HOST_NAME` | application · ask-campaign · deposit · event-gate · pass-close · pass-upsell · registration · seat-confirmed · thank-you · upsell-2 · vip-confirmation · vip-downsell · vip-upsell · vip-upsell-long |
| `HOST_PROMISE_QUOTE` | registration |
| `HOST_TAGLINE` | registration |
| `HOST_YEARS` | vip-upsell-long |
| `HOSTS_BIO` | registration |
| `HOSTS_MARKER_1` | registration |
| `HOSTS_MARKER_2` | registration |
| `HOSTS_MARKER_3` | registration |
| `HOSTS_MARKER_4` | registration |
| `HOSTS_TAGLINE` | registration |
| `INCLUSION_1` | membership |
| `INCLUSION_1_DESC` | membership |
| `INCLUSION_1_VALUE` | membership |
| `INCLUSION_2` | membership |
| `INCLUSION_2_DESC` | membership |
| `INCLUSION_2_VALUE` | membership |
| `INCLUSION_3` | membership |
| `INCLUSION_3_DESC` | membership |
| `INCLUSION_3_VALUE` | membership |
| `INCLUSION_4` | membership |
| `INCLUSION_4_DESC` | membership |
| `INCLUSION_4_VALUE` | membership |
| `KIT` | application · ask-campaign · deposit · event-gate · membership · pass-close · pass-upsell · registration · replay · seat-confirmed · thank-you · upsell-2 · vip-confirmation · vip-downsell · vip-upsell · vip-upsell-long |
| `LETTER_C` | registration |
| `LETTER_C_HEAD` | registration |
| `LETTER_E` | registration |
| `LETTER_E_HEAD` | registration |
| `LETTER_O` | registration |
| `LETTER_O_HEAD` | registration |
| `LETTER_R` | registration |
| `LETTER_R_HEAD` | registration |
| `LETTER_R_PROOF` | registration |
| `LETTER_S` | registration |
| `LETTER_S_HEAD` | registration |
| `LEVEL_1` | ask-campaign |
| `LEVEL_2` | ask-campaign |
| `LEVEL_3` | ask-campaign |
| `LEVEL_4` | ask-campaign |
| `MAGIC_FORMULA_HOT_STEP` | vip-upsell · vip-upsell-long |
| `MAGIC_FORMULA_STAGE_1` | vip-upsell · vip-upsell-long |
| `MAGIC_FORMULA_STAGE_2` | vip-upsell · vip-upsell-long |
| `MAGIC_FORMULA_STAGE_3` | vip-upsell · vip-upsell-long |
| `MEMBER_BONUS_1` | membership |
| `MEMBER_BONUS_1_DESC` | membership |
| `MEMBER_BONUS_1_VALUE` | membership |
| `MEMBER_BONUS_2` | membership |
| `MEMBER_BONUS_2_DESC` | membership |
| `MEMBER_BONUS_2_VALUE` | membership |
| `MEMBER_CORE` | membership |
| `MEMBER_CORE_DESC` | membership |
| `MEMBER_DEADLINE_ISO` | membership |
| `MEMBER_FROM_PRICE` | membership |
| `MEMBER_GUARANTEE_NAME` | membership |
| `MEMBER_GUARANTEE_SCOPE` | membership |
| `MEMBER_GUARANTEE_TERMS` | membership |
| `MEMBER_RESULT_1` | membership |
| `MEMBER_RESULT_1_NAME` | membership |
| `MEMBER_RESULT_1_SOURCE` | membership |
| `MEMBER_RESULT_2` | membership |
| `MEMBER_RESULT_2_NAME` | membership |
| `MEMBER_RESULT_2_SOURCE` | membership |
| `MEMBER_RESULT_3` | membership |
| `MEMBER_RESULT_3_NAME` | membership |
| `MEMBER_RESULT_3_SOURCE` | membership |
| `MEMBER_RESULT_4` | membership |
| `MEMBER_RESULT_4_NAME` | membership |
| `MEMBER_RESULT_4_SOURCE` | membership |
| `MEMBER_SPOTS` | membership |
| `MEMBER_TOTAL_VALUE` | membership |
| `MEMBER_URGENCY_LINE` | membership |
| `MODULE_1` | membership |
| `MODULE_1_DESC` | membership |
| `MODULE_1_VALUE` | membership |
| `MODULE_2` | membership |
| `MODULE_2_DESC` | membership |
| `MODULE_2_VALUE` | membership |
| `MODULE_3` | membership |
| `MODULE_3_DESC` | membership |
| `MODULE_3_VALUE` | membership |
| `MONTHLY_NOTE` | membership |
| `MONTHLY_PRICE` | membership |
| `NEXT_PAGE_URL` | registration |
| `NO_THANKS_TO` | pass-upsell · upsell-2 · vip-downsell · vip-upsell · vip-upsell-long |
| `NO_THANKS_URL` | pass-upsell · upsell-2 · vip-downsell · vip-upsell · vip-upsell-long |
| `OBJECTION_1` | membership · registration |
| `OBJECTION_2` | membership · registration |
| `OFFER_CTA` | replay |
| `OFFER_DEADLINE_LINE` | replay |
| `OFFER_HEADLINE` | deposit |
| `OFFER_INCLUDE_1` | deposit |
| `OFFER_INCLUDE_1_DESC` | deposit |
| `OFFER_INCLUDE_1_VALUE` | deposit |
| `OFFER_INCLUDE_2` | deposit |
| `OFFER_INCLUDE_2_DESC` | deposit |
| `OFFER_INCLUDE_2_VALUE` | deposit |
| `OFFER_INCLUDE_3` | deposit |
| `OFFER_INCLUDE_3_DESC` | deposit |
| `OFFER_INCLUDE_3_VALUE` | deposit |
| `OFFER_INCLUDE_4` | deposit |
| `OFFER_INCLUDE_4_DESC` | deposit |
| `OFFER_INCLUDE_4_VALUE` | deposit |
| `OFFER_INCLUDE_5` | deposit |
| `OFFER_INCLUDE_5_DESC` | deposit |
| `OFFER_INCLUDE_5_VALUE` | deposit |
| `OFFER_INCLUDE_6` | deposit |
| `OFFER_INCLUDE_6_DESC` | deposit |
| `OFFER_INCLUDE_6_VALUE` | deposit |
| `OFFER_NAME` | deposit · replay |
| `OFFER_PRICE` | deposit |
| `OFFER_SPOTS` | deposit |
| `OFFER_SUBHEAD` | deposit |
| `OFFER_TEASE` | replay |
| `OFFER_TOTAL_VALUE` | deposit |
| `OUTCOME_1` | registration |
| `OUTCOME_2` | registration |
| `OUTCOME_3` | registration |
| `PAIN_1_BODY` | registration |
| `PAIN_1_LABEL` | registration |
| `PAIN_1_QUOTE` | registration |
| `PAIN_2_BODY` | registration |
| `PAIN_2_LABEL` | registration |
| `PAIN_2_QUOTE` | registration |
| `PAIN_3_BODY` | registration |
| `PAIN_3_LABEL` | registration |
| `PAIN_3_QUOTE` | registration |
| `PAIN_4_BODY` | registration |
| `PAIN_4_LABEL` | registration |
| `PAIN_4_QUOTE` | registration |
| `PAINS_HEADLINE` | registration |
| `PAINS_SUBHEAD` | registration |
| `PAINS_TRUTH` | registration |
| `PASS_BLIND_SPOT` | pass-close · pass-upsell |
| `PASS_BONUS_CRED` | pass-close · pass-upsell |
| `PASS_BONUS_DESC` | pass-close · pass-upsell |
| `PASS_BONUS_NAME` | pass-close · pass-upsell |
| `PASS_BONUS_SCARCITY` | pass-close · pass-upsell |
| `PASS_CREDIT_LINE` | pass-close · pass-upsell |
| `PASS_DEADLINE_ISO` | pass-close |
| `PASS_DELIVERABLE` | pass-close · pass-upsell |
| `PASS_DELIVERABLE_WORD` | pass-close · pass-upsell |
| `PASS_DELIVERY_TERMS` | pass-close · pass-upsell |
| `PASS_GUARANTEE` | pass-close · pass-upsell |
| `PASS_GUARANTEE_DAYS` | pass-close · pass-upsell |
| `PASS_HEADLINE` | pass-close |
| `PASS_INSIDE_1` | pass-close · pass-upsell |
| `PASS_INSIDE_2` | pass-close · pass-upsell |
| `PASS_INSIDE_3` | pass-close · pass-upsell |
| `PASS_INSIDE_4` | pass-close · pass-upsell |
| `PASS_INSIDE_5` | pass-close · pass-upsell |
| `PASS_INSIDE_6` | pass-close · pass-upsell |
| `PASS_INSIDE_7` | pass-close · pass-upsell |
| `PASS_INSIDE_8` | pass-close · pass-upsell |
| `PASS_NAME` | pass-close · pass-upsell · thank-you |
| `PASS_OVERWHELM_LINE` | pass-close · pass-upsell |
| `PASS_PRICE` | pass-close · pass-upsell |
| `PASS_PRICE_TALK` | pass-close · pass-upsell |
| `PASS_ROI_HEADER` | pass-close · pass-upsell |
| `PASS_ROI_RESULT` | pass-close · pass-upsell |
| `PASS_ROI_RESULT_SUB` | pass-close · pass-upsell |
| `PASS_ROI_SCENARIO` | pass-close · pass-upsell |
| `PASS_STEP_1` | pass-close · pass-upsell |
| `PASS_STEP_1_DESC` | pass-close · pass-upsell |
| `PASS_STEP_2` | pass-close · pass-upsell |
| `PASS_STEP_2_DESC` | pass-close · pass-upsell |
| `PASS_STEP_3` | pass-close · pass-upsell |
| `PASS_STEP_3_DESC` | pass-close · pass-upsell |
| `PASS_STEP_4` | pass-close · pass-upsell |
| `PASS_STEP_4_DESC` | pass-close · pass-upsell |
| `PASS_SUBHEAD` | pass-close |
| `PASS_SUMMARY` | pass-close · pass-upsell |
| `PASS_TESTIMONIAL_1` | pass-close · pass-upsell |
| `PASS_TESTIMONIAL_1_NAME` | pass-close · pass-upsell |
| `PASS_TESTIMONIAL_1_SOURCE` | pass-close · pass-upsell |
| `PASS_TESTIMONIAL_2` | pass-close · pass-upsell |
| `PASS_TESTIMONIAL_2_NAME` | pass-close · pass-upsell |
| `PASS_TESTIMONIAL_2_SOURCE` | pass-close · pass-upsell |
| `PASS_TESTIMONIAL_3` | pass-close · pass-upsell |
| `PASS_TESTIMONIAL_3_NAME` | pass-close · pass-upsell |
| `PASS_TESTIMONIAL_3_SOURCE` | pass-close · pass-upsell |
| `PASS_URGENCY_LINE` | pass-close |
| `PASS_WORTH_IT` | pass-close · pass-upsell |
| `PRIVACY_URL` | application · ask-campaign · deposit · event-gate · membership · pass-close · pass-upsell · registration · replay · seat-confirmed · thank-you · upsell-2 · vip-confirmation · vip-downsell · vip-upsell · vip-upsell-long |
| `PROBLEM_1` | registration |
| `PROBLEM_1_BENEFIT_1` | registration |
| `PROBLEM_1_BENEFIT_2` | registration |
| `PROBLEM_1_BENEFIT_3` | registration |
| `PROBLEM_2` | registration |
| `PROBLEM_2_BENEFIT_1` | registration |
| `PROBLEM_2_BENEFIT_2` | registration |
| `PROBLEM_2_BENEFIT_3` | registration |
| `PROBLEM_3` | registration |
| `PROBLEM_3_BENEFIT_1` | registration |
| `PROBLEM_3_BENEFIT_2` | registration |
| `PROBLEM_3_BENEFIT_3` | registration |
| `PROBLEMS_INTRO` | registration |
| `PROGRAM_NAME` | membership |
| `PROGRAM_PROMISE` | membership |
| `PULL_QUOTE` | registration |
| `QUALIFIER_1` | registration |
| `QUALIFIER_1_LABEL` | registration |
| `QUALIFIER_2` | registration |
| `QUALIFIER_2_LABEL` | registration |
| `QUALIFIER_3` | registration |
| `QUALIFIER_3_LABEL` | registration |
| `REFRAME_REAL` | registration |
| `REFRAME_THINK` | registration |
| `REPLAY_END_ISO` | replay |
| `REPLAY_WINDOW` | replay |
| `RESOURCE_1` | replay |
| `RESOURCE_1_URL` | replay |
| `RESOURCE_2` | replay |
| `RESOURCE_2_URL` | replay |
| `RESOURCE_3` | replay |
| `RESOURCE_3_URL` | replay |
| `RESULTS_DISCLAIMER` | application · ask-campaign · deposit · event-gate · membership · pass-close · pass-upsell · registration · replay · seat-confirmed · thank-you · upsell-2 · vip-confirmation · vip-downsell · vip-upsell · vip-upsell-long |
| `SENDER_EMAIL` | seat-confirmed · thank-you · vip-confirmation |
| `SOLUTION_BENEFIT_1` | registration |
| `SOLUTION_BENEFIT_2` | registration |
| `SOLUTION_BENEFIT_3` | registration |
| `SOLUTION_BODY` | registration |
| `SOLUTION_QUOTE` | registration |
| `SOLUTION_SUBHEAD` | registration |
| `SOLVE_1` | registration |
| `SOLVE_2` | registration |
| `SOLVE_3` | registration |
| `STACK_1` | registration |
| `STACK_1_VALUE` | registration |
| `STACK_2` | registration |
| `STACK_2_VALUE` | registration |
| `STACK_3` | registration |
| `STACK_3_VALUE` | registration |
| `STATEMENT_DESCRIPTOR` | thank-you · vip-confirmation |
| `SUPPORT_EMAIL` | application · ask-campaign · deposit · event-gate · membership · pass-close · pass-upsell · registration · replay · seat-confirmed · thank-you · upsell-2 · vip-confirmation · vip-downsell · vip-upsell · vip-upsell-long |
| `SURVEY_FORM_URL` | ask-campaign |
| `SURVEY_PITCH` | ask-campaign |
| `SYSTEM_FRAME` | deposit · membership |
| `SYSTEM_NAME` | deposit · membership · vip-upsell · vip-upsell-long |
| `TERMS_URL` | application · ask-campaign · deposit · event-gate · membership · pass-close · pass-upsell · registration · replay · seat-confirmed · thank-you · upsell-2 · vip-confirmation · vip-downsell · vip-upsell · vip-upsell-long |
| `TESTIMONIAL_1` | registration |
| `TESTIMONIAL_1_NAME` | registration |
| `TESTIMONIAL_1_SOURCE` | registration |
| `TESTIMONIAL_2` | registration |
| `TESTIMONIAL_2_NAME` | registration |
| `TESTIMONIAL_2_SOURCE` | registration |
| `TESTIMONIAL_3` | registration |
| `TESTIMONIAL_3_NAME` | registration |
| `TESTIMONIAL_3_SOURCE` | registration |
| `TESTIMONIAL_4` | registration |
| `TESTIMONIAL_4_NAME` | registration |
| `TESTIMONIAL_4_SOURCE` | registration |
| `TESTIMONIAL_5` | registration |
| `TESTIMONIAL_5_NAME` | registration |
| `TESTIMONIAL_5_SOURCE` | registration |
| `TESTIMONIAL_6` | registration |
| `TESTIMONIAL_6_NAME` | registration |
| `TESTIMONIAL_6_SOURCE` | registration |
| `TICKET_GUARANTEE` | registration |
| `TICKET_GUARANTEE_DAYS` | registration |
| `TICKET_GUARANTEE_SHORT` | registration |
| `TICKET_PRICE` | registration · thank-you · vip-confirmation |
| `TOTAL_VALUE` | registration |
| `TRUST_AUDIENCE` | registration |
| `TWO_FUTURES` | registration |
| `UPSELL2_BENEFIT_1` | upsell-2 |
| `UPSELL2_BENEFIT_1_DESC` | upsell-2 |
| `UPSELL2_BENEFIT_2` | upsell-2 |
| `UPSELL2_BENEFIT_2_DESC` | upsell-2 |
| `UPSELL2_BENEFIT_3` | upsell-2 |
| `UPSELL2_BENEFIT_3_DESC` | upsell-2 |
| `UPSELL2_DELIVERY_TERMS` | upsell-2 |
| `UPSELL2_GUARANTEE` | upsell-2 |
| `UPSELL2_GUARANTEE_DAYS` | upsell-2 |
| `UPSELL2_INCLUDE_1` | upsell-2 |
| `UPSELL2_INCLUDE_2` | upsell-2 |
| `UPSELL2_INCLUDE_3` | upsell-2 |
| `UPSELL2_INCLUDE_4` | upsell-2 |
| `UPSELL2_INCLUDE_5` | upsell-2 |
| `UPSELL2_INCLUDE_6` | upsell-2 |
| `UPSELL2_NAME` | upsell-2 |
| `UPSELL2_PRICE` | upsell-2 |
| `VIP_ANCHOR_PRICE` | vip-upsell-long |
| `VIP_CONGRATS_LETTER` | vip-upsell-long |
| `VIP_GUARANTEE` | vip-upsell · vip-upsell-long |
| `VIP_GUARANTEE_DAYS` | vip-upsell · vip-upsell-long |
| `VIP_GUARANTEE_SHORT` | vip-upsell |
| `VIP_OFFER_NAME` | vip-upsell-long |
| `VIP_ONE_MORE_THING` | vip-upsell-long |
| `VIP_OUTCOME` | seat-confirmed |
| `VIP_PARTY_HOURLY_ANCHOR` | vip-upsell-long |
| `VIP_PARTY_LENGTH` | vip-upsell · vip-upsell-long |
| `VIP_PARTY_OUTCOME` | vip-upsell-long |
| `VIP_PARTY_VALUE` | vip-upsell · vip-upsell-long |
| `VIP_PLUSONE_VALUE` | vip-upsell · vip-upsell-long |
| `VIP_POCKET_HOURLY_ANCHOR` | vip-upsell-long |
| `VIP_POCKET_PLATFORM` | seat-confirmed · vip-upsell · vip-upsell-long |
| `VIP_POCKET_VALUE` | vip-upsell · vip-upsell-long |
| `VIP_POCKET_WINDOW` | seat-confirmed · vip-upsell · vip-upsell-long |
| `VIP_PRICE` | seat-confirmed · vip-confirmation · vip-upsell · vip-upsell-long |
| `VIP_SHIFT_1_FROM` | vip-upsell-long |
| `VIP_SHIFT_1_TO` | vip-upsell-long |
| `VIP_SHIFT_2_FROM` | vip-upsell-long |
| `VIP_SHIFT_2_TO` | vip-upsell-long |
| `VIP_SHIFT_3_FROM` | vip-upsell-long |
| `VIP_SHIFT_3_TO` | vip-upsell-long |
| `VIP_SPEED_BENEFIT` | vip-upsell-long |
| `VIP_TESTIMONIAL_1` | vip-upsell · vip-upsell-long |
| `VIP_TESTIMONIAL_1_NAME` | vip-upsell · vip-upsell-long |
| `VIP_TESTIMONIAL_1_SOURCE` | vip-upsell · vip-upsell-long |
| `VIP_TESTIMONIAL_2` | vip-upsell · vip-upsell-long |
| `VIP_TESTIMONIAL_2_NAME` | vip-upsell · vip-upsell-long |
| `VIP_TESTIMONIAL_2_SOURCE` | vip-upsell · vip-upsell-long |
| `VIP_TESTIMONIAL_3` | vip-upsell · vip-upsell-long |
| `VIP_TESTIMONIAL_3_NAME` | vip-upsell · vip-upsell-long |
| `VIP_TESTIMONIAL_3_SOURCE` | vip-upsell · vip-upsell-long |
| `VIP_TOTAL_VALUE` | vip-upsell · vip-upsell-long |
| `VIP_TRIVIAL_COMPARISON` | vip-upsell-long |
| `VIP_URL` | seat-confirmed |
| `VIP_VAULT_VALUE` | vip-upsell · vip-upsell-long |
| `VIP_WORKBOOK_VALUE` | vip-upsell · vip-upsell-long |
| `WHY_FREE` | registration |
| `WHY_PAYOFF` | registration |
| `WHY_SO_LOW` | registration |
| `YEAR` | application · ask-campaign · deposit · event-gate · membership · pass-close · pass-upsell · registration · replay · seat-confirmed · thank-you · upsell-2 · vip-confirmation · vip-downsell · vip-upsell · vip-upsell-long |
| `YEARLY_NOTE` | membership |
| `YEARLY_PRICE` | membership |
| `YEARLY_SAVING` | membership |