# Recipes — which pages, in what order, and where every link goes

A funnel is a **recipe**: an ordered list of pages from the library (`templates/`). The four Accelerator phases are
the starting recipes. File names, links and lanes are worked out from the order — the tables below are the four
recipes worked out (generated from the V2 engine's `funnel_map.py`, so V3 builds the same funnels). Use them as they
are; for a changed recipe, work it out with the rules under the tables.

## The flow questions — ask these first, one at a time (PLAN-V3 Step 4)

1. **Which phase recipe?** 1 Launch · 2 Execute · 3 Growth · 4 Mastery (from CONTEXT.md / the Money Model — confirm).
2. **Free or paid entry?** (the recipe's default unless the Money Model says otherwise)
3. **Which event?** workshop · masterclass · challenge.
4. **Which offers follow page 1?** VIP (always) · VIP downsell · PASS™ upsell · Upsell 2 — add or remove from the recipe.
5. **Which close?** application · membership · PASS™ session · deposit (the phase's options).

**Downsell price rule (Authority Detonator™):** VIP $100 or more → the downsell is the SAME offer as a payment plan;
under $100 → a lower price with items removed.

## The page library

registration · ask-campaign · vip-upsell (short, cart on the page) · vip-upsell-long · vip-downsell ·
vip-confirmation · seat-confirmed · pass-upsell · upsell-2 · event-gate · replay · closes: application · membership ·
pass-close · deposit. (thank-you = legacy single confirmation; not in any recipe.)

## Videos — which pages get one, and which script (decision 15)

| Page | Video | Script |
|---|---|---|
| registration — PAID | yes, at the top | Ticket Sales Detonator™ |
| registration — FREE | **no** | — |
| ask-campaign | yes | Authority Detonator™ A · Show-Up |
| vip-upsell / vip-upsell-long | yes | Authority Detonator™ B (free entry) · D (paid entry) |
| vip-downsell | yes | Authority Detonator™ E |
| pass-upsell · upsell-2 | yes | Authority Detonator™ F |
| vip-confirmation · seat-confirmed | yes | Authority Detonator™ C (the confirmation pair) |
| event-gate · application · replay · membership · pass-close · deposit | **no** — keep as they are | — |

## The four recipes
### Phase 1 · Launch · Free workshop · entry: free · close: application

| File | Page · template | Yes / next → | No thanks → | Step bar (**now**) |
|---|---|---|---|---|
| `1-registration.html` | Registration · `registration` | 2-ask-campaign.html | — | — |
| `2-ask-campaign.html` | Ask Campaign · survey thank-you · `ask-campaign` | 3-event-gate.html | — | — |
| `3-event-gate.html` | Event Gate · `event-gate` | 4-replay.html | — | — |
| `4-replay.html` | Replay · `replay` | 5-application.html | — | — |
| `5-application.html` | Close · Application · `application` | — | — | — |

### Phase 2 · Execute · Free masterclass · entry: free · close: membership

| File | Page · template | Yes / next → | No thanks → | Step bar (**now**) |
|---|---|---|---|---|
| `1-registration.html` | Registration · `registration` | 2-vip-upsell.html | — | — |
| `2-vip-upsell.html` | VIP Upsell · short, with cart · `vip-upsell` | 3a-vip-confirmation.html | 3b-seat-confirmed.html | Ticket / Seat · **VIP upgrade** · Confirmation |
| `3a-vip-confirmation.html` | VIP Confirmation · `vip-confirmation` | 4-event-gate.html | — | Ticket / Seat · VIP upgrade · **Confirmation** |
| `3b-seat-confirmed.html` | Seat Confirmed · `seat-confirmed` | 4-event-gate.html | — | Ticket / Seat · **Confirmation** |
| `4-event-gate.html` | Event Gate · `event-gate` | 5-replay.html | — | — |
| `5-replay.html` | Replay · `replay` | 6-membership.html | — | — |
| `6-membership.html` | Close · Membership · `membership` | — | — | — |

### Phase 2 · Execute · Free masterclass · entry: free · close: pass-close

| File | Page · template | Yes / next → | No thanks → | Step bar (**now**) |
|---|---|---|---|---|
| `1-registration.html` | Registration · `registration` | 2-vip-upsell.html | — | — |
| `2-vip-upsell.html` | VIP Upsell · short, with cart · `vip-upsell` | 3a-vip-confirmation.html | 3b-seat-confirmed.html | Ticket / Seat · **VIP upgrade** · Confirmation |
| `3a-vip-confirmation.html` | VIP Confirmation · `vip-confirmation` | 4-event-gate.html | — | Ticket / Seat · VIP upgrade · **Confirmation** |
| `3b-seat-confirmed.html` | Seat Confirmed · `seat-confirmed` | 4-event-gate.html | — | Ticket / Seat · **Confirmation** |
| `4-event-gate.html` | Event Gate · `event-gate` | 5-replay.html | — | — |
| `5-replay.html` | Replay · `replay` | 6-pass.html | — | — |
| `6-pass.html` | Close · PASS™ session · `pass-close` | — | — | — |

### Phase 3 · Growth · Paid masterclass · entry: paid · close: membership

| File | Page · template | Yes / next → | No thanks → | Step bar (**now**) |
|---|---|---|---|---|
| `1-registration.html` | Registration · `registration` | 2-vip-upsell.html | — | — |
| `2-vip-upsell.html` | VIP Upsell · long-form · `vip-upsell-long` | 3a-pass-upsell.html | 3b-pass-upsell.html | Ticket / Seat · **VIP upgrade** · Session · Confirmation |
| `3a-pass-upsell.html` | PASS™ Upsell · VIP lane · `pass-upsell` | 4a-vip-confirmation.html | 4a-vip-confirmation.html | Ticket / Seat · VIP upgrade · **Session** · Confirmation |
| `3b-pass-upsell.html` | PASS™ Upsell · no-VIP lane · `pass-upsell` | 4b-seat-confirmed.html | 4b-seat-confirmed.html | Ticket / Seat · VIP upgrade · **Session** · Confirmation |
| `4a-vip-confirmation.html` | VIP Confirmation · `vip-confirmation` | 5-event-gate.html | — | Ticket / Seat · VIP upgrade · Session · **Confirmation** |
| `4b-seat-confirmed.html` | Seat Confirmed · `seat-confirmed` | 5-event-gate.html | — | Ticket / Seat · Session · **Confirmation** |
| `5-event-gate.html` | Event Gate · `event-gate` | 6-replay.html | — | — |
| `6-replay.html` | Replay · `replay` | 7-membership.html | — | — |
| `7-membership.html` | Close · Membership · `membership` | — | — | — |

### Phase 4 · Mastery · Paid challenge · entry: paid · close: membership

| File | Page · template | Yes / next → | No thanks → | Step bar (**now**) |
|---|---|---|---|---|
| `1-registration.html` | Registration · `registration` | 2-vip-upsell.html | — | — |
| `2-vip-upsell.html` | VIP Upsell · long-form · `vip-upsell-long` | 3a-pass-upsell.html | 2b-vip-downsell.html | Ticket / Seat · **VIP upgrade** · Session · {{UPSELL2_STEP_LABEL}} · Confirmation |
| `2b-vip-downsell.html` | VIP Downsell · `vip-downsell` | 3b-pass-upsell.html | 3b-pass-upsell.html | Ticket / Seat · **VIP upgrade** · Session · {{UPSELL2_STEP_LABEL}} · Confirmation |
| `3a-pass-upsell.html` | PASS™ Upsell · VIP lane · `pass-upsell` | 4a-upsell-2.html | 4a-upsell-2.html | Ticket / Seat · VIP upgrade · **Session** · {{UPSELL2_STEP_LABEL}} · Confirmation |
| `3b-pass-upsell.html` | PASS™ Upsell · no-VIP lane · `pass-upsell` | 4b-upsell-2.html | 4b-upsell-2.html | Ticket / Seat · VIP upgrade · **Session** · {{UPSELL2_STEP_LABEL}} · Confirmation |
| `4a-upsell-2.html` | Upsell 2 · VIP lane · `upsell-2` | 5a-vip-confirmation.html | 5a-vip-confirmation.html | Ticket / Seat · VIP upgrade · Session · **{{UPSELL2_STEP_LABEL}}** · Confirmation |
| `4b-upsell-2.html` | Upsell 2 · no-VIP lane · `upsell-2` | 5b-seat-confirmed.html | 5b-seat-confirmed.html | Ticket / Seat · VIP upgrade · Session · **{{UPSELL2_STEP_LABEL}}** · Confirmation |
| `5a-vip-confirmation.html` | VIP Confirmation · `vip-confirmation` | 6-event-gate.html | — | Ticket / Seat · VIP upgrade · Session · {{UPSELL2_STEP_LABEL}} · **Confirmation** |
| `5b-seat-confirmed.html` | Seat Confirmed · `seat-confirmed` | 6-event-gate.html | — | Ticket / Seat · Session · {{UPSELL2_STEP_LABEL}} · **Confirmation** |
| `6-event-gate.html` | Event Gate · `event-gate` | 7-replay.html | — | — |
| `7-replay.html` | Replay · `replay` | 8-membership.html | — | — |
| `8-membership.html` | Close · Membership · `membership` | — | — | — |

### Phase 4 · Mastery · Paid challenge · entry: paid · close: deposit

| File | Page · template | Yes / next → | No thanks → | Step bar (**now**) |
|---|---|---|---|---|
| `1-registration.html` | Registration · `registration` | 2-vip-upsell.html | — | — |
| `2-vip-upsell.html` | VIP Upsell · long-form · `vip-upsell-long` | 3a-pass-upsell.html | 2b-vip-downsell.html | Ticket / Seat · **VIP upgrade** · Session · {{UPSELL2_STEP_LABEL}} · Confirmation |
| `2b-vip-downsell.html` | VIP Downsell · `vip-downsell` | 3b-pass-upsell.html | 3b-pass-upsell.html | Ticket / Seat · **VIP upgrade** · Session · {{UPSELL2_STEP_LABEL}} · Confirmation |
| `3a-pass-upsell.html` | PASS™ Upsell · VIP lane · `pass-upsell` | 4a-upsell-2.html | 4a-upsell-2.html | Ticket / Seat · VIP upgrade · **Session** · {{UPSELL2_STEP_LABEL}} · Confirmation |
| `3b-pass-upsell.html` | PASS™ Upsell · no-VIP lane · `pass-upsell` | 4b-upsell-2.html | 4b-upsell-2.html | Ticket / Seat · VIP upgrade · **Session** · {{UPSELL2_STEP_LABEL}} · Confirmation |
| `4a-upsell-2.html` | Upsell 2 · VIP lane · `upsell-2` | 5a-vip-confirmation.html | 5a-vip-confirmation.html | Ticket / Seat · VIP upgrade · Session · **{{UPSELL2_STEP_LABEL}}** · Confirmation |
| `4b-upsell-2.html` | Upsell 2 · no-VIP lane · `upsell-2` | 5b-seat-confirmed.html | 5b-seat-confirmed.html | Ticket / Seat · VIP upgrade · Session · **{{UPSELL2_STEP_LABEL}}** · Confirmation |
| `5a-vip-confirmation.html` | VIP Confirmation · `vip-confirmation` | 6-event-gate.html | — | Ticket / Seat · VIP upgrade · Session · {{UPSELL2_STEP_LABEL}} · **Confirmation** |
| `5b-seat-confirmed.html` | Seat Confirmed · `seat-confirmed` | 6-event-gate.html | — | Ticket / Seat · Session · {{UPSELL2_STEP_LABEL}} · **Confirmation** |
| `6-event-gate.html` | Event Gate · `event-gate` | 7-replay.html | — | — |
| `7-replay.html` | Replay · `replay` | 8-deposit.html | — | — |
| `8-deposit.html` | Close · Deposit · `deposit` | — | — | — |

## Working out a changed recipe

- **Add / remove pages** with the operator ("add vip-upsell after ask-campaign", "remove pass-upsell"). It must start
  with registration; a downsell or VIP confirmation needs a VIP page before it; no two VIP pages; an offer always has a
  page after it. Warn if replay comes before event-gate or there's no close.
- **File names:** number the pages in order: `1-registration.html`, `2-…`. The yes/no confirmations share a number
  (`3a-vip-confirmation`, `3b-seat-confirmed`); a downsell takes its offer's number + `b` (`2b-vip-downsell`).
- **Links:** each page's form/next → the next page. An offer's **No thanks** → the next page that isn't its "yes"
  page; its **Yes** is the order form's / upsell block's own redirect (note it for AI Studio). `VIP_URL` = the VIP page
  `#checkout` (seat-confirmed's P.S. re-pitch). The replay's button → the close page.
- **Lanes (paid events with offers between the VIP page and the confirmations):** a GHL page has one exit, so each of
  those offers is built twice — `a` (VIP lane → … → vip-confirmation) and `b` (no-VIP lane → … → seat-confirmed). VIP
  yes → the a pages; VIP no and the downsell → the b pages. Same page, different exits.
- **FREE events have no b lane (decision 14):** VIP "No thanks" goes straight to seat-confirmed (with the VIP re-pitch).
  No paid offers on the no-VIP path of a free event — there's no card on file.
- **The step bar:** V3 upsell/confirmation pages show the fixed 3-step header (Checkout/Registration ✓ · Almost
  complete · Complete) instead; the "Step bar" column is kept for reference only.