# Build rules — how a template becomes a finished page (V3, no Python)

V2 did these steps with `build_page.py`. In V3 **you** do them, in this order, on a copy of the template. The result
must be exactly what the script would have made — same markup, same classes — so nothing downstream changes.

## 0 · What you start with

- The template: `templates/<page id>.html` (never edit the template itself — work on a copy).
- The client's facts: every slot filled from their own files (see `SKILL.md` Step 2), plus the switches:
  `ENTRY` (free | paid), `EVENT_TYPE_WORD` (workshop | masterclass | challenge …), `VIP_OFF` (list), the page's place in
  the recipe (`reference/recipes.md`: file name, next page, no-thanks page, step bar).

## 1 · Recipe flags — `data-cfe-flag="x"`

Keep the element (remove the attribute) only when the recipe gives this page that flag; otherwise delete the whole
element. The only flag today: `vip-only` on the VIP confirmation when nothing else could have been bought (no PASS™ /
Upsell 2 in the funnel).

## 2 · VIP items — `data-cfe-vip="key"` / `data-cfe-vip-alt="key"`

Keys: `party · pocket · workbook · vault · plusone`. For each key in `VIP_OFF`: delete every element marked
`data-cfe-vip="key"`, keep the ones marked `data-cfe-vip-alt="key"` (that's the wording used instead). For keys NOT
off: keep `data-cfe-vip`, delete `data-cfe-vip-alt`. Then remove the attributes. A bare `<span>` wrapper left with no
attributes is unwrapped (keep its inside).

## 3 · Layout — `data-cfe-layout="hero"`

Registration only. **FREE → `data-layout="split"`** (the 2-column hero, the still V3 hero image on the right).
**PAID → no data-layout attribute** (the stacked, video-led hero — Matthew 2026-11-11). Remove `data-cfe-layout`.

## 4 · Entry — `data-cfe-entry="free|paid"` and the `<!-- @cta… -->` markers

Delete every element whose `data-cfe-entry` is the other entry (the whole element, nested ones included); on the kept
ones remove the attribute. Then replace each CTA marker with the stack below (`{{…}}` are filled in step 9).

| Marker | PAID | FREE |
|---|---|---|
| `<!-- @cta -->` | button + safe line + proof line | button + safe line + proof line |
| `<!-- @cta:hero -->` | same, button carries `data-cfe-cta="hero"` | same |
| `<!-- @cta:block -->` | same, button class `cl-cta cl-cta--block` | same |
| `<!-- @cta:close -->` | button + safe line only | button + safe line only |
| `<!-- @cta:sticky -->` | the button only, `cl-cta cl-cta--block`, `tabindex="-1"` | same |

PAID pieces (no price line — **one ticket price, never an early-bird or price-rise line**, decision 9):
- button: `<a class="cl-cta" href="#checkout"><span class="cl-cta__main">Grab My Seat — {{TICKET_PRICE}}</span><span class="cl-cta__sub">{{EVENT_DATE}} @ {{EVENT_TIME}}</span></a>`
- safe line: `<p class="cl-privacy">Secure checkout<span data-cfe-optional="guarantee" data-cfe-requires="TICKET_GUARANTEE_DAYS"> · {{TICKET_GUARANTEE_DAYS}}-day money-back guarantee</span></p>`

FREE pieces:
- price line (all but close/sticky): `<p class="cl-priceline" data-cfe-optional="anchor" data-cfe-requires="EVENT_ANCHOR_VALUE"><span class="cl-strike">Normally {{EVENT_ANCHOR_VALUE}}</span> <strong class="cl-pos">Today it's free.</strong></p>` — placed BEFORE the button
- button: `<a class="cl-cta" href="#register" data-open="register"><span class="cl-cta__main">Save My FREE Seat</span><span class="cl-cta__sub">{{EVENT_DATE}} @ {{EVENT_TIME}}</span></a>`
- safe line: `<p class="cl-privacy">Your information is 100% safe with us.</p>`

Proof line (both, all but close/sticky): `<p class="cl-proofline" data-cfe-optional="proof">{{HERO_PROOF_LINE}}</p>`.

## 5 · The step bar — `<!-- @progress … -->`

V3 upsell and confirmation pages no longer use it (they carry the 3-step `v3-prog` header, already in the template).
If a page still has the marker (none do today), build `<ol class="cl-progress">` from the recipe table's step bar.

## 6 · Co-host — `data-cfe-unless="SLOT"` (new in V3)

Delete the element when that slot is filled; otherwise keep it and remove the attribute. Used once: the single-host
section (`08-host`) is dropped when there is a `COHOST_NAME`, because the combined **Meet your hosts** section
(`08-hosts`, needs a photo of both: MEDIA `hosts`) takes its place.

## 7 · Media — every `data-cfe-media="key"` placeholder

For each key with a file (or link) from the client:
- **Photo** → `<img class="<the placeholder's classes>" src="…" alt="<what it shows>" data-cfe-media="key">`.
  Exception — a placeholder with class **`v3-slot`** (inside the V3 hero, thumbnails, product shot) becomes a plain
  `<img src="…" alt="">` with NO class.
- **Video link in a `.cl-video` spot** (Vimeo / YouTube / Loom / Wistia → their player iframe; .mp4/.webm → `<video
  controls playsinline preload="metadata">`) → the spot keeps its own `<div class="cl-video …" data-cfe-media="key">`
  but EVERYTHING inside it (the V3 thumbnail or hero poster, the player bar) is replaced by the player.
- **Order form / calendar / form link in a `.cl-embed` spot** → `<div class="<classes> cl-embed--live" data-cfe-media="key"><iframe src="…" title="…" scrolling="yes"></iframe></div>`.
- **One-click block** (`v3-oneclick`, key `…-upsell-block`): stays as it is — AI Studio drops its upsell block in there.

Keys with no file stay as placeholders and go on the report's media list. A block marked `data-cfe-needs-media` (the
trust row) is deleted unless EVERY key inside it has a file. Never put a stock or example photo in a client's slot.

## 8 · Optional sections — `data-cfe-optional="name"`

Delete an optional element when **every** slot inside it is empty (slots that also appear outside every optional block
— EVENT_TYPE_WORD, HOST_NAME … — don't count). With `data-cfe-requires="SLOT"` it's simpler: delete it whenever that
one slot is empty. Judge nested optional blocks on their own. Delete the outermost dropped block only.

## 9 · Fill the slots — `{{SLOT}}`

- A slot alone on its line → paragraphs: split on blank lines, each `<p>…</p>`.
- Anywhere else → inline text. In both, `**bold**` → `<strong>`, `*accent*` → `<em>` (the V3 hero hook uses `*…*` for
  its accent words); escape `<`, `>` and `&` in the client's text first.
- Inside an attribute (`href="{{CALENDAR_URL}}"`) → plain escaped text, never markup.
- `<title>` too.
- **Empty required slot** → `<mark class="cl-mark" data-cfe-missing="SLOT">[CLIENT TO SUPPLY: SLOT]</mark>` (in an
  attribute: `CLIENT-TO-SUPPLY-SLOT`). It goes on the report. Never fill a gap with an example's words.
- `{{contact.first_name}}` / `{{contact.email}}` are GHL merge fields — leave them exactly as they are.
- Links between the funnel's own pages (NEXT_PAGE_URL, NO_THANKS_URL, VIP_URL, CLOSE_URL, NO_THANKS_TO) come from the
  recipe table; live GHL URLs replace the file names once the pages are live.

## 10 · Clean up

- Delete every `<!-- @note … -->`, the template's header comment (`<!-- CASH FLOW ENGINE™ TEMPLATE …-->`) and the
  numbered section comments (`<!-- 07 · … -->`). Delete the V3 build markers `<!-- @panel:N -->` and
  `<!-- @product-shot -->` once their piece is built (`reference/v3-pieces.md`).
- No `{{` left except GHL merge fields. No `data-cfe-entry`, `data-cfe-flag`, `data-cfe-vip`, `data-cfe-unless`,
  `data-cfe-layout` attributes left.

## 11 · The kit and scripts — one self-contained file

Replace `<!-- @kit:start --> … <!-- @kit:end -->` with ONE `<style>` holding, in this order: the client's token file
(`Reference/brand-kit/tokens/<kit>.css`, else `kit/tokens/<kit>.css`) + its OVERRIDES line as
`:root, [data-surface=L] { --name: value; … }`, then `kit/blocks.css`, `kit/surfaces/page.css`,
`kit/surfaces/funnel.css`, `kit/surfaces/vipvis.css`, `kit/surfaces/v3-addons.css`, `kit/surfaces/v3-pages.css`.
Move every `@import url(…);` to the very top of that style block. Replace `<!-- @script:start --> … <!-- @script:end -->`
with ONE `<script>` holding `kit/funnel.js` then `kit/v3-anim.js` (the scroll animation — live pages only).

## The pages that stay as they were (decision 15)

event-gate · replay · application · membership · pass-close · deposit (and the legacy thank-you): only the
`cfe-v3` body class changed. No video is added to them.
