# The V3 pieces — what each one is and how to fill it

Every piece here was approved by Matthew on the board on 2026-11-11 (PLAN-V3 Steps 2–3, STATUS.md). The templates
already carry most of them; this file covers the ones you **build** for each client (panels, product shot, icons) and
the words that go in the rest. Styles: `kit/surfaces/v3-addons.css` + `v3-pages.css` — Brand Kit tokens only.

**Everything is the running client's own collateral.** Their photo, their real Event Magnet™ tool image, their
system's words, their Golden Avatar™'s name, their prices. The examples on the board (Coach Launch's Sniper Close™
pages, Holly, Dana, "Sample Clinic Growth Co.") are only examples. A missing piece shows `[CLIENT TO SUPPLY: …]`,
never an example's words or photo.

**Every promise states a RESULT, never the pain** (decision 10).

---

## 1 · The hero (registration) — in the template

One design, both entries. Left: the host photo (`host-hero` — upper body, room above the head) fading into one dark
background; only the host's name + company on it. Right: `HERO_HOOK`, `HERO_SUB`, `HERO_TAG`, and the client's REAL
Event Magnet™ tool image (`event-magnet-tool`) — big, slightly tilted, bleeding off the bottom. Never a drawn
stand-in for the tool; no rotated text; nothing laid over the photo but the name.

| Slot | What | Example (Coach Launch — shape only) |
|---|---|---|
| `HERO_HOOK` | The Event Magnet™'s RESULT in the tool's own promise words; `*accent*` on the result | `Turn your virtual room into *3–5 high-ticket clients*` |
| `HERO_SUB` | The objection it removes, one line | `Without dreading the money ask or awkward silence.` |
| `HERO_TAG` | What the tool is, short | `The one-page roadmap you'll fill in live` |

- **FREE**: the still image beside the copy (split hero). No video, ever (decision 4).
- **PAID**: video-led. The same picture is the poster of the Ticket Sales Detonator™ video, full width under the
  headline, with the play button and the player bar ("Watch this first"). The video link replaces the whole spot.
- Above the headline: `AUDIENCE_QUALIFIER` shows as a white pill — keep it SHORT (who + offer level, e.g. "coaches and
  experts selling a $3K+ offer"). Under the lede: the results-vary line (fixed).
- Host photo crop: set `style="object-position: X% Y%"` on the `<img>` so the face sits in the upper third
  (Matthew's: `58% 14%`).

## 2 · The three animated panels (registration, "the problems we solve") — you build these

Each `<!-- @panel:N -->` placeholder becomes ONE panel, built from the client's own system — the Magic Formula™ part
or Event Magnet™ step that solves problem N. Pick the panel type that shows that part best:

| Type | Shows | Body rows |
|---|---|---|
| **timeline** | a sequence / phases | `v3-tl` bar + `v3-stages` with 3–5 `v3-stage` |
| **chat** | a conversation that changes (before → after, yeses arriving) | 3–4 `v3-msg` |
| **options** | choices, tiers, the close that fits | 2–4 `v3-opt` + a `v3-note` |
| **numbers** | the maths behind a result | `v3-tl` bar + 2–3 `v3-math` + a `v3-note` |

Shell (every type):

```html
<div class="v3-panel v3-anim" role="img" aria-label="TITLE: BADGE"><div class="v3-panel__top"><span class="v3-panel__dots"><i></i><i></i><i></i></span><b>TITLE</b><span class="v3-panel__badge">BADGE</span></div><div class="v3-panel__body">
  …rows…
</div></div>
```

Rows (`style="--i: n"` = the order they animate in, from 0):

```html
<!-- timeline -->
<div class="v3-tl"><b></b></div><div class="v3-stages">
  <div class="v3-stage"><span class="v3-stage__dot" style="--i: 0">1</span><b>Who</b><span>open the loop</span></div> …
</div>
<!-- chat: --you = the host / the client, --them = the other side, add v3-msg--was for a "before" line -->
<p class="v3-msg v3-msg--them" style="--i: 0"><small>Chat</small>How do I join?</p>
<!-- options -->
<div class="v3-opt" style="--i: 0"><div><b>The ASK™ Close</b><span>They apply, book, and buy on the call.</span></div><em>60–90 min</em></div>
<!-- numbers -->
<div class="v3-math" style="--i: 0"><span>$5,000 a year</span><span>5,000 ÷ 5,000 =</span><b>1 member</b></div>
<!-- a closing line, any type -->
<p class="v3-note" style="--i: 3">The longer the immersion, the shorter the sales cycle.</p>
```

Every word comes from the client's files. A blank the buyer fills in on the day is written `___`.
Approved examples: Coach Launch (`v3-wip\make-v3-cl.ps1`, `$PANEL1–3`), Holly (`make-v3-holly.ps1`).

## 3 · The product shot (registration, above the price box) — you build this

Replace `<!-- @product-shot --><div class="cl-imgslot" data-v3="product-shot">…</div>` with:

```html
<div class="v3-shotwrap"><div class="v3-ps" role="img" aria-label="Everything in the EVENT NAME">
<div class="v3-floor"></div>
GUIDE l2 · GUIDE l1 · GUIDE r2 · GUIDE r1
<div class="v3-lap"><div class="v3-lid">COVER</div><div class="v3-base"></div></div>
<div class="v3-tab"><div class="scr img"><img src="EVENT-MAGNET-TOOL" alt=""></div></div>
<div class="v3-phn"><div class="scr"><div class="sb"><span>9:41</span><i></i><span>•••</span></div>
<p class="hi">Good <em>morning</em></p><small>PHONE LINE</small>
<div class="t"><i>1</i><div>TAKE-AWAY 1<span>short line</span></div></div> … 4 take-aways (marks 1 · ✓ · 3 · ★)
</div></div>
</div></div>
```

- **GUIDE** (4 cards behind the devices, positions `l2 l1 r2 r1`): 
  `<div class="v3-gd r2"><div class="gh"><span>COMPANY</span><u>Step 01</u></div><div class="gb"><small>EVENT NAME</small><h5>TITLE</h5><p>ONE LINE</p></div></div>`
  — the event's deliverables (Step 01–03 + Bonus).
- **COVER** (the laptop screen) = the hero picture as a cover: the hero markup with class
  `v3-hero v3-hero--still v3-hero--cover` (photo right, promise left — mirrored).
- **Tablet** = the client's real Event Magnet™ tool image. **Phone** = the buyer's week: "Good morning" (or the
  Golden Avatar™'s first name — "Good morning, Erin"), one line, the four take-aways.
- Approved example: `Shot()` in `v3-wip\make-v3-cl.ps1`.

## 4 · Icons (value stack rows + "you'll have" deliverables) — you add these

Each value-stack row: `<li><span class="v3-stackname">ICON NAME</span> <span class="cl-stack__value">…</span></li>`.
The deliverables list gets class `v3-iconlist` and each item `<li>ICON<span><strong>NAME</strong> — line</span></li>`.
ICON = `<span class="v3-ic" aria-hidden="true"><svg viewBox="0 0 24 24">PATHS</svg></span>`, picked by the item's words:

| Words | Icon | Paths |
|---|---|---|
| masterclass · workshop · challenge · live | video | `<rect x="2" y="4" width="20" height="16" rx="2"></rect><path d="m10 9 5 3-5 3z"></path>` |
| roadmap · map · plan | map | `<path d="m3 6 6-3 6 3 6-3v15l-6 3-6-3-6 3z"></path><path d="M9 3v15M15 6v15"></path>` |
| close · target · goal | target | `<circle cx="12" cy="12" r="10"></circle><circle cx="12" cy="12" r="6"></circle><circle cx="12" cy="12" r="2"></circle>` |
| token · bonus · gift | gift | `<path d="M20 12v10H4V12M2 7h20v5H2zM12 22V7M12 7H7.5a2.5 2.5 0 0 1 0-5C11 2 12 7 12 7zM12 7h4.5a2.5 2.5 0 0 0 0-5C13 2 12 7 12 7z"></path>` |
| moment · fast · energy | zap | `<path d="M13 2 3 14h9l-1 8 10-12h-9z"></path>` |
| anything else | list | `<path d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01"></path>` |

## 5 · Hosts — in the template

**The hosts are always ONE section — the standard; never ask about it** (Matthew 2026-11-11). One host → the host
section. **A co-host → the ONE "Meet your hosts" section**. Separate host + co-host sections only when the operator
specifically asks for them (then use the `08-host` + `09b-cohost` pair from the original page library,
`v3-wip/source-templates/registration.html` in the workspace). The combined section: one photo of both
(MEDIA `hosts`) on the left, 481 px wide; `HOST_NAME & COHOST_NAME`; `HOSTS_TAGLINE` (one line true of both);
`HOSTS_BIO` (their two stories, then what they built together — only facts from the two bios); `HOSTS_MARKER_1–4`
(a figure that belongs to one host says so: "Matthew has delivered…"). Third person throughout.

## 6 · Upsell pages — in the template (decisions 11–13)

Warning bar "Important: Do Not Close This Window Or Click The 'Back' Button" · the logo · progress Checkout
(free: Registration) ✓ · Almost complete… · Complete · one headline "Your Order (free: Registration) Is Not Yet
Complete. *Please Watch This Important Message Below.*" · the video · "To Access Your Purchase (free: Seat): Please
watch this short message from HOST_FIRST_NAME right now". Nothing else above the video. **No countdowns.**
Checkout: free event → the VIP page (and a downsell) keeps its cart; paid event → VIP and every offer after it are
one-click (`v3-oneclick` — AI Studio's upsell block). PASS™ and Upsell 2 are always one-click.

Logo: `<div class="v3-logo"><i>COMPANY_INITIALS</i>COMPANY</div>`; with a logo file, replace the `<i>` and the name with
`<img src="LOGO" alt="COMPANY" style="height: 34px">`.

## 7 · Confirmations + the Ask Campaign — in the template

Logo · progress complete (green) · pill "Your order is confirmed · welcome to VIP" / "Your seat (paid: ticket) is
confirmed · welcome aboard" / "Your seat is saved · welcome aboard" · headline "Check Your Email in the Next *Few
Minutes* for Your Access / Your Joining Details" · "While you wait, watch this short message from HOST_FIRST_NAME." ·
the video. Seat confirmed also gets them to SHOW UP (decision 14): calendar, community, why live matters — its video
(Authority Detonator™ C, no-upgrade) carries that and the last VIP re-pitch.

## 8 · Video thumbnails — in the template

Every host video spot after the front page shows the thumbnail v2 (chip · two-tone title · one line · "with HOST_NAME" ·
play button · the host photo card `host-avatar` · badge) until the real video goes in. The words are fixed per page
type in the template. Which page gets which video script: `reference/recipes.md` → "Videos".

## 9 · The Design board (when the operator wants one)

The board is for EDITING (Matthew 2026-11-11): every artboard is static and full height so every section and image can
be seen and clicked. Board copies: no `v3-anim.js` (nothing waits for a scroll), no `loading="lazy"`, artboard height =
the page's full height at 1280 wide (measure it; a V3 registration page is ~17,000–21,000 px, never cap at 8,000).
Images go up once as board assets and are referenced (`/_blob/…`), never embedded. `kit\to-dc.ps1` makes an artboard.
Keep each funnel stack ONE sample client end to end; a model page sits apart, to the left (x −2000).
