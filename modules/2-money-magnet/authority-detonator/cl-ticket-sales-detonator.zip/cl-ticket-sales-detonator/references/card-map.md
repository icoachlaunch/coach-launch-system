# Card map — where every line comes from

The SCORE™ Card is the content. The SCORE™ Framework is the shape. The dream outcome (S-1, R-3, R-4) is
what's being sold in every section; the event and the tool are the vehicle, and the ticket is the first
step. This file maps one onto the other, so every moment knows which blocks to draw from. Use the client's
blocks; adapt them for speech (shorter sentences, direct to camera, their voice); never change their
meaning or add to them.

## The SCORE™ Card — 5 acts, 19 blocks

| Act | Blocks |
|---|---|
| **1 · Serendipity** | S-1 $Million Promise™ Anchor · S-2 Question · S-3 Symbolism · S-4 Debunking |
| **2 · Connection** | C-1 3 Problems · C-2 $Million Moment™ Story · C-3 Credibility Anchors |
| **3 · Opportunity** | O-1 System Reveal · O-2 Core Differentiator · O-3 Client Proof |
| **4 · Reality** | R-1 Consequence of Inaction · R-2 Limits · R-3 Reward · R-4 Desire |
| **5 · Execution** | E-1 2 Ways · E-2 Hard Choice · E-3 Because · E-4 FOMO · E-5 CTA |

Older Cards may call Act 4 "Risk/Reward"; it's the same act (Reality). A founding-stage Card's O-3 may be a
"Founding Client Opportunity" and says it is **not proof** — treat it as no client proof yet: fill the
proof slots with sourced industry data, or `[PROOF NEEDED]` if none exists. If a block is thin or missing,
write that line thin and say so in the chat. Never pad it.

## The five sections

| Section | Act | Draw from | Notes |
|---|---|---|---|
| 1 · The Hook | Serendipity | One of S-2 / S-3 / S-4 / C-2 / Golden Avatar™ words / sourced data for the opening line · Golden Avatar™ (the call-out) · **S-1** (the promise) · S-4 (the hint) · one O-3 result | Open on them or on a person, never a greeting. Hint the big idea, never say it |
| 2 · The Problem + My Story | Connection | **C-1** (the three questions, in the avatar's words) · **C-2** (the host's story as a scene) · **C-3** (the hardest number, then every credential with a benefit) | Host proof only. Loop A and Loop B open here |
| 3 · The Real Reason + The Day | Opportunity | **O-3** (the client story as a scene) · **S-4 / O-2** (the twist) · the big idea (the real reason) · the event name · the Event Magnet™ Spec (tool name, A3 pieces, A4 hero, A5 map) · **O-1** — the system's name and the map line only · a second O-3 result or sourced research | Both loops close. No how, no steps |
| 4 · The Picture | Reality | **R-1** · **R-2** (a different case or sourced data) · **R-3** (the three Imagine lines) · **R-4** · the big idea | Picture before price |
| 5 · The Ticket | Execution | The Money Model (event format, length if fixed, the ticket price) · the ticket page (what's included, the guarantee) · the operator (the anchor, the reason, any real cap) · **E-1 / E-2** (two paths) · **E-3** (because) · E-4 only if genuine · the best remaining proof | One action: buy the ticket. **E-5 is the core offer's CTA — read it for its shape, never use its offer** |

**The proof map — each proof once.** First proof (Section 1) · host proof — C-3 and every credential in the
assets (Section 2) · the client story (Section 3) · system proof (Section 3) · "someone like you", R-2
(Section 4) · the strongest proof, last (Section 5). No client results yet → real, sourced industry data in
the system-proof and R-2 slots (sources in the chat). Never repeat a result across sections, except one
callback to the client story at the end.

**Proof matches what they're buying.** For every result, know where it came from: the event or tool
itself, or the client's coaching / program / done-for-you work. Say it as it is ("one of our coaching
clients"). Never imply the ticket alone produced a coaching result.

**Trust the folders.** Everything in the client's folders counts as verified, including lines an older
asset tagged `[VERIFY]` or `UNVERIFIED`. Use it.

## The big idea

Usually S-4 (the debunk) turned into the truth, or O-2 (the core differentiator) said as the reason they're
stuck. One sentence for the brief; a 3–8 word line for the script ("You don't need more leads. You need a
system."). It must be true to the Card — never a new claim.

## The other assets

- **Event Magnet™ Spec** — A1 title and object name · A3 the pieces (panels) · A4 the hero/result panel ·
  A5 the system map · B2 walk-away ("for the first time…") · B4 the open question · B6 the one-liner.
  Teaching points (B3) are never used. An older Spec that describes the tool in prose still works.
- **Money Model** — event format and length (only if fixed) · paid · the ticket price · the close (never
  pitched).
- **The paid ticket page** (`Client Engine/Money Magnet/cash-flow-engine/`) — the price as sold, what the
  ticket includes, the guarantee, the headline the video should match. If it carries an early-bird line, a
  countdown that isn't real or a different price, list the page edit for the Funnel Builder.
- **The Golden Avatar™** — the call-out, their exact words, the "this won't work for me" belief (R-2).
- **What reads this script next:** the Authority Detonator™'s paid branch (VIP upsell, downsell, PASS /
  Upsell 2, confirmations) takes its big idea and line, its three struggles and its spent proof from here.
  Keep the line word for word each time it's said, so it carries on cleanly.
- **Brand Voice** — sentence length, power words, banned words, "Speaks as" (I / we).

## Names that exist (use exactly, with ™)

The $100K Day Engine™ · The $100K Day Accelerator™ · Offer Matrix™ · Money Magnet™ · Client Flywheel™ ·
$Million Story™ · $Million Promise™ · The Golden Avatar™ · $Million Moment™ · Magic Formula™ · Red Diamond
Offer™ · The Sniper Close™ · Sniper Presentation™ · Cash Flow Engine™ · Cash Flow Max™ · Genie X Converter™ ·
Goliath Content™ · Pixie Dust Social™ · Dragon Fire Ads™ · Event Magnet™ · SCORE™ Card · SCORE™ Framework ·
The Authority Detonator™ · The Ticket Sales Detonator™ · Coach Launch Academy™. Plain names: the Money
Model, the Enrollment Doc, Brand Voice, Business Brand Profile, Visual Style Guide. Phases: Launch ·
Execute · Growth · Mastery. Say masterclass, workshop or challenge — whichever the Money Model says.

The mechanics in this skill (the two loops, the big idea and its line, scenes, the anchor) are plain
copywriting words, not brand names. Never label them on camera, and never borrow a name for them from
another program.
