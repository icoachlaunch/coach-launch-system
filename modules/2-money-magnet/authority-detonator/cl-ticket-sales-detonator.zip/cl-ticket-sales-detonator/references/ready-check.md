# Check, score and the document

Everything in this file is said **in the chat**, never written into the client's document.

## 1 · Runtime check

Count the words; at about 150 a minute, give the minutes. The band is 5–8 minutes (750–1,200 words);
target ~1,050. Give the host's story's share of the whole (aim ~15%).
- **Short** → the material is thin: ask one more question (a story detail, a client result), never pad.
- **Long** → trim transitions, then the client story to its turn, then the question stack to two
  questions. Never cut a loop's close, the anchor, the price, the guarantee or the one action.

## 2 · The structure check

- **Loop A** opens at the one thing (Section 2) and closes at the real reason (Section 3) ✓
- **Loop B** opens inside the host's story ("until I noticed…") and closes at the reveal (Section 3) ✓
- Both loops close **before the price** ✓
- **The big idea's line** is hinted (never said) in Section 1, said in full first at the real reason, then
  word for word 4–6 times in all, and is the last idea they hear ✓
- **The three struggles** are named in the question stack ✓
- **Every section ends pulling into the next** ✓
- **The picture comes before the price** ✓

## 3 · The Ready Check — every line must pass

0. **Sells the outcome.** Every promise leads with the dream outcome (S-1, R-3, R-4); the event and the
   tool are tied to what they get them. The tool is named by what it does, never sold as a worksheet.
1. **Calls them out.** The first line is about the viewer or a real person, not a greeting. A choice of
   openings (at least four styles) was offered. Each split-test version is a complete Section 1.
2. **The stories are scenes.** The host's story and the client story each have a real person, a real
   day, what they tried, how it felt and the turn — every detail from the client's folders.
3. **Shows, never teaches.** No maths, worked examples, teaching headlines or Magic Formula™ steps.
4. **Nothing released early.** "What you'll get when you show up" is there; no download, inbox or
   print-it steps.
5. **The price is straight.** Anchor → exact price → honest reason → guarantee, in that order. The price
   matches the Money Model and the ticket page. The anchor came from the client's material or the
   operator — never an invented value. Under $100.
6. **Guarantee present** — the client's own, or the Coach Launch default (and the chat says so).
7. **Urgency is real or absent.** No early-bird, no price rise, no countdown unless confirmed real.
8. **Proof slots filled and matched.** First proof, host proof, the client story, system proof, R-2 and
   the last proof are six different pieces (one callback allowed). Each says where the result came from;
   none implies the ticket alone produced a coaching result. Gaps filled with sourced data, sources in the
   chat; `[PROOF NEEDED]` only where none exists.
9. **One action.** Buy the ticket — the button right under this video. No VIP, no replay (unless the
   ticket includes one), no core offer, never "upsell". Ends on an instruction, then the line.
10. **Evergreen.** No date, time, time zone or weekday for the event.
11. **Voice mix.** "I" only in the host's story and credentials; "we" for the event, team and method;
    "they / them" for the people the host helps.
12. **Every claim traces** to the client's folders, the operator, or a cited source. Nothing the event or
    tool can't physically deliver. Regulated niches: results are what real people got, never what the
    viewer will get. No other client's material.
13. **Sounds spoken, inside the length** (or over it as a recorded operator call).
14. **Sounds like the client, not the framework.** Sentence length matches the Brand Voice (no clipped lines
    if it says full sentences) · its signature moves used where they fit (its "I get it" pivot, one picture
    per section, threes, CAPS per beat, its peak phrase) · zero banned words (scan for them) · its own names
    for its system, tool and event · the credentials in the form its Reference docs require (e.g. combined
    figures only as "we").

Any ✗ → fix it in its section and re-run. **Operator calls** — lines the operator chose to keep — are
listed separately and are not failures.

## 4 · The SCORE™ score — per act, 1–5

Score against the `cl-score-framework` rubric, one line of reason per act:

| Act | Where | The question |
|---|---|---|
| Serendipity | Section 1 | Would a cold viewer see themselves in the first line and stay? (Score each split-test version.) |
| Connection | Section 2 | Do the questions name their struggles, and does the host's story land as a scene with a real turn? |
| Opportunity | Section 3 | Do both loops close, does the client story prove it travels, and is the outcome sold through the tool with no how? |
| Reality | Section 4 | Does staying put now feel more costly than the ticket? |
| Execution | Section 5 | Anchor, price, honest reason, guarantee, two paths, one action — and an instruction to end? |

21–25 ship · 16–20 tighten any act at 3 · 11–15 rebuild weak acts · 10 or below back to the Card.
**Floor rule:** any act at 2 or below doesn't ship. Score honestly, operator overrides included — but list
those as operator calls.

Then list in the chat: research sources used · every `[PROOF NEEDED]` / `[PROVISIONAL]` line · the default
guarantee if used · page edits for the Funnel Builder (early-bird line, fake countdown, price mismatch,
download step, promised replay) · upsell scripts written before this one that need a re-run ·
anything still to confirm.

## 5 · The document (client-facing only)

```
# 🎬 YOUR TICKET SALES DETONATOR™ SCRIPT — [Event name]
*About [N] minutes. Read it aloud. Record it in one take.*

---

**SECTION 1 · THE HOOK** [0:00 – 0:XX]
[spoken words]

**SECTION 2 · THE PROBLEM + MY STORY** [0:XX – X:XX]
[spoken words]

**SECTION 3 · THE REAL REASON + THE DAY** [X:XX – X:XX]
[spoken words, with [SHOW THE TOOL] and the [POINT …] directions]

**SECTION 4 · THE PICTURE** [X:XX – X:XX]
[spoken words]

**SECTION 5 · YOUR TICKET** [X:XX – X:XX]
[spoken words]

**END OF SCRIPT**

---

## 🎬 SPLIT-TEST OPENINGS  (only when the operator chose to test)
*Record Section 1 once per version. Same script after it.*

**SECTION 1 · VERSION B** [0:00 – 0:XX]
[spoken words]

**SECTION 1 · VERSION C** [0:00 – 0:XX]
[spoken words]

---

## 🎥 RECORDING NOTES
[the recording notes — add: "Split test: record each Section 1 version as its own take."]
```

**Never in the document:** act labels or SCORE™ terms, loop or big-idea labels, "built from", runtime,
score, Ready Check, flags, research notes, filename, this skill's version. The client only sees what they
act on: `[PROOF NEEDED]`, `[PROVISIONAL]` and the stage directions.
