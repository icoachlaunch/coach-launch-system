# The Ticket Sales Detonator™ sections

Five spoken sections on the SCORE™ Framework's five acts, with two open loops and one big idea running
through them. The templates are shapes, not scripts: fill every bracket from the client's own blocks (see
`card-map.md`) in their voice, using the I / we / they mix. Stage directions sit in `[SQUARE BRACKETS,
CAPS]` and stay format-neutral — they work whether the client films on camera, over slides, or both.
Every line sells the dream outcome; the ticket is the first step to it.

**Contents:** Timing guide · The moment map · 1 The Hook · 2 The Problem + My Story · 3 The Real Reason +
The Day · 4 The Picture · 5 The Ticket · Recording notes

## Timing guide (5–8 min, ~750–1,200 words; target ~1,050)

| Section | Share | Words at ~1,050 | Notes |
|---|---|---|---|
| 1 The Hook | ~10% | ~100 | never cut the first line |
| 2 The Problem + My Story | ~25% | ~270 | the host's story is ~15% of the whole video on its own |
| 3 The Real Reason + The Day | ~30% | ~320 | the client story, the reveal, the tool |
| 4 The Picture | ~15% | ~160 | images, not adjectives |
| 5 The Ticket | ~20% | ~200 | never cut the anchor, the price, the guarantee or the action |

Over length → trim transitions first, then the client story to its turn, then the question stack to two
questions. Never cut a loop's close, the price order, the guarantee or the one action. Under 750 words →
the material is thin: ask one more question in Step 2, never pad.

## The moment map — what happens where

| # | Moment | Section | Loop / big idea |
|---|---|---|---|
| 1 | The opening line | 1 | big idea **hinted** |
| 2 | The call-out | 1 | |
| 3 | The promise | 1 | big idea **hinted** |
| 4 | First proof | 1 | |
| 5 | The question stack | 2 | |
| 6 | The one thing | 2 | **Loop A opens** |
| 7 | My story — a scene | 2 | **Loop B opens** ("until I noticed…") |
| 8 | The hardest number | 2 | |
| 9 | Someone just like you — a scene | 3 | |
| 10 | The twist | 3 | |
| 11 | The real reason | 3 | **Loop A closes** · big idea said in full (1st) |
| 12 | The reveal: the day + the tool | 3 | **Loop B closes** · big idea (2nd) |
| 13 | What the tool does for them | 3 | |
| 14 | It works for people like them | 3 | |
| 15 | Until this changes | 4 | |
| 16 | "This won't work for me" | 4 | |
| 17 | Imagine × 3 | 4 | |
| 18 | Who they become | 4 | |
| 19 | The recap | 4 | big idea (3rd) |
| 20 | The day in one breath | 5 | |
| 21 | Anchor → price → reason | 5 | |
| 22 | The guarantee | 5 | |
| 23 | The strongest proof, last | 5 | |
| 24 | Two paths | 5 | big idea (4th) |
| 25 | The one action | 5 | big idea (5th, the last idea they hear) |

At moments 1 and 3 the big idea is **hinted** — the frame ("it's not another course"), never the answer
and never the line itself, or Loop A is spoiled. The line is said in full first at 11, then word for word
4–6 times in all.

**The proof map — each proof once, in its own place.** First proof (4) · host proof (8) · the client
story (9) · system proof (14) · "someone like you" (16) · the strongest proof (23). Six different pieces;
the only repeat allowed is one callback to the client story at 23. Few pieces → sourced industry data or
the one metaphor the opening set up; never the same result three times.

---

## Section 1 · The Hook — Serendipity

**Job:** a cold viewer decides in the first line whether to stay. Make them see themselves.

**Shape:** the opening line → the call-out ("If you're a [who] who [the behaviour they keep repeating],
don't skip this.") → the promise: S-1's outcome, with the event named as the way to it (not explained) and
the big idea hinted → one result, made human in two lines (who + what changed).

**The opening — a choice, never a default.** Write at least four, one per style, each labelled:

| Style | Draws on | Fits when… |
|---|---|---|
| **Question** | S-2 | the audience is already asking it themselves |
| **Debunk** | S-4 | they keep repeating a fix that doesn't work — sets up the big idea |
| **Symbol** | S-3 | the metaphor can carry the whole video (then it's the only one used) |
| **Mirror** | Golden Avatar™ words | their exact current state is vivid and specific |
| **Promise** | S-1 | the outcome itself stops them |
| **Chance moment** | C-2 or the client story | a turning point that mirrors their pain — opens on a person and a day |
| **Real statistic** | sourced research | a striking, real, cited number exists |

For cold traffic, the chance moment and the mirror usually win: a real person on a real day, before any
claim. Say which you'd pick and why, then let the operator choose — or **split-test**. Each split-test
version is a **complete Section 1** (first line through first proof) that hands off to the same Section 2.

> "[Opening line.]
>
> If you're a [who] who [the behaviour they keep repeating], don't skip this video.
>
> Because in the next few minutes, we're going to show you how [S-1's outcome, in their words] — without
> [the fear or the failed fix]. And it's not [the thing they expect — hint the big idea, never the answer].
>
> [Name] was [where they were]. [One line: what changed, with the number.]"

**Rules:** no greeting first, no "in this video I'm going to talk about…", no date, no price yet.

---

## Section 2 · The Problem + My Story — Connection

**Job:** "this person gets me — and they've been where I am."

**Shape:**
1. **The question stack** — three "why" questions in the avatar's words, from C-1: (1) the main problem
   the event solves · (2) all three struggles, named · (3) what's missing — the bridge to the real reason.
   > "Why is it that [main problem]? Why do you [struggle 1], [struggle 2], and still [struggle 3]? And
   > why does nothing you've tried actually stick?"
2. **The one thing — Loop A opens.** Tease only:
   > "It's because of one thing most [who] have never thought about."
3. **My story — a scene, ~15% of the video (C-2).** Where they were → what they tried (their failed
   fixes, by name) → the low point, felt (what they said out loud, the number on the screen) → **"until I
   noticed…" — Loop B opens** → the result. Close on a line that pulls forward:
   > "It wasn't a better [plan / course / ad]. It was one thing I didn't believe until I tested it."
4. **The hardest number (C-3)** — one line, earned by the story. Every other credential the assets carry
   follows in one or two lines, each with what it means for the viewer. The client can cut.

**Rules:** "I" lives here. Host proof only. Don't name the one thing yet.

---

## Section 3 · The Real Reason + The Day — Opportunity

**Job:** close both loops, reveal the day and the tool, and prove it travels.

**Shape:**
1. **Someone just like you — a scene (O-3).** "Then we tried it with someone just like you." One client:
   who they were, a real day, what they'd tried, how it felt, the moment they nearly quit, the one thing,
   life now. Shorter than the host's story. Say plainly where the result came from (coaching, the
   program) — never imply the ticket alone produced it.
2. **The twist (S-4 / O-2).** What works is different from what they've been told:
   > "Here's what nobody tells you. [The debunk, as a truth.]"
3. **The real reason — Loop A closes.** The big idea, said in full for the first time:
   > "You don't have a [their blame-word] problem. [THE LINE.]"
4. **The reveal — Loop B closes.** What the host noticed, packaged:
   > "That's why we built [tool name], and that's exactly what we do at [event name]. [THE LINE, again.]"
   `[SHOW THE TOOL]` — then what it does for them, as outcomes:
   > "This is the one-page [tool name] that turns [what they already have] into [the two or three things
   > it produces, as outcomes]. It's step [X] of [N] in [system name]. And this is what you'll get when
   > you show up — we fill it in together, live."
5. **What it does for them** — up to three pieces, `[POINT AT THE PIECE]` for each, one line per piece on
   what it gets them. Never how.
6. **It works for people like them (O-3 / research)** — a different result, or real sourced industry data
   that backs the twist ("A study of nearly 1,000 [profession] found that…"). Sources in the chat.

**Rules:** no maths, no worked example, no teaching headline. The Magic Formula™'s steps are never named;
the map line only.

---

## Section 4 · The Picture — Reality

**Job:** staying where they are should now feel more costly than $[price]. Truth, not pressure.

**Shape:**
1. **Until this changes (R-1)** — "And until that changes, [the pain] keeps [its verb]." Felt, specific,
   their life a few months on.
2. **"This won't work for me" (R-2)** — the belief in the way, answered with someone like them: a
   different client case, or sourced data.
3. **Imagine × 3 (R-3)** — three "Imagine…" lines, each with a when and something they'd see, hear or feel:
   > "Imagine next Monday at 9am: [what they see]."
   Every "Imagine…" stays imagine — never flattened into a claim or a guarantee of results.
4. **Who they become (R-4)** — one or two lines on the identity they want.
5. **The recap** — the big idea, landed:
   > "It was never about [the broken path]. It's about [the one thing]. [THE LINE.]"

**Rules:** images, not adjectives. No replay mention. No invented urgency. The picture always comes
before the price.

---

## Section 5 · The Ticket — Execution

**Job:** make buying the ticket the obvious next step, and say the price straight.

**Shape, in order:**
1. **The day in one breath** — the live [event], its length if fixed, what we build together, the tool
   ("what you'll get when you show up"). The full detail is on the page.
2. **Anchor → price → reason (Money Model / operator):**
   > "[The anchor — what the day is worth or what it replaces.] Your ticket is $[exact price]. [The
   > honest reason it's priced that way.]"
   No anchor in the assets and none from the operator → "what it replaces" in plain words, never a value.
3. **The guarantee — always.** The client's own, or the Coach Launch default:
   > "Show up, do the work with us, and if you don't feel you got 10 times the value of your ticket,
   > email us and we'll refund every cent. You've got nothing to lose."
4. **The strongest proof, last** — the best remaining piece, or one callback to the client story.
5. **Two paths (E-1 / E-2)** — keep [the broken path], with its cost felt — or [the one thing]. End on
   the line.
6. **The one action (E-3, E-5's shape, never its offer):**
   > "If you're ready to stop [the pain], your next step is [event name]. Click the button right under
   > this video and grab your ticket. [A real seat cap only if confirmed.] [THE LINE.]"

**Rules:** one price, said once with the anchor and once on the button line at most. No early-bird, no
price rise, no countdown unless the operator confirms it's real. No VIP, no replay, no core offer. Ends
on an instruction, then the big idea.

---

## Recording notes (go in the document after the script)

Short and format-neutral — the client films it however they like.

- **The tool.** `[SHOW THE TOOL]` and `[POINT AT THE PIECE]` mean the printed tool in hand, or its image
  on screen — whichever you're using. Show the whole page before pointing.
- **The price.** Say it plainly and keep going. If you're using slides, put the anchor, the price and the
  guarantee on screen as you say them.
- **The button.** "Right under this video" — point down, or show an arrow.
- **No date.** Said one by habit? Re-take the line.
- **The stories are scenes.** Slow down in them. They're the part people remember.
- **One take is fine.** Eyes on the lens, a pause is fine, an "um" is fine.
