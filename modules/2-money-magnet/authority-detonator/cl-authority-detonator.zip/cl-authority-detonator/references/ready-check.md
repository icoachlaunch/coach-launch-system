# Check, score and the document

Everything in this file is said **in the chat**, never written into the client's document.

## 1 · Runtime check

Count the words; at about 150 a minute, give the minutes. Free-branch Detonators 5–12 min (750–1,800
words) · paid VIP upsell and PASS / Upsell 2 6–7.5 min (950–1,150) · downsell ~1 min (150–250) · buyer
confirmation 1–2 min (150–300) · no-upgrade 2–4 min (300–600). Free branch: short → add to Section 4 or a
sharper Reality image, not more of the host; long → trim transitions, then Section 2's story to its turn.
Paid branch: short → give the time to "What it takes" / "Each missing piece" and "How it works", never to
the story; long → trim the recap, then "How it works" to one line per piece. Never cut a pain, an offer
term, the guarantee, the clean no or the one action. When in doubt, shorter.

## 2 · The Ready Check — every line must pass

0. **Sells the outcome.** Every promise leads with the dream outcome (S-1, R-3, R-4); the tool, components
   and next steps are tied to what they get them. Section 3 names the tool once and never speaks the Spec's
   title as the promise.
1. **Calls them out.** The first line is about the viewer, not a greeting. A choice of openings (at least
   four styles) was offered. Each split-test version is a complete Section 1 that hands off cleanly to
   Section 2 (with its own Section 2 closing line if its contrast needs one).
2. **Evergreen.** No date, time, time zone or weekday for the event or the live component ("the day
   after"). The time is "on this page and in your inbox".
3. **Nothing released early.** "This is what you'll get when you show up" is there; no download, inbox or
   print-it steps; confirmation videos say "everything else gets released on the day".
4. **Section 4 teaches nothing** (free-branch Detonators; in the paid branch, "How it works" never teaches the how either). 3–4 pains, each: the moment → the emotional consequence →
   a point → a breakthrough line. No maths, examples, teaching headlines or "I'll be showing you how";
   at most one hook-style reveal line. The dream picture, the map, the hinge and the bring item follow. No
   new metaphor beyond the one the opening set up.
5. **Proof slots filled.** System proof (Section 4) and "someone like you" (Section 5): a real client
   result, or real sourced industry data with the source given in the chat. `[PROOF NEEDED]` only where no
   credible data exists. Host proof in Section 2 — every credential the assets carry.
6. **Voice mix.** "I" only in the host's own story and credentials; "we" for the event, team and method;
   "they / them" for the people the host helps and the two groups.
7. **One action, matching the page.** Show-Up: be there live. VIP: the upgrade button (+ the clean no).
   Buyer: the next steps. No-upgrade: next steps, then the upgrade button. Ends on an instruction. Never
   the core offer, never the word "upsell".
8. **Guarantee present** (VIP, VIP upsell, PASS / Upsell 2 and no-upgrade videos): the client's own or the
   Coach Launch 10X default.
9. **Money and scarcity are honest.** Show-Up: no price. VIP: the offer's value, price, terms; "normally
   $X" only with the operator's past price; cap, countdown, deadline or "VIPs win" only if confirmed.
10. **Every claim traces** to the client's folders, the operator, or a cited source. Nothing the tool or
    offer can't physically deliver. No other client's material.
11. **Sounds spoken, inside the length.**

**The paid branch — also check (D, E, F, and C after a ticket):**

12. **Already sold.** No hook-and-story opening, no tool tour, no pains toured on the tool. The host's story
    appears as one line at most. The big idea's line from the ticket script is said back once.
13. **Nothing repeated, nothing contradicted.** The ticket script and every approved script in the funnel
    were read. No proof piece is reused across the funnel (one callback to the ticket's client story
    allowed). No line lifted out of the ticket script's story.
14. **Proof matches what's sold.** VIP parts use VIP results, PASS parts PASS results; no ticket or
    coaching result passed off as an upsell result. Nothing real → the proof part is out, and the chat
    says so.
15. **No earlier purchase assumed.** F never assumes the VIP; E speaks only to someone who just said no.
16. **The downsell is honest.** $100+: the same offer, said as "[N] payments of $[amount]", never "the same
    price" unless the maths is exact. Under $100: a lower price, with what's in and what's out named, and
    the cut taken from the offer or the operator. Nothing after the ask implies access.
17. **The order is right.** D: you're in → before you go → what it takes (the ticket ticks one off) → who
    this is for → the VIP → how it works → imagine → proof → value, past price, price, guarantee, only-here
    if true → one button, the clean no, "either way". F: no order recap; the takeaway before the reveal.
18. **The landing pages fit.** A payment-plan VIP buyer goes to VIP-confirmation; a cut-down buyer to
    seat-confirmed, where the no-upgrade video acknowledges what they took.

Any ✗ → fix it in its section and re-run. **Operator calls** — lines the operator chose to keep — are
listed separately and are not failures.

## 3 · The SCORE™ score — per act, 1–5

Score against the `cl-score-framework` rubric, one line of reason per act:

| Act | Where | The question |
|---|---|---|
| Serendipity | Section 1 | Do they see themselves in the first line? (Score each split-test version.) |
| Connection | Section 2 | Real turning point, problems as facts, every credential with a benefit? |
| Opportunity | Sections 3–4 | The outcome sold through the tool, the pains toured to breakthroughs, one argument, real or sourced proof, no how? |
| Reality | Section 5 | Does staying put (A) or note-taking (B) now feel more costly than acting? |
| Execution | Section 6 | One obvious action, a true reason, the guarantee, the barriers removed, an instruction to end? |

**Paid branch (D and F)** — score by part, same rubric:

| Act | Where (D · F) | The question |
|---|---|---|
| Serendipity | D 1–2 · F 1 | Does the decision feel celebrated (D), and does the turn make them stay? |
| Connection | D 3–4 · F 2–4 | Is the missing piece named in their words, with what it costs them, and does the qualifier let the wrong people go? |
| Opportunity | D 5–6 · F 5–7 | Is the offer sold by what each piece gets them, never how? |
| Reality | D 7–8 · F 8–9 | Does the picture make the next step feel worth it — with only real proof? |
| Execution | D 9–10 · F 10–12 | Value, price, guarantee and only-here in order and true, one button, the clean no? |

The downsell (E) isn't scored by act — it passes when the Ready Check (especially #16) passes and it reads
in about a minute.

21–25 ship · 16–20 tighten any act at 3 · 11–15 rebuild weak acts · 10 or below back to the Card.
**Floor rule:** any act at 2 or below doesn't ship. Score honestly, operator overrides included — but list
those as operator calls.

Then list in the chat: research sources used · every `[PROOF NEEDED]` / `[PROVISIONAL]` line · the default
guarantee if used · page edits for the Funnel Builder · anything still to confirm.

## 4 · The document (client-facing only)

```
# 🎬 YOUR AUTHORITY DETONATOR™ SCRIPT — [Event name] · [Show-Up video / VIP video]
*About [N] minutes. Read it aloud. Record it in one take.*

---

**SECTION 1 · HOOK + WELCOME** [0:00 – 0:XX]
[spoken words]

**SECTION 2 · THE PROBLEM + WHO I AM** [0:XX – X:XX]
[spoken words]

**SECTION 3 · MEET THE TOOL** [X:XX – X:XX]
[spoken words, with [HOLD UP THE PRINTED TOOL]]

**SECTION 4 · THE PAINS, ON THE TOOL** [X:XX – X:XX]
[spoken words, with the [POINT …] directions]

**SECTION 5 · [WHY LIVE / THE VIP]** [X:XX – X:XX]
[spoken words]

**SECTION 6 · ACTION** [X:XX – X:XX]
[spoken words]

**END OF SCRIPT**

---

## 🎬 SPLIT-TEST OPENINGS  (only when the operator chose to test)
*Record Section 1 once per version. Same script after it.*

**SECTION 1 · VERSION B** [0:00 – 0:XX]
[spoken words]
[If Section 2's closing line changes for this version: **Section 2 closing line for Version B:** "…"]

**SECTION 1 · VERSION C** [0:00 – 0:XX]
[spoken words]

---

## 🎥 SHOT NOTES
[the shot notes — add: "Split test: record each Section 1 version as its own take, same framing."]
```

Confirmation videos use the same shape with their own title and the beats' timing markers.

**Paid branch:** the same shape, with the job's parts as the section headings (D: **YOU'RE IN · BEFORE YOU
GO · WHAT IT TAKES · WHO THIS IS FOR · MEET THE [VIP NAME] · HOW IT WORKS · IMAGINE · [VIPS] · THE OFFER ·
YOUR NEXT STEP**; F likewise, from its twelve parts). Titles: "🎬 YOUR AUTHORITY DETONATOR™ SCRIPT — [Event
name] · VIP upsell video" · "· [VIP / PASS / Upsell 2] downsell video" · "· [PASS name / Upsell 2 name]
video". A part left out (no real proof, no only-here) simply isn't in the document.

**Never in the document:** act labels or SCORE™ terms, placement or phase, "built from", runtime, score,
Ready Check, flags, research notes, filename, this skill's version. The client only sees what they act on:
`[PROOF NEEDED]`, `[PROVISIONAL]` and the stage directions.
