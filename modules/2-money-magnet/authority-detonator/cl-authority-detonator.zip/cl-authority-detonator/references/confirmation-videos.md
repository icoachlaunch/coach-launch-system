# The confirmation videos (job C) — both branches

Two short videos, written as a pair, one per confirmation page. The viewer has just watched the VIP video
(free branch: the 5–12 minute VIP Detonator; paid branch: the ticket video, then the VIP upsell and any
downsell, PASS or Upsell 2) and made their decisions; these videos respect them. Same rules as the Detonators: evergreen,
numerals, the outcome sold (never the deliverable), the I / we / they voice mix ("it means a lot to us",
"join us on WhatsApp"), nothing released before the day. One beat per SCORE™ act; the audience is **hot**,
so the weight sits on Reality and Execution.

| | **Buyer** (took the VIP or an offer) | **No-upgrade** (took nothing) |
|---|---|---|
| Page | VIP-confirmation · the buyer thank-you page | Seat-confirmed · the no-upgrade thank-you page |
| Length | **1–2 min** (150–300 words) | **2–4 min**, never over 4 (300–600 words) |
| Job | Celebrate the decision, what it gets them, the next steps | Confirm the seat warmly, next steps, one last real chance to upgrade |

**Pages carry the basics only:** calendar, email, community, WhatsApp, the +1 invite. Both scripts say
"Everything else gets released on the day." If a page shows download or "print it" steps, or a video note
that doesn't fit the job (e.g. "welcome, no selling, 60–90 sec" on the no-upgrade page), list the page edits
for the Cash Flow Engine™ Funnel Builder in the chat. A funnel with one shared thank-you page → write
both, flag the split. Phase 1 has no confirmation video.

**In the paid branch, write these last.** Read the ticket script and every approved upsell and downsell
script first, so nothing is repeated and no proof is reused (one proof map across the funnel).
- **Who lands where:** a VIP buyer — including a payment-plan VIP buyer (the $100+ downsell is the same VIP)
  — lands on VIP-confirmation. Everyone else, including a cut-down downsell buyer and anyone who took only
  a PASS or Upsell 2, lands on seat-confirmed. If the funnel routes a payment-plan buyer to seat-confirmed,
  list the page edit for the Funnel Builder.
- **Buyer video:** names everything they bought (the ticket, the VIP, a PASS or Upsell 2), one clause each.
- **No-upgrade video:** if they took something (a cut-down downsell, a PASS, Upsell 2), acknowledge it
  warmly in one line before the last chance at VIP — never treat a buyer as if they took nothing.

---

## Buyer — 1–2 minutes

1. **Serendipity — the decision.** Lead with what they just did: "You decided not to just attend, but to
   implement." Specific, warm, not gushing.
2. **Connection — one line.** Why it matters to the host ("it means a lot to us").
3. **Opportunity — what it gets them.** The outcome first (S-1 / the VIP's promise), then each VIP
   component in one clause, as an outcome (the live component the day after first).
4. **Reality — the picture.** R-3 in one image: the week after, with it working.
5. **Execution — the next steps.** In the page's order: calendar (the event and the live component "the day
   after"), email, the +1 invite, community / WhatsApp. "Everything else gets released on the day."
   End: "I'll see you on the day, and at the [live component]."

**Rules:** no new selling. Any other offer they bought (a PASS etc.) gets one plain line.

---

## No-upgrade — 2–4 minutes

They said no to a full VIP pitch a minute ago. Another full stack won't change their mind. One reason might.

1. **Serendipity — you're in, no guilt.** Warm confirmation of the seat.
2. **Connection — one line** of the host.
3. **Opportunity — what the day gets them.** The outcome first, then the tool as the way there: "this is
   what you'll get when you show up."
4. **The next steps on this page:** calendar, email, community / WhatsApp, the bring item. "Everything else
   gets released on the day. The time's on this page and in your inbox."
5. **Reality — note-taker vs action taker.** The note-taker's week after against the action taker's,
   said with respect.
6. **Execution — the last chance:**
   - **One reason** to upgrade — the outcome the live component (the day after) gets them, as a result.
   - **One objection**, usually money — answered with **the guarantee** (the client's own, or the Coach
     Launch default: 10 times the value or a full refund, "you have nothing to lose").
   - **The two ways**, respectfully: keep the seat as it is, or add the VIP and implement it.
   - **No deadline line** unless the page genuinely closes the VIP at a set point. A placeholder deadline
     on the page → ask whether it's real; if not, flag it to come off.
   - **The one action:** "If you want it, the upgrade's right here on this page — [point]." Then: "Either
     way, you're in, and we'll see you on the day."

**Rules:** no full stack, no price flip — one reason, one objection, one action. Cap at 4 minutes.

---

## Document

Offer two or three opening lines here too (styles as in `detonator-sections.md`); split-test versions
work the same way. Title line ("🎬 CONFIRMATION VIDEO — [event name] · VIP buyers" / "· Seat confirmed"), "About [N] minutes.
Read it aloud. Record it in one take.", the script with timing markers and `[STAGE DIRECTIONS]`
(`[POINT DOWN TO THE CALENDAR BUTTON]`), then short shot notes. Nothing internal.
