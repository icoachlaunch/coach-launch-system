# Card map — where every line comes from

The SCORE™ Card is the content. The SCORE™ Framework is the shape. The dream outcome (S-1, R-3, R-4) is
what's being sold in every section; the tool, the event and the VIP are the vehicle that gets them there. This file maps one onto the other for
each job, so every section knows which blocks to draw from. Use the client's blocks; adapt them for speech
(shorter sentences, direct to camera, their voice); never change their meaning or add to them.

## The SCORE™ Card — 5 acts, 19 blocks

| Act | Blocks |
|---|---|
| **1 · Serendipity** | S-1 $Million Promise™ Anchor · S-2 Question · S-3 Symbolism · S-4 Debunking |
| **2 · Connection** | C-1 3 Problems · C-2 $Million Moment™ Story · C-3 Credibility Anchors |
| **3 · Opportunity** | O-1 System Reveal · O-2 Core Differentiator · O-3 Client Proof |
| **4 · Reality** | R-1 Consequence of Inaction · R-2 Limits · R-3 Reward · R-4 Desire |
| **5 · Execution** | E-1 2 Ways · E-2 Hard Choice · E-3 Because · E-4 FOMO · E-5 CTA |

Older Cards may call Act 4 "Risk/Reward"; it's the same act (Reality). A founding-stage Card's O-3 may be a
"Founding Client Opportunity" and says it is **not proof** — treat it as no client proof yet: fill the slot with sourced industry data, or `[PROOF NEEDED]` if none exists.
If a block is thin or missing, write that line thin and say so in the chat. Never pad it.

## The free-branch Detonators (jobs A and B) — six sections on five acts

| Section | Act | Draw from | Notes |
|---|---|---|---|
| 1 · Hook + Welcome | Serendipity | S-1 (the promise, spoken) · one of S-2 / S-3 / S-4 for the first line · Golden Avatar™ (who, their words) · B: the VIP's promise (Blueprint) as the one question | Open on them, never a greeting |
| 2 · The Problem + Who I Am | Connection | C-1's framing (the root cause, as a scene) · C-2 in two spoken lines · C-3 (host credibility, each with a benefit) | Proof here is about the **host** only |
| 3 · Meet the Tool | Opportunity | The tool's name (operator's name wins) · what it turns their inputs into (A3/A4, as outcomes) · S-1 / R-3 (the outcome) · R-4 (the identity) | Name it once; every line is the outcome. Never the A1 title as the promise. |
| 4 · The Pains, On the Tool | Opportunity | 3–4 pains the pieces solve (C-1, the tool's own struggles, B1) · Golden Avatar™ (the emotional consequence, their inner voice) · Spec A3 pieces · B2 (the dream picture) · **O-2** (the argument) · **O-3** or sourced research (proof) · A5 map · the bring item · B4 (A only) | No B3 headlines, no how. O-1 stays for the event |
| 5 · Why Live (A) / The VIP, and Why It Matters (B) | Reality | **R-1** cost · **R-2** the limit broken (a client case or sourced data) · **R-3** reward (images) · **R-4** desire · E-4 only if genuine · B: the VIP's name and purpose | B: VIP first, then note-takers vs action takers |
| 6 · Action | Execution | **E-1** two ways · **E-2** the weight · **E-3** because · E-4 only if genuine · B: the VIP offer (stack, terms, price, past price, guarantee) · Golden Avatar™ objections | One action. E-5 is the core offer's CTA — read it, never use it |

**The proof map — each proof once, in its own act.** Host proof (C-3 and every credential in the assets)
in Section 2. System proof (O-3) in Section 4. "Someone like you" (R-2) in Section 5. No client results yet
→ real, sourced industry data in those two slots (sources in the chat). Never repeat a result across sections.

**Trust the folders.** Everything in the client's folders counts as verified, including lines an older
asset tagged `[VERIFY]` or `UNVERIFIED`. Use it.

## The paid branch (jobs D, E, F) — the already-sold scripts

The **Ticket Sales Detonator™ script** is read first. From it: the big idea and its line (said back once,
as a callback), the three struggles, the voice, and the list of proof already spent. The SCORE™ Card is
still the content source for everything the ticket video didn't use.

**D · VIP upsell** (`paid-upsell-sections.md`)

| Part | Act | Draw from |
|---|---|---|
| 1 You're in · 2 Before you go | Serendipity | The event name · S-1 (the outcome, one line) · the tool's name and what it does for them (Spec A3/A4) · a real "how many we've helped" number from C-3, only if the files hold one |
| 3 What it takes · 4 Who this is for | Connection | The ticket script's three struggles · C-1 · the VIP's promise (Blueprint) · R-1 (the note-taker's week after) |
| 5 Meet the VIP · 6 How it works | Opportunity | The VIP offer: name, promise, every component in build · access · keep, each by its outcome |
| 7 Imagine · 8 VIPs | Reality | R-3 · R-4 · VIP proof (Blueprint or operator) or the confirmed "VIPs win" line |
| 9 The offer · 10 The ask | Execution | The VIP offer: stack value, past price (operator), price, trial, guarantee · E-1 (the two ways, if used) · the big idea's line, once |

**E · Downsell** (`downsell.md`): the upsell it follows (its promise and step three) · the downsell terms
(payments, or the price and what's removed) · the Golden Avatar™'s money objection, as "not at that price
right now".

**F · PASS / Upsell 2** (`paid-upsell-sections.md`)

| Part | Act | Draw from |
|---|---|---|
| 1 One more thing | Serendipity | The offer's promise |
| 2 The big picture · 3 Each missing piece · 4 The takeaway | Connection | C-1 · O-1 (the system's shape, never its steps) · the offer's next problem · R-1 for the felt line |
| 5 One short story · 6 The reveal · 7 How it works | Opportunity | A result from this offer (only if real) · the offer: name, promise, parts by outcome |
| 8 Imagine · 9 Proof | Reality | R-3 · R-4 · proof from people who have it (only if real) |
| 10 The offer · 11 Strongest proof · 12 The ask | Execution | The offer: value, past price (operator), price, guarantee · the best remaining proof |

**One proof map across the whole paid funnel.** Every result is used once — in the ticket video, an
upsell, a downsell or a confirmation video, never two. The one allowed repeat is a single callback to the
ticket video's client story. Proof matches what's sold: a VIP part uses VIP results, a PASS part PASS
results. Nothing real for an offer → leave its proof part out and say so in the chat.

## The confirmation videos (job C)

| Beat | Act | Draw from |
|---|---|---|
| You're in / you did it | Serendipity | the decision they just made; the event name |
| One line of you | Connection | C-2 or C-3, a single line |
| What you now have / what the day gives you | Opportunity | Buyer: the Blueprint's components by name · No-upgrade: the tool ("what you'll get when you show up") |
| The picture | Reality | R-3 (buyer) · R-1 / R-2 framed as note-taker vs action taker (no-upgrade) |
| The next step / the last chance | Execution | the page's steps · No-upgrade: one standout VIP reason, one Golden Avatar™ objection, E-1, the upgrade button |

## The other assets

- **Event Magnet™ Spec** — A1 title and object name · A3 the pieces (panels) · A4 the hero/result panel ·
  A5 the system map · A6 the next step · A9 the one-sitting win · B1 pain · B2 walk-away ("for the first
  time…") · B3 teaching points (headlines only) + the do-it-now · B4 the open question · B5 what it proves ·
  B6 the one-liner. An older Spec that describes the tool in prose still works.
- **Money Model** — phase · event format and length (only if fixed) · free or ticketed · VIP yes/no · the close.
- **The VIP offer** — the Cash Flow Max™ Blueprint *or* the approved VIP upsell page copy in
  `Money Magnet/cash-flow-engine/`: name and promise · components · value stack · price · guarantee · trial ·
  decline line. Nothing goes in the stack that isn't in the offer. Past price from the operator. No guarantee
  in the offer → the Coach Launch default (10 times the value or a full refund).
  The standard Coach Launch VIP stack (use the client's Blueprint wording): The VIP After Party (the day
  after — never a date) · Coaching In Your Pocket · The Secret To Making It Stick (the workbook) · the
  Recordings Vault · Bring Your +1.
  Buckets for the VIP case: **BUILD** (what they build with — the workbook) · **ACCESS** (time with the host
  — the After Party, Coaching In Your Pocket, the +1 seat) · **KEEP** (what they keep — the Recordings Vault).
- **The Golden Avatar™** — the callout, their exact words, the two objections the VIP close sweeps.
- **Brand Voice** — sentence length, power words, banned words, "Speaks as" (I / we).

## Names that exist (use exactly, with ™)

The $100K Day Engine™ · The $100K Day Accelerator™ · Offer Matrix™ · Money Magnet™ · Client Flywheel™ ·
$Million Story™ · $Million Promise™ · The Golden Avatar™ · $Million Moment™ · Magic Formula™ · Red Diamond
Offer™ · The Sniper Close™ · Sniper Presentation™ · Cash Flow Engine™ · Cash Flow Max™ · Genie X Converter™ ·
Goliath Content™ · Pixie Dust Social™ · Dragon Fire Ads™ · Event Magnet™ · SCORE™ Card · SCORE™ Framework ·
The Authority Detonator™ · The Ticket Sales Detonator™ · Coach Launch Academy™. Plain names: the Money Model, the Enrollment Doc, Brand
Voice, Business Brand Profile, Visual Style Guide. Phases: Launch · Execute · Growth · Mastery.
Say masterclass, workshop or challenge — whichever the Money Model says.
