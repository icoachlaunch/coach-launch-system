# The Detonator sections — Show-Up (A) and VIP (B)

**Free branch only** — for someone who got their seat free, so nothing before these videos has built any
authority. After a paid ticket, the VIP video is job D (`paid-upsell-sections.md`): the Ticket Sales
Detonator™ has already done the story, the tool and the case.

Six spoken sections on the SCORE™ Framework's five acts. Same spine for both jobs; Sections 5 and 6 change
with the job. The templates are shapes, not scripts: fill every bracket from the client's own blocks (see
`card-map.md`) in their voice, using the I / we / they mix. Stage directions sit in `[SQUARE BRACKETS, CAPS]`.
Every line sells the dream outcome; the tool is the vehicle.

**Contents:** Timing guide · 1 Hook · 2 The Problem + Who I Am · 3 Meet the Tool · 4 The Pains, On the Tool
· 5A Why Live · 5B The VIP, and Why It Matters · 6A Action (show up) · 6B Action (upgrade) · Shot notes

## Timing guide (5–12 min, set by the job)

Proportions that worked on a live VIP Detonator (about 1,640 words, 11 minutes):

| Section | Share | Notes |
|---|---|---|
| 1 Hook | ~10% | never cut the first line |
| 2 Problem + host | ~15–20% | can run to ~20% when the client's credentials are long — keep them all |
| 3 Meet the Tool | ~5% | short |
| 4 The Pains | ~23% (A: up to ~30%) | where the minutes go if it's short |
| 5 Reality (A) / VIP + two groups (B) | ~14–20% | B: about 200 words |
| 6 Action (A) / Stack + ask (B) | ~15% (A) · ~25% (B) | B: keep every term |

Over length → trim transitions first, then Section 2's story to its turn. Never cut a pain, a VIP term,
the guarantee or the one action.

---

## Section 1 · Hook — Serendipity

**Job:** make them stay. The first line decides everything.

**Shape:** the first line (see below) → "you're in" → stop them closing the page **with the outcome** —
what this one tool will get them, never what they'll be holding → the gap between where they are and that
outcome, aimed at the situation → the big promise, once (S-1, spoken).

**The opening — a choice, never a default.** Write at least four, one per style, from the Card's S-blocks
and the Golden Avatar™, each labelled:

| Style | Draws on | Fits when… |
|---|---|---|
| **Question** | S-2 | the audience is already asking it themselves |
| **Debunk** | S-4 | they keep repeating a fix that doesn't work (course after course, discounting) — sets up "a system, not another [course]" |
| **Symbol** | S-3 | the metaphor can carry the whole video (then it's the only one used) |
| **Mirror** | Golden Avatar™ words | their exact current state is vivid and specific |
| **Promise** | S-1 | the audience is warm and the outcome itself stops them |
| **Chance moment** | C-2 | the host's turning point mirrors their pain |
| **Real statistic** | sourced research | a striking, real, cited number exists |

Say which you'd pick and why (usually the one that names the behaviour they keep repeating and sets up the
contrast Section 2 closes on), then let the operator choose — or **split-test**.

**Split-testing openings.** When the operator wants two or three versions to test, write each as a
**complete Section 1** — from the first line through the big promise — so each hands off cleanly to the
same Section 2. If a version sets up a contrast or a metaphor that Section 2's closing line doesn't carry,
give that version its own matching closing line for Section 2 and say so. The rest of the script is shared.
In the document, Section 1 holds Version A; the alternates go under **SPLIT-TEST OPENINGS** after the
script (see `ready-check.md`), so the client records Section 1 once per version and the editor swaps it in.

**A · Show-Up**
> "[First line.] You're in. Your seat at [event name] is saved, and your email's on its way. And your
> [tool name]? That's what you'll get when you show up.
>
> But before you close this page, stick with me. We're going to show you how, with this one tool, you
> [S-1's outcome in their words]. [One line on the gap: what separates the ones stuck where they are from
> the ones who have that outcome.]
>
> Because here's what [event name] is really about. [S-1, spoken.]"

**B · VIP**
> "[First line.] You're in. Your seat at [event name] is confirmed and your email's on its way.
>
> But before you close this page, stick with me. We're going to show you how [event name] gets you
> [S-1's outcome] — and how to leave with it working, not just written down.
>
> One question first. [The dream outcome as the question — the result only, no deliverables: 'Want to
> leave this [masterclass] with the exact system that [S-1's outcome]?']
>
> Give me about [N] minutes. If it's not for you, no problem — there's a link under this video that takes
> you straight to your confirmation page. But first, here's what [event name] is really about. [S-1.]"

**Rules:** every promise here is an outcome. No greeting first, no "in this video I'm going to talk
about…", no date. No line implying VIPs get better results unless the operator confirmed it.

---

## Section 2 · The Problem + Who I Am — Connection

**Job:** "this person gets me." Problem first, then the host.

**Shape:** the main problem as a scene (C-1's framing) → the root-cause line ("You don't have a [surface]
problem. You have a [real] problem.") → C-2, the story, in a few spoken lines with its result → **every**
credential in C-3 (and the other assets), as numerals, each with what it means for the viewer → close on
the contrast the first line set up: "Not another [course]. A system." → "So we built something to fix it."

**Rules:** "I" lives here (the host's own story and credentials). Keep every credential and result the
assets carry — the client can cut. Host proof only (client results go in Sections 4 and 5).

---

## Section 3 · Meet the Tool — Opportunity opens

**Job:** the reveal. Name the tool once; every other line is the outcome it gets them. Never speak the
Spec's title as the promise — that sells the worksheet.

> "[HOLD UP THE PRINTED TOOL.]
>
> This is the unique one-page [tool name] that turns [what they already have] into [the two or three things
> it produces, as outcomes].
>
> This is the EXACT system our clients are using to [dream outcome], without [the fear they have].
>
> This is the [system] that gets [more clients saying yes / the outcome], so you stop being [current
> identity] and start being [the identity they want].
>
> And this is what you'll get when you show up."

**A only — the tool is the bribe:** one line that it's handed out to the people who are there live.

**Rules:** "our clients" is fine when the host has clients from their years doing this work, even if this
offer is new. Identity language is wanted here (from "still working on it" to "the [expert] you're meant to
be"). No pieces, no how.

---

## Section 4 · The Pains, On the Tool — Opportunity

**Job:** the heart of the video. A tour of **3 or 4 pains** — the ones the tool's pieces actually solve —
then the dream picture, the proof, the map and the hinge. **It teaches nothing.**

**For each pain:**
1. **The moment:** "You know how [the moment they recognise]?"
2. **The emotional consequence, said plainly:** the overwhelm, the impostor syndrome, the inner voice
   ("who is going to pay me for this?", "maybe I'm just not good enough"), or what it costs them
   (prospects leave confused and go elsewhere).
3. `[POINT AT THE PIECE]`
4. **A short breakthrough line:** "Let me show you how we fix this, right here." / "Good news… this piece
   is where we have a breakthrough." / "This box is going to change the way you look at your business,
   forever."

One short reveal line is allowed if it stays a hook ("The secret… less is more."). Nothing else about the
piece: **no explanation, no maths, no worked example, no B3 teaching headlines, no "on this piece I'll be
showing you how to…"**.

**Then:**
- **The dream picture:** "So picture all [N] of those problems solved in just one session. You walk away
  with [outcomes]… and after that the right people start saying yes, without you ever feeling like you're
  selling. That's [S-1 outcome] in one simple [tool]."
- **The argument (O-2):** one line on why this works when everything else they've tried didn't.
- **The proof (O-3):** a real client result (name, number, timeline). No client results for this system
  yet → real, sourced industry data that backs **this** argument, as close to the audience's profession as
  you can find ("A study of nearly 1,000 [profession] found that…"); sources in the chat, and say there if
  you could only read a summary. `[PROOF NEEDED]` only if no credible data exists.
- **The map (A5):** one line — "This is step [X] of [N] in [system name]. On the day, we walk you through
  the whole map."
- **The hinge:** "And here's the exciting part. We'll be giving you this to fill in with us, live. You
  leave with a real result, not just notes."
- **The bring item:** "Write down [bring item] and bring it" — as the live exercise's input, or as the
  "why" anchor the operator chose.
- **A ends on the open question (B4):** "One thing it doesn't do, though. [B4.] That's what the room is
  for." **B ends on the hinge / bring item** — Section 5 opens on the VIP.

**Metaphors:** only the one the opening line set up, or none. Never a new analogy here.

---

## Section 5A · Why Live — Reality (Show-Up)

**Job:** staying home should feel more costly than turning up. Truth, not pressure.

**Shape:** what only live gives them (filling it in with us, their question answered) → **R-1** the cost,
their life a few months on if nothing changes → **R-2** the limit broken: the belief in the way ("this
won't work for me"), answered with someone like them — a client case, or sourced data → **R-3** the reward
as images → **R-4** the real want → E-4 only if genuine → "That's why we want you in the room."

**Rules:** no replay or recording mention. No invented urgency. Images, not adjectives.

---

## Section 5B · The VIP, and Why It Matters — Reality (VIP)

**Job:** introduce the VIP up front, then show why it matters through the two kinds of people. About
**200 words**.

**Shape, in order:**
1. "Now let me tell you how we make this [event] even better."
2. **The VIP by name and purpose:** "Right under this video, there's a VIP option. The [VIP name]. It's
   built so you don't just attend. You implement it."
3. "Here's why that matters." **Two kinds of people:**
   - **Note-takers:** they leave inspired, and by next week [the inbox / life] has won. "Nothing wrong with
     that path. It just keeps you where you are."
   - **Action takers:** they invest in themselves and do what it takes. They're the ones who take the VIP,
     because that's where questions get answered and implementation happens.
4. **If the operator confirmed "VIPs win":** "In our experience, the people who invest in the VIP are
   usually the ones who make the biggest shift. Not because of the VIP itself, but because they've
   committed and they're going all in." If not confirmed, leave the comparison of results out.
5. "That's what the [VIP name] is for. Here's what's inside."

**Rules:** never say "upsell". Name the groups in the script's own frame (note-taker / action taker) and
reuse that frame at the close. Check the host's message — if it's "you don't need more knowledge", don't
praise a hunger for knowledge.

---

## Section 6A · Action — Execution (Show-Up)

**Job:** one action — be there live — then what happens next on this page.

**Shape:** **E-1** the two ways → **E-3** the because (why now) → the one action: be there live → what
happens next, pointing at the page (calendar "right under this video", community, survey) → the bring item
→ "The time's on this page and in your inbox." → end on an instruction.

**Rules:** no money, no VIP, only steps the page actually carries, never a date.

---

## Section 6B · Action — Execution (VIP)

**Job:** make upgrading the obvious next step and remove the last barriers.

**Shape, in order:**
1. **The stack**, in three buckets — "First, the build." (BUILD) · "Second, access." (ACCESS, the live
   component the day after first) · "Third, what you keep." (KEEP). Each component sold by its outcome in
   one or two lines ("the After Party: 90 minutes where you leave with [the outcome]", not "a 90-minute
   call"), with its value.
2. **Trial terms**, if any: free for how long, the price after, how to cancel, what they keep.
3. **The price flip:** "That's $[stack total] of support. Normally, it's $[past price]. Today, it's just
   $[price]." (No past price from the operator → drop the "normally" line.)
4. **The guarantee — always.** The client's own, or the Coach Launch default: "If you don't feel you've
   gotten 10 times the value, simply email us and we'll give you a full refund. You have nothing to lose."
   Then: "The value, we guarantee. Your results are up to you."
5. **Two objections** (from the Golden Avatar™), one line each — reuse the VIP page's own answers and the
   sourced data where they fit.
6. **The weight / identity:** upgrading is about the version of them that shows up on the day.
7. **The one action:** "Hit the upgrade button right under this video." + a cap or deadline only if real.
8. **The clean no:** "If VIP's not for you, that's fine. The link under the button takes you to your
   confirmation page, and we'll see you on the day."
9. **Close on the script's own frame:** "You're going to be in the room either way. The only question
   is… [note-taker, or action taker?]" → "Upgrade now." + one line naming the live component ("See you at
   the [After Party]").

**Rules:** the VIP video asks for one thing; next steps belong to the confirmation page. No core offer.
Every number traces to the VIP offer, the operator or a cited source.

---

## Shot notes (go in the document after the script)

- **Print the tool — your copy.** [Tool name] on paper, in hand from Section 3 on, held steady at chest
  height. The viewers get theirs on the day — this one's for the camera.
- **Section 3 — hold it still.** Let the camera see the whole page first.
- **Section 4 — point, don't explain.** One finger, one piece, a pause so the camera sees it.
- **B · Section 6 — show what's in it.** The VIP page or stack on a second screen.
- **Point where the button is.** Point down; say "right under this video."
- **No date.** Said one by habit? Re-take the line.
- **One take, eyes on the lens.** A pause is fine; an "um" is fine. Smile before you hit record.
