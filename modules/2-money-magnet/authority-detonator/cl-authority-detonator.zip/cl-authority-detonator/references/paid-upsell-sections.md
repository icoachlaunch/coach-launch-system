# The paid branch — VIP upsell (D) and PASS / Upsell 2 (F)

The viewer has just bought a ticket, after a 5–8 minute Ticket Sales Detonator™ video that told the host's
story, showed the tool and made the case. They're already sold on the host and the day. These scripts
don't sell either again: they confirm the decision, name the next problem, and make the offer on this page
an easy yes. Same rules as every Detonator — evergreen, numerals, the outcome sold (never the deliverable),
the I / we / they voice mix, nothing released before the day. Fill every bracket from the client's own
material (see `card-map.md`); stage directions sit in `[SQUARE BRACKETS, CAPS]`.

**Read the ticket script first.** Carry on its big idea (its line said back once, as a callback), its
three struggles and its voice. Every proof piece it used is spent — don't reuse it. Never lift a line out
of its story.

**Contents:** D · VIP upsell (timing, the ten parts) · F · PASS / Upsell 2 (timing, the twelve parts) ·
Shot notes

---

## D · VIP upsell — 6–7.5 minutes (950–1,150 words)

| # | Part | Act | Share | Its one job |
|---|---|---|---|---|
| 1 | **You're in** | Serendipity | ~15% | Confirm the ticket — the longest part |
| 2 | **Before you go** | Serendipity | ~3% | The turn: one important thing |
| 3 | **What it takes** | Connection | ~15% | The three things the outcome needs — the ticket ticks one off |
| 4 | **Who this is for** | Connection | ~5% | The qualifier |
| 5 | **Meet the VIP** | Opportunity | ~7% | Its name and the result it gets them |
| 6 | **How it works** | Opportunity | ~20% | Build · access · keep — each piece by what it does for them |
| 7 | **Imagine** | Reality | ~10% | Life with the next problem solved |
| 8 | **VIPs** | Reality | ~5% | Proof from people who took it (only if real) |
| 9 | **The offer** | Execution | ~12% | The stack's value → what it's been → the price → the guarantee → only here (if true) |
| 10 | **The ask** | Execution | ~8% | One button, the clean no, "either way" |

Over length → trim part 1's recap to one line per item, then "How it works" to one line per piece. Never cut
the qualifier, the price, the guarantee or the clean no. Short → give the time to "What it takes" and "How it
works" (each piece, why it matters, what it costs them, in their struggles' words); never pad.

### 1 · You're in — Serendipity

**Job:** celebrate the decision and recap what the ticket gives them. No result stories here: a result right
after "you're in" is out of place.

> "You did it. You're in. [One line on the decision: they chose to do something about [the struggle], not
> just think about it.]
>
> And just to recap what you've got: your seat at [event name], live. [What the day gets them — the
> outcome, in one or two lines.] And when you show up, you'll get [tool name] — [what it does for them].
> We fill it in together, live.
>
> [Only if the files hold a real number:] You're in good company. [N] [who] have already [done it].
>
> Your confirmation's on its way to your inbox, and the time's on the next page."

### 2 · Before you go — Serendipity

> "But before you go, there's one very important thing we need to cover. It could be the difference between
> [the outcome] and [where they are now]. So stay with me for a few minutes."

### 3 · What it takes — Connection

**Job:** the three things the dream outcome needs, in order, with the ticket ticking one off. Ends on the
real reason the third is missing. From the ticket script's three struggles, the Card's C-1 and the VIP's
promise.

> "Here's the thing. There are three things you need to [the outcome], no matter [their background].
>
> Number one, [the first]. Number two, [the second] — and the good news is, you've just covered that. That's
> [event name]. [One line on what the day does for it.]
>
> But number three is [implementation / support / doing it with someone beside you]. [Why it matters, in
> their words. What it costs them when it's missing — the note-taker's week after, felt.]
>
> Most [who] leave a great day with a page full of notes, and a week later, life has won. Not because they
> didn't care. Because nobody was there for step three."

The **note-taker vs action taker** frame from the free branch fits here when the client uses it — once, said
with respect.

### 4 · Who this is for — Connection

> "Now, if you've already got [step three] handled, you can skip the rest of this video. But if you want
> [the outcome] to actually happen this time, don't miss the next few minutes."

### 5 · Meet the VIP — Opportunity

> "That's exactly why we built the [VIP name]. It's how you [the VIP's promise — the result only, no
> deliverables]. Let me show you how it works."

### 6 · How it works — Opportunity

**Job:** every Blueprint component, in the Blueprint's words, in three buckets, each sold by what it does
for them — the live component first. "Now check this out" before the strongest piece.

> "First, the build. [The workbook / build component] — so you [the outcome of building it], not just hear
> about it.
>
> Second, access. [The live component, 'the day after', never a date] — [what they leave with]. [The other
> access components, one line each.]
>
> And third, what you keep. [The Recordings Vault etc.] — so [what keeping it gets them]."

The VIP's own name for each component, never "a 90-minute call" — "the After Party: 90 minutes where you
leave with [the outcome]".

### 7 · Imagine — Reality

Two or three "Imagine…" lines, each with a when and something they'd see, hear or feel — the week after the
event, with step three done (R-3, R-4). Every "Imagine…" stays imagine.

### 8 · VIPs — Reality

**Only if real:** a line or two about people who took the VIP (the Blueprint's or the operator's), or the
"VIPs win" line if the operator confirmed it: "In our experience, the people who go VIP are usually the ones
who make the biggest shift. Not because of the VIP itself, but because they've committed." Never a ticket
result or a coaching result passed off as a VIP result. Nothing real → leave this part out and say so in the
chat.

### 9 · The offer — Execution

In this order, every number from the offer, the operator or a cited source:
1. **The value:** "That's $[stack total] of support."
2. **What it's been:** "Normally, it's $[past price]." (No past price from the operator → no line.)
3. **The price:** "Today, it's just $[price]." Trial terms plainly, if any.
4. **The guarantee — always:** the client's own, or the Coach Launch default: "If you don't feel you've
   gotten 10 times the value, simply email us and we'll give you a full refund. You have nothing to lose."
   Then: "The value, we guarantee. Your results are up to you."
5. **Only here, right now** — only if it's true (the VIP really is only on this page at this price, or a
   real cap). No early-bird, no price rise, no countdown that isn't real.

### 10 · The ask — Execution

> "So here's what to do. Hit the button right under this video and add the [VIP name] to your order. [The
> big idea's line, said back once.]
>
> If it's not for you, that's fine. The link under the button takes you to your confirmation page.
>
> Either way, you're in, and we'll see you on the day."

**Rules:** one button. No core offer. Never say "upsell". Ends on an instruction.

---

## F · PASS / Upsell 2 — 6–7.5 minutes (950–1,150 words)

The viewer has bought a ticket and said yes or no to the VIP. **Never assume either.** No order recap — the
VIP video or the confirmation page does that.

| # | Part | Act | Share | Its one job |
|---|---|---|---|---|
| 1 | **One more thing** | Serendipity | ~4% | The turn — no order confirmation |
| 2 | **The big picture** | Connection | ~15% | The 3–4 things the bigger result needs, in order — the ticket's one ticked off |
| 3 | **Each missing piece** | Connection | ~15% | Why each matters, ending on one felt line |
| 4 | **The takeaway** | Connection | ~5% | "This probably isn't for most people here…" |
| 5 | **One short story** | Opportunity | ~8% | Someone who hit this next problem and solved it with this offer (only if real) |
| 6 | **The reveal** | Opportunity | ~7% | Its name and what it does for them |
| 7 | **How it works** | Opportunity | ~15% | Each part, what it does for them — "Now check this out" before the strongest |
| 8 | **Imagine** | Reality | ~8% | Life with it done |
| 9 | **Proof** | Reality | ~5% | People who have it (only if real) |
| 10 | **The offer** | Execution | ~10% | What it's worth, what it's been, the price, the guarantee |
| 11 | **Strongest proof, last** | Execution | ~3% | One line (only if real) |
| 12 | **The ask** | Execution | ~5% | Only here (if true) · one button · "either way" |

### 1 · One more thing — Serendipity

> "One more thing before you go — and it could be a real game-changer for [the bigger result]."

### 2 · The big picture — Connection

The 3–4 things the bigger result needs, in order (from the Card's C-1 / O-1 and the offer's promise). The
one the event solves, ticked off: "the good news is, [event name] covers that." Never "the VIP covers that".

### 3 · Each missing piece — Connection

Why each remaining piece matters, in their words, what it costs them. End on one felt line: "And until
that's solved, [the pain] keeps [its verb]."

### 4 · The takeaway — Connection

> "Now, this probably isn't for most people here. If you've already got [this] handled, close this video —
> your confirmation's on its way. If not, watch the next few minutes."

### 5 · One short story — Opportunity

Only if real: someone who had what they've got, hit this next problem, and solved it with this offer. Three
or four lines. Nothing real → leave it out and say so in the chat.

### 6–7 · The reveal and how it works — Opportunity

> "That's why we built [PASS / Upsell 2 name]. It's how you [its promise]."

Then each part by what it does for them, never how. "Now check this out" before the strongest part.

### 8–9 · Imagine and proof — Reality

Two or three "Imagine…" lines with a when. Then proof from people who have it — only if real.

### 10–11 · The offer and strongest proof — Execution

What it's worth → "normally $X" (only with the operator's past price) → the price → the guarantee (the
client's own, or the Coach Launch default) → the strongest proof, one line, only if real.

### 12 · The ask — Execution

> "[Only if true: This is only on this page.] Hit the button right under this video and add [name] to your
> order. Either way, we'll see you on the day."

---

## Shot notes (go in the document after the script)

- **These are short on purpose.** They've just bought; keep the energy of someone celebrating with them.
- **Point where the button is.** Point down; say "right under this video."
- **Show what's inside** (part 6). The offer's page or stack on a second screen, if you're using one.
- **No date.** Said one by habit? Re-take the line.
- **One take, eyes on the lens.** A pause is fine; an "um" is fine. Smile before you hit record.
