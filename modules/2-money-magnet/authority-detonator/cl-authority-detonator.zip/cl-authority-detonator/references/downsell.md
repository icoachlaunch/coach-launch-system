# The downsell (E) — about 1 minute (150–250 words)

Plays on the page after someone says no to an upsell — the VIP downsell, or a PASS / Upsell 2 downsell if
the funnel has one. They just said no to a full offer. Another full pitch won't change their mind; an easier
yes might. Same rules as every Detonator — evergreen, numerals, the outcome sold, nothing released before
the day. Never say "downsell" on camera.

## The offer — set by the price of the upsell it follows (Matthew, 2026-11-09)

| The upsell was… | The downsell is… | How it's said |
|---|---|---|
| **$100 or more** (e.g. a $297 VIP) | **The same offer, as a payment plan.** Nothing taken out, same access | "[N] payments of $[amount]" |
| **Under $100** | **A lower price, with items removed** (e.g. the recordings only) | Name exactly what's in and what's out |

**Payment-plan maths — work it out before you write a word.** Never call it "the same price" or "the same
$[price], split up" unless N × amount equals the upsell price exactly. A plan that totals more is fine —
just never disguised. **A payment-plan buyer has bought the VIP**: they land on the VIP-confirmation page.
If the funnel sends them to the no-VIP page, list the page edit for the Funnel Builder.

**Cut-down offer — what's removed comes from the offer or the operator, never invented.** Never let the
cut-down version sound like the full thing. A cut-down buyer has not bought the VIP: they land on the
seat-confirmed page, and the no-upgrade video acknowledges what they took.

## The six parts

| # | Part | Its one job |
|---|---|---|
| 1 | **One last thing** | "This will be the shortest video you watch today." |
| 2 | **Two kinds of people** | "One of two things is true": you've already got [step three] handled — or you want it, just not at that price right now |
| 3 | **Let the first group go** | "If that's you, no worries. Skip this, and we'll see you on the day." |
| 4 | **The easier yes** | $100+: "the full [VIP name], same access, in [N] payments of $[amount]" · under $100: "[what's in], for just $[price]" |
| 5 | **What you get** | One breath: what's inside, what it gets them, what it's worth. The guarantee in one clause, if the offer carries one |
| 6 | **The ask** | "Click the button right under this video to add it to your order." Nothing after it that implies they already have it |

> "Okay, this will be the shortest video you watch today.
>
> If you're watching this, one of two things is true. Either you've already got [step three] handled — or
> you want [the outcome], just not at $[price] right now.
>
> If you're the first, no worries. Skip this, and we'll see you on the day.
>
> If you're the second, here's an easier way in. [The easier yes.] [What you get, in one breath.]
>
> Click the button right under this video to add it to your order."

**Rules:** one offer, one button. No stack, no story, no proof parade. No deadline unless it's real. No line
after the ask that implies access ("see you inside", "press play") — they don't have it until the order goes
through.

## Document

Offer two or three opening lines (styles as in `detonator-sections.md`). Title line ("🎬 YOUR AUTHORITY
DETONATOR™ SCRIPT — [event name] · [VIP / PASS] downsell video"), "About 1 minute. Read it aloud. Record it in
one take.", the script with timing markers and `[STAGE DIRECTIONS]` (`[POINT DOWN TO THE BUTTON]`), then
two or three shot notes. Nothing internal.
