# Copy specs and compliance

## Contents
1. The fields of a Meta ad
2. The long primary text — five acts at ad depth
3. CTA buttons by destination
4. The Meta policy check for coaches
5. Truth and claims

Placement limits change. These are the working limits; if Ads Manager shows something different, Ads
Manager wins — note it in the pack.

---

## 1 · The fields of a Meta ad

| Field | Limit (working) | Job |
|---|---|---|
| **Hook** (first line of primary text) | the first ~40 characters do the stopping | Serendipity: the moment, the person, the loop |
| **Primary text — short** | ≤ 125 characters (shows in full above "See more") | The whole ad for most people: hook + outcome + action |
| **Primary text — long** | 60–180 words, short paragraphs, line breaks between acts | All five acts for the people who tap "See more" |
| **Headline** (under the creative) | ≤ 40 characters (≈ 27 show on some placements — front-load) | The outcome, or the tool + outcome. Not the format alone |
| **Description** | ≤ 30 characters (often hidden) | The proof of ease: "Free · Live online · 60 min" |
| **CTA button** | Meta's list (§3) | Matches the destination |
| **On-creative text** | ≤ 12 words headline + ≤ 20 words sub | Carried by the creative, not repeated word for word in the headline |

**The link line.** Primary text can carry a clickable URL, so every version gives the reader a link where
they are reading: `👉 Grab your $27 seat here: <URL>` on its own line — after the short text's ≤ 125
characters (the limit counts the words before the 👉), and at the end of the long text's first and last
paragraphs. Use the destination's own URL (with the ad set's UTMs); in a promise test each ad set links to its
own page.

Write the short and long versions so either can run: the short one is Serendipity + Opportunity + Execution
in one breath; the long one adds Connection and Reality.

## 2 · The long primary text — five acts at ad depth

One line or one short paragraph per act, in order, with a blank line between. No act labels in the pack.

1. **Serendipity** — the avatar callout, then the adapted map hook.
2. **Connection** — the struggle stated as fact, or the host's turning point in one line (C-2, third
   person in copy introducing the host; first person if the host is "speaking" the ad).
3. **Opportunity** — what the virtual event (or tool) gets them: the outcome first, the tool as the vehicle,
   the system named once, and **the full $Million Promise™, word for word** (or in Execution if it reads better
   there). Never teach the how.
4. **Reality** — one line: the cost of staying put, or one real result from someone like them (C-3/O-3),
   or the snapshot of life after.
5. **Execution** — the one action, what it costs (free / the ticket), what happens next, what they walk
   away with. Real scarcity only (seats capped, cart closing) — else the because. End on an instruction.

Format: emoji only if the Brand Voice uses them; max one per paragraph. Bullets (3 max) are allowed in
Opportunity for "what you'll walk away with". Numerals for numbers.

## 3 · CTA buttons by destination

| Destination | Button | Long-copy action line |
|---|---|---|
| Registration — free | Sign Up | "Save your free seat — the link's below." |
| Registration — paid ticket | Book Now (or Get Tickets where offered) | "Grab your ticket below — [price] for the full session." |
| Click-to-message | Send Message / Send WhatsApp Message | "Tap the button and message us '[keyword]' — we'll send you the details." |
| Event Magnet™ opt-in (standalone funnel only) | Download (or Get Offer) | "Tap below and get your [tool name] — [the outcome it starts]." |
| Retargeting — show up / VIP / replay | Learn More / Sign Up | per the moment (`campaign-setup.md` §4) |
| Retargeting — the close | Apply Now / Book Now / Learn More | per the close (ASK™ apply · PASS™ book · JOIN™ / SEAL™ learn more) |

## 4 · The Meta policy check for coaches

Run on every line, every creative, every script. Any ✗ is rewritten before delivery. (This is a practical
checklist, not legal advice; Meta's Advertising Standards are the authority.)

| # | Check | ✗ looks like | ✓ rewrite |
|---|---|---|---|
| 1 | **No personal-attribute callout** — never assert or imply the viewer *has* a trait: health, mental health, finances, body, age, religion, sexuality, ethnicity, criminal record, relationship status | "Are you drowning in debt?" · "Struggling with anxiety?" · "Your marriage is falling apart" | Talk about the situation or the group, not "you are": "For coaches who've had a slow quarter…" · "When the diary's empty and the bills aren't…" |
| 2 | **No guaranteed or promised outcomes** — especially income, weight, health. Never tell the viewer what *they* will make | "You can make $10K in the next 30 days, guaranteed" · "You'll close $30K this month" | Report what happened, from I / we / they: "This is how our clients made $30,000 in the last 60 days" · "Last month I made $30,000 from this one campaign" · "This is how we make $20,000 a week from virtual events" |
| 3 | **Income claims are reported, never assumed** — the money belongs to I, we, our clients, they or them, never "you" / "your", and no assumptive words ("you will", "you'll", "you're going to", "imagine making", "your first $10K month") | "Your first $100K month is 112 days away" | "Our clients reached their first $100K month in 112 days" (only if the documents say so) — real, named or attributed, with the timeline, and "Results not typical. Individual results vary." on the creative or page |
| 4 | **No before/after imagery** for health, weight, appearance | split body photos | Show the tool, the host, the moment — not a body |
| 5 | **No sensational or shocking language / images** | "SHOCKING secret doctors hate" | Plain, specific, true |
| 6 | **No fake UI or misleading buttons** on the creative (fake play buttons, notifications, close-Xs) | a red "1 new message" badge | A plain button-shaped CTA bar is fine |
| 7 | **No Meta brand misuse** — don't imply endorsement; "Facebook"/"Instagram" in copy only plainly | "Facebook-approved method" | Leave it out |
| 8 | **Landing page matches the ad** — same promise, same price, same offer | ad says free, page charges | Fix the ad or the page |
| 9 | **Special ad categories** — credit, employment, housing, social issues need the category set | a coaching ad promising loan approval | Flag it to the operator in one line |
| 10 | **Text on image light** — the creative isn't a wall of words (delivery suffers) | 60 words on the image | ≤ 12-word headline + ≤ 20-word sub |

## 5 · Truth and claims

- Every number traces to the business's documents or the operator's chat. No invented results, counts,
  percentages, deadlines, seat caps, prices, testimonials or "as seen in".
- Testimonials are quoted as written, attributed as the business attributes them.
- Scarcity only if genuine (E-4, the Money Model, the operator). A countdown that resets is fake — never.
- Australian Consumer Law and the FTC both treat testimonials and earnings claims as claims: a typical-result
  line goes wherever a result is shown.
- **Who owns the money in the sentence.** Any sentence with a dollar figure, revenue, income, sales or profit
  speaks from I, we, us, our, they or them — what the host, the team or the clients actually did. "You" can
  call out the avatar ("If you're a coach…") and name their situation, but never owns a result or an amount.
  SCORE™ Card lines written to "you" with a result (e.g. an E-1 "your first $100K month") are reframed to
  "our clients…" before they go into an ad. The locked $Million Promise™ ("We help…") already speaks as "we".
