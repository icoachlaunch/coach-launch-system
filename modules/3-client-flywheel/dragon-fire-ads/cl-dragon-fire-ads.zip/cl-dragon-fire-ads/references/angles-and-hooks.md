# Angles and hooks — from the map to the ad

## Contents
1. The five angles
2. Pulling hooks from the map
3. Adapting a hook to an ad
4. The lead angle
5. Weak vs strong

---

## 1 · The five angles — one led by each SCORE™ act

An angle is one big idea told through one act. Every ad still carries all five acts (one line each); the
angle decides which act **opens** it and carries the weight. Five angles = five genuinely different front
doors, so the test learns something.

| # | Angle | Opens with | Map rows to pull (Event Magnet™ section first, then the hot step's) | Pairs with creative |
|---|---|---|---|---|
| A1 | **Recognition** | Serendipity — "this is about me" | Mirror · Question · Myth hooks (rows 7–9); Serendipity Stone (row 2) | C2 Pain Call-out |
| A2 | **Seen** | Connection — the struggle named, the host who's been there | Again · Turning Point · Pieces (rows 10–12); Connection Stone (row 3) | C5 Host |
| A3 | **The Tool** | Opportunity — the mechanism, the difference | Reveal · Difference (rows 13, 15); Opportunity Stone (row 4) | C1 Tool Hero |
| A4 | **Proof / Two Futures** | Reality — the cost of staying put, the life after, someone like them | Proof (row 14) · Calendar · Snapshot · Real Want (rows 16–18); Reality Stone (row 5) | C3 Proof — no real proof → rows 16–18 only, creative C4 |
| A5 | **The Door** | Execution — the obvious next step | Two Roads · Start Here · Open Door (rows 19–21); Execution Stone (row 6) | C4 Two Roads |

The Flagship title (row 1) of the Event Magnet™ section is the campaign's big idea in its biggest form —
use it to write the brief's big idea sentence, not as an ad hook.

**Hooks come from the map only.** The Event Magnet™ Spec (the four unused Tool Promise options, the B6
one-liner and host lines) and the SCORE™ Card feed the *body* of the ad — the Connection, Opportunity,
Reality and Execution lines — never the hook. A good line found there that the map lacks → suggest adding it
to the map (`cl-goliath-content-map` adds rows in place) for the next round.

## 2 · Pulling hooks from the map

- Read the CSV (or the `.md` tables). For each angle, list every candidate row from the Event Magnet™
  section and the hot step's section, then pick the **three** that open the strongest loop for a cold
  scroller who has never heard of the host.
- **Cite every hook**: `Map S11·R7 Mirror` (section 11, row 7). The citation goes in the pack beside the
  hook, so a winner can be traced back and its neighbours mined.
- A row carrying `[MISSING CONTENT — …]` can't run as an ad. Pick the next row; list the gap.
- No two angles share a row. No two ads in the pack open with the same first three words.

## 3 · Adapting a hook to an ad

A map row is a working title; an ad's first line is spoken to one person mid-scroll. Adapt — never rewrite
the meaning.

1. **Make it the first line, not a title.** Sentence case, no title caps, ends in a full stop or a question.
2. **Callout first, then the hook.** The first words name the avatar — one of the pack's callout variants
   (statement · question · gate · direct address, all built on the $Million Promise™'s Ideal Audience) — then
   the map hook (a Mirror row may already carry it). This is what tells an open Advantage+ audience who to find.
   Use a different variant on different ads, so the callout gets tested alongside the angle; a winning callout
   carries into the next round.
3. **Policy pass.** "You" + a personal attribute (health, finances, body, age, relationships, identity)
   is a disapproval risk — move it off the viewer and onto the situation: ✕ "Are you a broke coach?"
   ✓ "For coaches whose diary is full but whose launches keep running to stand still." (See
   `copy-and-compliance.md`.)
4. **Name online + live** within the first two lines when the destination is the virtual event.
5. **≤ 125 characters for the short primary text.** The hook plus one line of promise plus the action must
   fit above "See more" — that is the whole ad for most viewers.
6. **Keep the business's words.** The avatar phrases and coined names stay exactly as the map has them.

## 4 · The lead angle

Recommend one angle to launch with budget weight, with a one-line reason. Defaults, in order: the angle whose
hook is sharpest in the avatar's own words → A1 Recognition for cold, unaware markets → A3 The Tool when the
tool's name alone opens a loop → A4 when the proof is strong and specific. Past results from the operator
beat every default.

## 5 · Weak vs strong (fictional business — never reuse)

*Maya Reid, coach for physio clinic owners; Event Magnet™: Empty Slot Audit; virtual event: free masterclass.*

> **Weak:** "Want a full book? Join my free masterclass and get my audit!"
> *Anyone's ad. Sells the tool and the masterclass, not the outcome. No moment, no loop.*
>
> **Strong (A1, from a Mirror row):** "Clinic owners: six empty slots on a Tuesday, again. It isn't your
> marketing. Join Maya live online and find the one leak that's emptying your book — then fill it without
> another discount."
> *The moment first, a debunk, online + live, the outcome sold, one action implied.*
