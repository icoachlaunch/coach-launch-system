# Creatives — built around the Event Magnet™ tool

## Contents
1. Where the creatives are built
2. The five concepts
3. Sizes and safe zones
4. Building the boards
5. The creative rules

---

## 1 · Where the creatives are built

**Built by `cl-dragon-fire-ads-statics` on the business's own Dragon Fire Ads™ canvas** ("<Business> — Dragon
Fire Ads", one per business, one row per pack) — never on the Event Magnet™ canvas. That skill's
`references/concepts.md` §1 is the rule: first run creates the canvas from the Design type, installs the
business's design system (a client: Event Magnet Panels in their Kit; Coach Launch: its own default), and
uploads the exported tool PNG and real photos as assets placed with `<img src="/_blob/<id>">`. When this skill
builds statics itself, it follows the same rule.

**The concepts, looks, type floor and creative rules below are superseded by that skill's
`references/concepts.md` §2–§5** (a first set of 21 statics: 7 concepts × dark · white · photo; no text under
18 px; the $Million Promise™ on every image; no lockup or small print; AI supporting images). Where the two
disagree, the statics skill wins.

In one message, `read` from the design system: `project/README.md`, `project/kits.json`,
`project/templates/ad-4x5.dc.html`. Every concept below starts from the ad template's `<helmet>` block, its
logic `<script>` (the six Kits, `apply()`, `renderVals()`) and its classes (`.ad-eyebrow .ad-pill .ad-h
.ad-sub .ad-btn .ad-who`), copied verbatim; only the body changes.

## 2 · The five concepts

All 4:5 (1080 × 1350), dark `band` ground, Kit display face on every headline, mono eyebrow, ONE button-shaped
CTA bar, the business lockup bottom-right. The headline on the creative is the angle's lead hook cut to ≤ 12
words (one phrase in `band-accent`); the sub ≤ 20 words sells the outcome.

| Concept | Angle | Composition | Hero |
|---|---|---|---|
| **C1 · Tool Hero** | A3 The Tool | The ad template as built: eyebrow pill (`Free · live online` or the format), headline, sub, the tool page tilted −2° at 60 %, button, lockup | The tool, large |
| **C2 · Pain Call-out** | A1 Recognition | Top half: the struggle line as a big statement (≤ 14 words, Kit display, `band-ink`), a small mono label above it (`Sound familiar?` or the avatar callout). Bottom half: a thin `band-accent` rule, "There's a one-page fix." in the sub, the tool at 45 % tilted +3° bottom-right, button bottom-left | The words, then the tool |
| **C3 · Proof** | A4 Proof | A testimonial card (quote ≤ 90 chars, name · role, five gold stars `#F2B21B` bottom-right) overlapping the tool page at 50 %, headline above, one stat tile if the Card holds a real number. Legal line at the foot: *Results not typical. Individual results vary.* | The client's real result |
| **C4 · Two Roads** | A5 The Door (or A4 without proof) | Headline across the top; two columns below: left "The old way" in `band-soft` with 3 short struck-through lines (the workaround from B1); right "The new way" (or the outcome in ≤ 4 words) in `band-accent` with the tool at 40 % and 3 outcome lines; button full width | The contrast |
| **C5 · Host** | A2 Seen | The host's round headshot (360 px, `band-accent` ring) or a photo panel left third; a first-person quote line from the host (C-2 turning point, ≤ 16 words) beside it; the tool at 45 % under the quote; name + credential line (client's own, from C-3) | The person |

No real proof → C3 is skipped and C4 runs for A4; list `[MISSING CONTENT — one real client result]`.
No headshot → C5's photo circle carries `[MISSING CONTENT — host headshot]` and is listed. A photo of the host holding the printed tool
is the strongest C5 — if the operator wants one generated from a real headshot, use `cl-image-gen` with
the operator's approval; never generate a likeness without it.

## 3 · Sizes and safe zones

| Size | Board | Use | Rule |
|---|---|---|---|
| **4:5 · 1080 × 1350** | every concept | Feed (Facebook, Instagram) | Main size. Everything inside 60 px margins |
| **9:16 · 1080 × 1920** | the lead creative | Stories, Reels | Reels-safe (also safe for Stories): keep text and button out of the top 270 px (≈ 14 %) and the bottom 670 px (≈ 35 %), and 65 px from each side. Stack inside the middle: headline · tool (55 %) · sub · button |
| **1:1 · 1080 × 1080** | the lead creative | Right column, some placements | Drop the sub; tool at 50 %; headline ≤ 9 words |

Other concepts get extra sizes on request, or once they win a test.

## 4 · Building the boards

1. Scratchpad folder, one file per board: `project/Ad-C1-tool-hero.dc.html`, `project/Ad-C2-pain.dc.html`,
   `project/Ad-C3-proof.dc.html`, `project/Ad-C4-two-roads.dc.html`, `project/Ad-C5-host.dc.html`, plus
   `project/Ad-C1-tool-hero-9x16.dc.html` and `project/Ad-C1-tool-hero-1x1.dc.html` (the lead concept's
   files take its letter). Each root sets its own `width`/`height` and `$preview`.
2. **Set the Kit exactly as `cl-event-magnet-visual` Step 3 does** — the Kit id in the root's inline
   variables, the `kit` default in `data-props`, and every `??` fallback; OVERRIDES via `useOwnHero` / `hero` /
   `inkOnHero`; font overrides on the root and the Google Fonts link. Copy the Kits table verbatim (it is
   JSON; retyping it breaks the script). Keep SVG attributes camelCase.
3. The tool sits inside a fixed box with the template's wrapper: outer box `overflow:hidden`, inner
   `1587 × 1123` scaled with `transform:scale(s)`, and
   the tool asset `<img src="/_blob/<tool id>" style="width:1587px;height:1123px;display:block">`.
4. Headshot: `<img>` with the photo resized to 360 px square as a JPEG data URI.
5. Add the boards to `project/canvas.json` (read it first; never drop existing boards): a row at
   `y = 1500` for the 4:5 concepts (`x = 0, 1160, 2320, 3480, 4640`), a second row below for the 9:16 and
   1:1 versions. Board titles: `Ad C1 · Tool Hero · 4:5` — never a paper size, never "draft".
6. **Before every publish, `read` the canvas back** and diff it against what you last published — the
   operator may have edited by hand between boards; their edits win and their changed values (sizes,
   weights, spacing) become rules for the next boards. Then publish to the canvas `url` with `root` = the
   folder, `file_path` = `project/canvas.json`, `files` = the new or changed boards only (existing files are
   kept). A refused publish means someone saved meanwhile: re-read and re-apply.
7. Fit check by arithmetic (the Design type doesn't render for you): headline 70 px × lines + sub 24 px ×
   lines + tool box + button 72 px + gaps must sit inside the board. Too tall → cut words first, then scale
   the tool down, never the type below 22 px (sub) or 56 px (headline).

## 5 · The creative rules

- The creative sells the outcome; the tool is proof that there's a real, visual thing behind the promise.
- One CTA bar, matching the destination's button word ("Save my free seat", "Message us", "Join live").
- No date, weekday, time or price baked into a creative — it would go stale or mismatch the page. "Free"
  is fine.
- No fake UI (play buttons, notification badges, close-Xs), no before/after body imagery.
- Client icons suit the client's niche (Streamline when connected, recoloured to the Kit) — never the
  hand-drawn Coach Launch style on a client creative.
- Every result shown carries the legal line.
