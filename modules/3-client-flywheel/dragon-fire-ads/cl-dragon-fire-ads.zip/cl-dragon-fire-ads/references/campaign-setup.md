# Campaign setup

Structure only. No predicted CPL, CTR or ROAS — the numbers come from running the ads, the targets from the
Money Model. Budgets come from the operator or the Money Model, else `[MISSING CONTENT — daily ad budget]`.
Ads Manager's current options win if they differ from these.

## 1 · Structure by destination

| Destination | Campaign objective | Optimise for | Notes |
|---|---|---|---|
| Registration page (free) | Leads (website) | Lead / CompleteRegistration on the thank-you page | Needs the pixel/CAPI conversion set up on the confirmation page — say so once |
| Registration page (paid) | Sales | Purchase | The ticket purchase event |
| Click-to-message | Engagement (or Leads) → messaging destination | Conversations | Greeting + ice breakers (§3) |
| Event Magnet™ opt-in | Leads (website or instant form) | Lead | Instant form only if the operator wants it; it lowers lead quality |
| Retargeting | Leads / Sales / Engagement by moment | per moment (§4) | Small audiences; frequency watched |

**Ad sets (prospecting):** start with **one** ad set so a coach's budget isn't split too thin to exit the
learning phase — let the creative do the targeting.
1. **Broad / Advantage+ audience** — country/region, age range from the Golden Avatar™. The default.
2. **Audience suggestions** — 3–6 interests the Golden Avatar™ names or implies (publications, tools,
   leaders, professions), entered as suggestions inside the one ad set; never claimed as tested.
3. **Lookalike** — a second ad set only once there are past registrants/buyers and budget to feed it.
4. **Exclusions, always** — past registrants for this virtual event, buyers, current clients (custom
   audiences the operator supplies), so prospecting money isn't spent re-reaching them.

**Ads per ad set:** the five angle ads (each on its creative + lead hook) and the V1 Hook Reel from day one
— Meta rewards varied creative. The lead angle's other two hooks wait for Round 2.

## 2 · Testing plan

1. **Round 1 — angles:** the five angle ads + V1 in the one ad set. Learn which front door works.
2. **Round 2 — hooks:** the winning angle × its three hooks (same creative). Learn which first line works.
3. **Round 3 — creative:** the winning hook × the other concepts and sizes, and the video scripts.
4. **Iterate:** a winner goes back into Stage 2 — new variants from neighbouring map rows (same section,
   same act), never a rewrite from scratch.

Kill and scale rules are set against the Money Model's target cost per registration (or per call/sale).
None in the Money Model → `[MISSING CONTENT — target cost per registration, from the Money Model]`; write
the rule shape ("pause an ad at 2× target with no result") with the target as that flag.

## 3 · Click-to-message setup

- **Greeting** (≤ 2 short lines, the Brand Voice, names the virtual event's outcome, never a price).
- **3 ice breakers** — tappable first messages in the avatar's words ("Send me the details", "Is this for
  [their situation]?", "When's the next one?").
- **The keyword** used in the ad ("Message us 'FULL'") — one word, matches the greeting.
- Hand-off line: the 8-touch conversation sequence takes over from the first reply; it isn't written here.

## 4 · Retargeting set (when the destination includes it)

| Audience | Window | Moment | The ask | Map source |
|---|---|---|---|---|
| Page visitors, not registered | 7–14 days | Didn't register | Save your seat — the outcome again, a different angle | Reality / Execution hooks |
| Registered, before the day | until the virtual event | Show up | Join live — the tool is handed over on the day | Execution · the Show-Up Detonator's big idea |
| Registered (paid phases) | until the virtual event | VIP | Upgrade to VIP (price from the VIP offer) | Execution |
| Attended / watched replay | replay window | The close | The business's close — ASK™ apply · PASS™ book · JOIN™ · SEAL™ | Reality / Execution |
| Didn't attend | replay window | Replay with countdown | Watch before it comes down (only if the countdown is real) | Calendar / Two Roads hooks |

## 5 · Naming and UTMs

- Campaign: `DFA | <Business> | <Destination> | <Event format> | <YYYY-MM>`
- Ad set: `<Audience> | <Placement>` · Ad: `<Angle code>-<Concept>-<Hook cite>` e.g. `A1-C2-S11R7`
- UTM: `utm_source=meta&utm_medium=paid&utm_campaign=<campaign slug>&utm_content=<ad name>`
