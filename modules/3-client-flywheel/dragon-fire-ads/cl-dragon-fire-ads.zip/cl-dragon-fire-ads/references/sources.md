# Sources — the gate, the inputs, the destination

Ads are the last step of the Client Flywheel™. They draw from everything the system has built, so the
inputs are checked before a single word is written.

## Contents
1. Where the assets live
2. The gate — what must exist before ads are built
3. Every input and what it feeds
4. The destination — choose per run
5. Coach Launch's own pack

---

## 1 · Where the assets live

Read the business's `CONTEXT.md` and folder READMEs first; it says what's built. Don't block on file names.

| Asset | Usual location (business folder) |
|---|---|
| Goliath Content™ Map (`.md` + `.csv`) | `Client Engine/Client Flywheel/goliath-content/` |
| SCORE™ Card | `Client Engine/Offer Matrix/score-card/` |
| $Million Promise™ · Golden Avatar™ · $Million Moment™ | `Client Engine/Offer Matrix/million-promise/` · `golden-avatar/` · `million-moment/` |
| Magic Formula™ (+ its visual) | `Client Engine/Offer Matrix/magic-formula/` · `magic-formula-visual/` |
| Event Magnet™ Spec(s) + Visual canvas link / exports | `Client Engine/Offer Matrix/event-magnet/` |
| Money Model | `Client Engine/Offer Matrix/money-model/` |
| Funnel pages (registration page first) | `Client Engine/Money Magnet/cash-flow-engine/` |
| Brand Voice | `Reference/brand-voice.md` |
| Visual Style Guide → BRAND KIT block | `Reference/visual-style-guide.md` |
| Headshots / photos | `Reference/images/profile-pics/` |

Files may also be pasted or uploaded in the chat. Everything found is used as written.

## 2 · The gate — what must exist before ads are built

| Asset | Why it gates | Missing → |
|---|---|---|
| **Goliath Content™ Map** with Slingshot Hooks™ | Every hook and angle is pulled from it. Ads written without it are generic. | Stop. "The ads are built from the Goliath Content™ Map — run `cl-goliath-content-map` first." |
| **SCORE™ Card** | The source of truth for each act, the proof, the CTA. | Stop. Name `cl-score-card-builder`. |
| **Event Magnet™ Spec** | The tool on every creative; its Tool Promise and B6 registration bullet anchor the message. | Stop. Name `cl-event-magnet-builder`. |
| **Event Magnet™ Visual** (the canvas, or the exported tool page) | The hero of every creative. | Copy can go ahead; creatives wait. Name `cl-event-magnet-visual`. Say so once and carry on with Stages 1–3, 5–6 if the operator agrees. |
| **The destination** and its page | The CTA, message match and campaign objective depend on it. | Ask. A page not yet built → `[MISSING CONTENT — the registration page link]` and the page's headline taken from the Event Magnet™ Spec B6. |

The map's **Event Magnet™ section** (Section 11 onward) is the first source for an ad that sends people to
that magnet's virtual event. A map with no Event Magnet™ section (the magnet was built after the map) → use
the hot step's section and say once that the map needs its magnet section added (`cl-goliath-content-map`
adds it in place) for the next round.

## 3 · Every input and what it feeds

| Input | Status | Feeds |
|---|---|---|
| Goliath Content™ Map | Required (gate) | Hooks (Slingshot Hooks™ rows 7–21), angles (Five Stones™ rows 2–6), the campaign big idea (Flagship row 1) |
| SCORE™ Card | Required (gate) | Each act's line in the long copy; proof (C-3, O-3); objections (R-2 internal, E external); the CTA (E-5) |
| Event Magnet™ Spec | Required (gate) | Tool name, Tool Promise (A1) and the four unused promise options (ready hooks), the three pains (A0/B1), B5 proof, B6 one-liner + registration bullet, B7 ticket line (paid) |
| Event Magnet™ Visual | Required for creatives | The tool page imported into every creative |
| $Million Promise™ | **Required** (or SCORE™ Card S-1) | The promise in every ad, verbatim; the Ideal Audience callout at the top; its stored Currency Options are the promise-test variants |
| Golden Avatar™ | Required (or from the Card) | The avatar's words; audience notes |
| Brand Voice | Required | Every line's sound |
| BRAND KIT block | Required for creatives | Kit + overrides. Missing for a client → creatives wait, `[MISSING CONTENT — BRAND KIT block from the Visual Style Guide]`; copy carries on |
| Money Model | Recommended | Phase → free or paid entry; ticket price; VIP; target cost per registration; ad budget |
| Registration page (or destination page) | **Required** | Congruency: its headline must carry the same promise as the ads (match ✔ / ✗ in the brief) |
| Magic Formula™ (+ visual) | Supporting | The system name in Opportunity lines; the Reveal hook |
| Headshot | Recommended | The host creative (C5) and V2. Missing → `[MISSING CONTENT — host headshot]` in the photo circle |
| Testimonials / real results | From the Card | The proof creative (C3). None → `[MISSING CONTENT — one real client result]`; A4 runs on its Calendar / Snapshot / Real Want rows with creative C4 |
| Past ad results (operator) | Bonus | Winning hooks start Stage 2; losing angles are dropped |

## 4 · The destination — choose per run

Ask every run, with the default pre-selected. It sets the objective, the CTA button, the temperature and
what the ad promises.

| Destination | When | Ad promises | CTA button | Temperature |
|---|---|---|---|---|
| **Registration page** (default) | Filling the next virtual event | Join live (free or the ticket) — the tool handed over on the day | Sign Up (free) · Book Now / Get Tickets (paid) | Cold |
| **Click-to-message** (Messenger / WhatsApp) | Conversation-first funnel; high-ticket or skeptical markets | A reply with the virtual event invite; the conversation does the warming | Send Message · Send WhatsApp Message | Cold |
| **Event Magnet™ opt-in** | A standalone lead-magnet funnel that does **not** feed a virtual event | The tool itself, delivered on opt-in | Download · Get Offer · Learn More | Cold |
| **Retargeting / show-up** | Registrants, page visitors, video viewers | Show up live; VIP; the replay countdown; the close | Learn More · Sign Up · Apply Now | Warm / hot |

The Event Magnet™ rule: in a virtual-event funnel nothing is released before the day, so a registration or
click-to-message ad says the tool is handed over live. The opt-in destination is only for a funnel that
delivers the tool on sign-up and doesn't feed a virtual event — confirm that with the operator before
writing "download".

Retargeting closes map to the Four Closes (ASK™ · JOIN™ · PASS™ · SEAL™, from the $100K Day Accelerator™
Framework); the business's own name for its PASS is used in copy.

## 5 · Coach Launch's own pack

Same gate, same workflow, Coach Launch's own assets in `CLIENT ENGINE` (`Client Engine/…`, `Reference/…`).
Brand: Coach Launch's brand kit (`Reference/brand-kit/`) and design system, the hand-drawn icon house style,
Matthew White's credentials ($24.6 Million in high-ticket sales generated · $5.2 Million in recurring client
results delivered) as Connection proof. Run the checker with `--coach-launch`.
