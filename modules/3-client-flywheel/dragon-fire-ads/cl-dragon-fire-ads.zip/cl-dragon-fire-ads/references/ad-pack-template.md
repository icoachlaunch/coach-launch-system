# Ad pack template — the output contract

Write the pack exactly in this shape. `scripts/ad_check.py` reads the headings and the bold field labels:
never rename, reorder or drop one. An empty section keeps its heading and says `[none]`. White space: one
blank line between every labelled line and after every heading — the pack is read by people, not just tools.

````markdown
---
asset: Dragon Fire Ads™ Ad Pack
client: [Business name — or Coach Launch]
campaign: [short campaign name]
destination: [registration | click-to-message | event-magnet-opt-in | retargeting]
virtual_event: [format + name, e.g. free masterclass · Full Book Masterclass]
version: 1
last_updated: [YYYY-MM-DD]
status: [draft | complete]
phase: [n/a | Launch | Execute | Growth | Mastery]
---

# DRAGON FIRE ADS™ AD PACK — [Business]

## Revision History

| Version | Date | Changes |
|---|---|---|
| 1 | [YYYY-MM-DD] | Initial build |

## 1 · THE CAMPAIGN BRIEF

**Big idea:** [one sentence, on the dream outcome]

**Promise:** "[the locked $Million Promise™, verbatim — or the test variants, labelled P1 / P2]"

**Callouts:** "[variant 1 — statement]" · "[variant 2 — question]" · "[variant 3 — gate]" · "[variant 4 — direct address]" (3–5, each built on the promise's Ideal Audience; spread across the ads)

**Page headline:** "[the registration page's headline, verbatim]"

**Message match:** [✔ — the page carries the promise · ✗ — fix: update the page via cl-cash-flow-funnel-builder · test — P1 → page A, P2 → page B]

**Destination:** [page or message flow] · [URL or [MISSING CONTENT — the link]]

**What they get:** [the virtual event's outcome — free / ticket price]

**Temperature:** [cold / warm / hot]

**Avatar:** [one line + their words]

**Event Magnet™:** [tool name] — "[Tool Promise]" · canvas: [link]

**Sources:** Goliath Content™ Map v[n] · SCORE™ Card v[n] · Event Magnet™ Spec [file] · Brand Voice · BRAND KIT: [kit]

**Lead angle:** [A#] — [one-line why]

## 2 · THE ANGLE MAP

| Angle | Act | Idea | Map rows | Creative |
|---|---|---|---|---|
| A1 Recognition | Serendipity | [ ] | [S11·R7, S11·R2] | C2 |
| A2 Seen | Connection | [ ] | [ ] | C5 |
| A3 The Tool | Opportunity | [ ] | [ ] | C1 |
| A4 Proof / Two Futures | Reality | [ ] | [ ] | C3 / C4 |
| A5 The Door | Execution | [ ] | [ ] | C4 |

## 3 · THE ADS

### Ad A1 · Recognition

**Hooks:**

1. [first line] — *Map S11·R7 Mirror*
2. [first line] — *Map S11·R8 Question*
3. [first line] — *Map S2·R9 Myth*

**Primary text (short):** [≤ 125 characters] 👉 [call to action]: [registration URL]

**Primary text (long):**

[Serendipity line]
👉 [call to action]: [registration URL]

[Connection line]

[Opportunity line]

[Reality line]

[Execution line]
👉 [call to action]: [registration URL]

**Headline:** [≤ 40]

**Description:** [≤ 30]

**CTA button:** [Sign Up]

**Creative:** C2 · Pain Call-out · 4:5

**SCORE™:** S n · C n · O n · R n · E n = nn/25

### Ad A2 · Seen

[same fields]

### Ad A3 · The Tool

### Ad A4 · Proof / Two Futures

### Ad A5 · The Door

## 4 · THE CREATIVES

**Canvas:** [link]

| Board | Concept | Angle | Size | On-creative headline |
|---|---|---|---|---|
| Ad C1 · Tool Hero · 4:5 | C1 | A3 | 1080 × 1350 | [ ] |

## 5 · THE VIDEO ADS

### V1 · Hook Reel

**Length:** [n] s · **Format:** 9:16

[0:00–0:03] [spoken line] — ON SCREEN: [text]

[…]

**Shot notes:** [ ]

### V2 · Host to Camera

### V3 · Tool Demo

## 6 · CAMPAIGN SETUP

**Objective:** [ ]

**Ad sets:** [ ]

**Budget:** [operator / Money Model — or [MISSING CONTENT — daily ad budget]]

**Testing plan:** [rounds 1–3]

**Kill and scale rules:** [against the target — or the flag]

**Naming and UTMs:** [ ]

## 7 · RETARGETING

[the retargeting ads, same fields as section 3 — or [none]]

## 8 · CLICK-TO-MESSAGE

[greeting · 3 ice breakers · keyword · hand-off — or [none]]

## 9 · COMPLIANCE CHECK

| # | Check | Result |
|---|---|---|
| 1 | No personal-attribute callout | ✔ |
| 2 | No guaranteed / unrealistic outcomes | ✔ |
| 3 | Income claims carry context | ✔ |
| 4 | No before/after imagery | ✔ |
| 5 | No sensational language | ✔ |
| 6 | No fake UI on creatives | ✔ |
| 7 | No Meta brand misuse | ✔ |
| 8 | Landing page matches | ✔ |
| 9 | Special ad category | n/a |
| 10 | Text on image light | ✔ |

## 10 · MISSING CONTENT

- [every [MISSING CONTENT — …] in the pack, each naming what's needed — or [none]]
````

**Must NOT include:** act labels inside the copy, invented numbers, results, deadlines, seat caps, links or
audiences' performance, dates baked into creatives, Matthew's figures in a client pack, retired markers, or
notes about how the pack was made.
