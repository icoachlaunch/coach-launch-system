# Video ads — three scripts

Spoken SCORE™: the same five acts, one beat each, in the first person (the host is speaking). Short
sentences, one idea each, contractions. Read every line aloud — if it reads like a document, rewrite it.

## The three scripts

| Script | Length | Format | Opens on | Hero shot |
|---|---|---|---|---|
| **V1 · Hook Reel** | 15–30 s (≈ 40–75 words) | 9:16, captions burned in, fast cuts | A Mirror / Myth / Question hook from the map, said in the first 3 seconds with the same line on screen | The tool on screen by second 5 |
| **V2 · Host to Camera** | 45–75 s (≈ 110–190 words) | 4:5 or 9:16, one take, eye level | An Again / Turning Point hook | The host holding the printed tool up |
| **V3 · Tool Demo** | 30–60 s (≈ 75–150 words) | 9:16 screen + hand shots | A Reveal / Difference hook | Pointing at the tool's panels — **shows, never teaches** |

## Script shape (every script)

```
[0:00–0:03] HOOK — [the line, spoken]                      ON SCREEN: [the same line, ≤ 8 words]
[0:03–0:10] CONNECTION — [the struggle as fact / the turning point]
[0:10–0:25] OPPORTUNITY — [what the virtual event gets them; hold up the tool]   [SHOT: tool in hand]
[0:25–0:35] REALITY — [the cost of staying put, or one real result]
[0:35–0:45] EXECUTION — [the one action, said out loud]    ON SCREEN: [button words + "Free · live online"]
```

Timings scale to the script's length; the hook is always the first 3 seconds.

## Rules

- **Never open on a greeting or a name.** "Hi, I'm…" loses the scroll. The hook first; the name can come
  in Connection.
- **Show, never teach.** The tool is held up and pointed at; what goes in each box is what they get live.
  No steps, no maths, no worked example.
- **Evergreen.** No date, weekday or time. "The next session's times are on the page."
- **Free virtual event:** no replay promised; the tool is handed over live, on the day.
- **One action**, said and shown: "Tap the button below and save your seat."
- Captions on every script (most feeds play muted): note `[CAPTIONS: burned in]` in the shot notes.
- **I / we / you.** "I" for the host's story and credentials only; "we" for the virtual event and the
  method; "you" for the viewer — without asserting a personal attribute (policy check 1).
- Shot notes after each script: setting, framing, the tool (a printed copy for camera), b-roll list,
  on-screen text list. The script itself carries no act labels; the timing markers carry the act names
  only in the chat version.
