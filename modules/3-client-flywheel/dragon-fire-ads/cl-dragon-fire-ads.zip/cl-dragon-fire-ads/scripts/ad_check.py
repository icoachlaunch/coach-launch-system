#!/usr/bin/env python3
"""Dragon Fire Ads(TM) ad pack checker.

Reads an ad-pack-<slug>.md written to references/ad-pack-template.md and checks structure,
field limits, the copy rules and the common Meta policy risks.

    python3 ad_check.py ad-pack-full-book.md --client "Maya Reid Coaching" --tool "Empty Slot Audit" \
        --map goliath-content-map.csv
    python3 ad_check.py ad-pack-coach-launch.md --coach-launch --tool "..." --map ...csv

Exit 0 = every hard check passed. 1 = at least one FAIL. WARN lines are judgement calls.
"""
import argparse
import csv
import re
import sys
from collections import Counter

HEADINGS = ["## Revision History", "## 1 · THE CAMPAIGN BRIEF", "## 2 · THE ANGLE MAP", "## 3 · THE ADS",
            "## 4 · THE CREATIVES", "## 5 · THE VIDEO ADS", "## 6 · CAMPAIGN SETUP", "## 7 · RETARGETING",
            "## 8 · CLICK-TO-MESSAGE", "## 9 · COMPLIANCE CHECK", "## 10 · MISSING CONTENT"]
FM_KEYS = ["asset", "client", "campaign", "destination", "virtual_event", "version", "last_updated", "status", "phase"]
DESTINATIONS = ["registration", "click-to-message", "event-magnet-opt-in", "retargeting"]
ANGLES = ["A1", "A2", "A3", "A4", "A5"]
BUTTONS = ["Sign Up", "Book Now", "Get Tickets", "Send Message", "Send WhatsApp Message", "Download",
           "Get Offer", "Learn More", "Apply Now", "Register Now", "Subscribe", "Contact Us", "Watch More"]
LIMITS = {"Primary text (short)": 125, "Headline": 40, "Description": 30}
RETIRED = ["[PROOF NEEDED]", "[CHECK WITH CLIENT]", "[PROVISIONAL]", "[VERIFY]", "UNVERIFIED"]
AI_WORDS = ["unlock", "elevate", "leverage", "supercharge", "game-changer", "game changer", "level up",
            "next level", "skyrocket", "revolutionary", "secret sauce"]
POLICY = [  # (regex, why) -- personal attributes, guarantees, sensational
    (r"\bare you (broke|in debt|depressed|anxious|overweight|fat|divorced|single|lonely|sick|struggling with (debt|anxiety|depression|your weight))",
     "personal-attribute callout (policy 1)"),
    (r"\byour (debt|anxiety|depression|weight|diagnosis|divorce|bankruptcy)\b", "personal-attribute callout (policy 1)"),
    (r"\bguarantee(d|s)?\b.{0,40}\$|\$.{0,40}\bguarantee(d|s)?\b", "guaranteed money outcome (policy 2)"),
    (r"\b(shocking|doctors hate|this one weird trick)\b", "sensational language (policy 5)"),
    (r"\bfacebook[- ]approved\b|\bendorsed by (facebook|meta|instagram)\b", "Meta brand misuse (policy 7)"),
]

fails, warns = [], []


def fail(m):
    fails.append(m)


def warn(m):
    warns.append(m)


def load_map(path):
    """(section, row) pairs present in the Goliath Content(TM) Map CSV (21 rows per section, in order)."""
    rows, count = set(), Counter()
    with open(path, encoding="utf-8-sig") as fh:
        for r in csv.DictReader(fh):
            m = re.match(r"\s*(\d+)", r.get("Section", ""))
            if m:
                n = int(m.group(1))
                count[n] += 1
                rows.add((n, count[n]))
    return rows


VIEWER = r"\b(you|you'll|you’ll|your|you're|you’re|yours|you can|you will)\b"


def income_aimed_at_viewer(sent):
    """True when a sentence gives the viewer a money result ('you'll make $10K', 'your first $100K month').
    Prices ('your $27 seat'), offer qualifiers ('a $3K+ offer') and results owned by I/we/they pass."""
    s = sent.lower()
    s = re.sub(r"\$\s?[\d,.]+\s?k?\+?\s*(offers?|seats?|tickets?|vip|or more|upgrade)\b"
               r"|\b(for|is|at|just|only|costs?)\s+\$\s?[\d,.]+", " ", s)
    words = s.split()
    for i, w in enumerate(words):
        if re.match(r"\$?\d[\d,.]*\s?(k|m)?\+?$", w) and ("$" in w or re.match(r"\d+(k|m)$", w) or
                (i + 1 < len(words) and words[i + 1] in ("thousand", "million"))):
            if "$" not in w and not re.match(r"\d+(k|m)$", w) and not (i + 1 < len(words) and words[i + 1] in ("thousand", "million")):
                continue
            window = " ".join(words[max(0, i - 6): i])
            if re.search(VIEWER, window):
                return True
    return bool(re.search(r"\byou('ll|’ll| will| can| could| are going to|'re going to)?\s+(make|earn|bank|generate|close)\b.{0,40}\$", s))


def section(text, heading):
    i = text.find(heading)
    if i < 0:
        return ""
    nxt = re.search(r"^## ", text[i + len(heading):], re.M)
    return text[i + len(heading): i + len(heading) + nxt.start()] if nxt else text[i + len(heading):]


def field(block, label):
    m = re.search(r"^\*\*" + re.escape(label) + r":\*\*[ \t]*(.*)$", block, re.M)
    return m.group(1).strip() if m else None


LINK = re.compile(r"👉[^\n]*?(https?://\S+|\[MISSING CONTENT[^\]]*link[^\]]*\])", re.I)


def strip_flags(s):
    return re.sub(r"\[MISSING CONTENT[^\]]*\]", "", s)


def main():
    ap = argparse.ArgumentParser(description="Dragon Fire Ads(TM) ad pack checker")
    ap.add_argument("pack")
    who = ap.add_mutually_exclusive_group(required=True)
    who.add_argument("--client", help="the business name, as in the frontmatter")
    who.add_argument("--coach-launch", action="store_true", help="Coach Launch's own pack")
    ap.add_argument("--tool", action="append", default=[], help="tool/system name(s) never preceded by 'the'")
    ap.add_argument("--system", action="append", default=[],
                    help="the business's signature system name(s) (e.g. the Magic Formula(TM) name) — never named in an ad; "
                         "it's introduced inside the virtual event")
    ap.add_argument("--map", help="the Goliath Content(TM) Map CSV, to check every hook citation exists")
    args = ap.parse_args()
    coach_launch = args.coach_launch
    text = open(args.pack, encoding="utf-8").read()
    map_rows = load_map(args.map) if args.map else None

    # frontmatter
    if not text.lstrip().startswith("---"):
        fail("No YAML frontmatter.")
        fm = ""
    else:
        fm = text.split("---", 2)[1]
        for k in FM_KEYS:
            if not re.search(rf"^{k}:", fm, re.M):
                fail(f"Frontmatter is missing '{k}:'.")
        d = re.search(r"^destination:\s*(.+)$", fm, re.M)
        if d and not any(x in d.group(1) for x in DESTINATIONS):
            fail(f"destination '{d.group(1).strip()}' is not one of {DESTINATIONS}.")
    body = text.split("---", 2)[2] if fm else text
    c = re.search(r"^client:\s*(.+)$", fm, re.M)
    if args.client and c and args.client.lower() not in c.group(1).lower():
        fail(f"--client '{args.client}' doesn't match frontmatter client '{c.group(1).strip()}'.")
    if not coach_launch and re.search(r"\bCoach Launch\b|\bMatthew White\b", body):
        fail("A client pack mentions Coach Launch or Matthew White.")

    for h in HEADINGS:
        if h not in body:
            fail(f"Missing heading '{h}'.")

    # the promise, the callout and congruency (brief)
    brief = section(body, "## 1 · THE CAMPAIGN BRIEF")
    norm = lambda x: re.sub(r"\s+", " ", x.replace("’", "'").replace("“", '"').replace("”", '"')).strip().lower()
    prom_f, call_f = field(brief, "Promise"), field(brief, "Callouts")
    page_f, match_f = field(brief, "Page headline"), field(brief, "Message match")
    promises = [p for p in re.findall(r'"([^"]+)"', prom_f or "") if p.strip()]
    callouts = [c.strip() for c in re.findall(r'"([^"]+)"', call_f or "") if c.strip()]
    if call_f and not 3 <= len(callouts) <= 5:
        fail(f"'**Callouts:**' needs 3–5 quoted callout variants, found {len(callouts)}.")
    used_callouts = Counter()
    for lab, v in (("Promise", prom_f), ("Callouts", call_f), ("Page headline", page_f), ("Message match", match_f)):
        if not v:
            fail(f"The brief needs '**{lab}:**' — the promise, the callout and congruency are checked on every pack.")
    if prom_f and not promises:
        fail("'**Promise:**' must quote the locked $Million Promise™ verbatim (or the test variants), in double quotes.")
    if match_f:
        m = match_f.lower()
        if "✗" in match_f and "test" not in m:
            fail("Message match is ✗ — update the page to the promise (cl-cash-flow-funnel-builder) or declare a promise test.")
        if "test" in m and len(promises) < 2:
            fail("A promise test needs at least two quoted variants on the '**Promise:**' line.")
        if "✔" in match_f and promises and page_f and not any(
                len(set(norm(p).split()) & set(norm(page_f).split())) >= 0.5 * len(set(norm(p).split())) for p in promises):
            warn("Message match says ✔ but the page headline shares less than half the promise's words — check it.")

    # ads
    ads_sec = section(body, "## 3 · THE ADS")
    blocks = re.split(r"^### ", ads_sec, flags=re.M)[1:]
    found = [b.split()[1] if len(b.split()) > 1 else "" for b in blocks]
    rt_blocks = [b for b in re.split(r"^### ", section(body, "## 7 · RETARGETING"), flags=re.M)[1:] if "**Hooks:**" in b]
    used_rows = {}
    for a in ANGLES:
        if a not in found:
            fail(f"Section 3 has no '### Ad {a} · …' block.")
    first_lines = []
    for b in blocks + rt_blocks:
        name = b.splitlines()[0].strip()
        is_rt = b in rt_blocks
        where = f"[{name}]"
        hooks = re.findall(r"^\d\.\s+(.+?)(?:\s+—\s+\*Map\s+([^*]+)\*)?\s*$",
                           b.split("**Primary text (short):**")[0], re.M)
        if len(hooks) < 3:
            fail(f"{where} needs 3 hooks, found {len(hooks)}.")
        for h, cite in hooks:
            m = re.fullmatch(r"S(\d+)·R(\d+) (\w[\w ]*)", (cite or "").strip())
            if not m:
                fail(f"{where} hook needs a map citation '— *Map S#·R# <Hook>*': \"{h[:60]}\"")
            else:
                sec, row = int(m.group(1)), int(m.group(2))
                if not 7 <= row <= 21:
                    fail(f"{where} hook cites row {row} — hooks are Slingshot Hook rows 7–21.")
                if map_rows is not None and (sec, row) not in map_rows:
                    fail(f"{where} hook cites S{sec}·R{row}, which isn't in the map CSV.")
                if not is_rt:
                    angle = name.split()[1] if len(name.split()) > 1 else name
                    other = used_rows.setdefault((sec, row), angle)
                    if other != angle:
                        fail(f"{where} hook row S{sec}·R{row} is already used by {other} — no two angles share a row.")
            first_lines.append((where, " ".join(h.lower().split()[:3])))
        for label, lim in LIMITS.items():
            v = field(b, label)
            if v is None:
                fail(f"{where} missing '**{label}:**'.")
            else:
                vv = strip_flags(v.split("👉")[0]).rstrip() if label == "Primary text (short)" else strip_flags(v)
                if len(vv) > lim:
                    fail(f"{where} {label} is {len(vv)} chars (limit {lim}{', before the 👉 link line' if '👉' in v else ''}): \"{v}\"")
        btn = field(b, "CTA button")
        if btn is None:
            fail(f"{where} missing '**CTA button:**'.")
        elif btn not in BUTTONS:
            warn(f"{where} CTA button '{btn}' isn't on the usual Meta list — check it exists.")
        short_v = field(b, "Primary text (short)") or ""
        if not LINK.search(short_v):
            fail(f"{where} the short primary text ends with the link line: '👉 <call to action>: <registration URL>' "
                 "(or [MISSING CONTENT — registration link]) — people click from the text, not just the button.")
        hit = [c for c in callouts if norm(c).rstrip(":?.…") in norm(short_v[:125])]
        if callouts and not is_rt:
            if not hit:
                fail(f"{where} the short primary text must open with one of the callout variants (inside 125 characters).")
            else:
                used_callouts[hit[0]] += 1
        long_m = re.search(r"\*\*Primary text \(long\):\*\*(.*?)\*\*Headline:", b, re.S)
        if long_m and not is_rt:
            paras0 = [p for p in re.split(r"\n\s*\n", long_m.group(1).strip()) if p.strip()]
            if callouts and paras0 and not any(norm(c).rstrip(":?.…") in norm(paras0[0]) for c in callouts):
                fail(f"{where} the long primary text's first paragraph must carry one of the callout variants.")
            body_p = [q for q in paras0 if not q.strip().lower().startswith("results not typical")]
            if body_p and not (LINK.search(body_p[0]) and LINK.search(body_p[-1])):
                fail(f"{where} the long primary text carries the 👉 link line twice — at the end of the first paragraph "
                     "(its own line) and at the end of the last.")
            if promises and not any(norm(p) in norm(long_m.group(1)) for p in promises):
                fail(f"{where} the long primary text must carry the $Million Promise™ word for word.")
        if not long_m:
            fail(f"{where} missing '**Primary text (long):**' before the headline.")
        else:
            paras = [p for p in re.split(r"\n\s*\n", long_m.group(1).strip()) if p.strip()]
            words = len(strip_flags("\n".join(l for l in long_m.group(1).splitlines() if "👉" not in l)).split())
            if len(paras) < 5:
                fail(f"{where} long primary text has {len(paras)} paragraphs — one per act (5).")
            if not 60 <= words <= 180:
                warn(f"{where} long primary text is {words} words (aim 60–180).")
            if re.search(r"\[(Serendipity|Connection|Opportunity|Reality|Execution)\]", long_m.group(1)):
                fail(f"{where} act labels left in the copy.")
            if paras and paras[-1].rstrip().endswith("?"):
                warn(f"{where} long copy ends on a question — Execution ends on an instruction.")
        sc = field(b, "SCORE™")
        nums = [int(n) for n in re.findall(r"\b[SCORE]\s?([1-5])\b", sc or "")]
        if len(nums) != 5:
            fail(f"{where} needs '**SCORE™:** S n · C n · O n · R n · E n = nn/25' with five scores 1–5.")
        elif any(n <= 2 for n in nums):
            fail(f"{where} an act scores 2 or below — floor rule, doesn't ship.")
    if callouts and len(blocks) >= 3 and len(used_callouts) < min(3, len(callouts)):
        warn(f"Only {len(used_callouts)} callout variant(s) used across {len(blocks)} ads — spread at least 3 so the callout gets tested.")
    for k, c in Counter(f for _, f in first_lines).items():
        if c > 1 and k:
            warn(f"{c} hooks open with the same three words '{k}'.")

    # copy rules across the copy sections
    copy_heads = ["## 1 · THE CAMPAIGN BRIEF", "## 2 · THE ANGLE MAP", "## 3 · THE ADS", "## 4 · THE CREATIVES",
                  "## 5 · THE VIDEO ADS", "## 6 · CAMPAIGN SETUP", "## 7 · RETARGETING", "## 8 · CLICK-TO-MESSAGE"]
    lines = [(h, ln) for h in copy_heads for ln in section(body, h).splitlines()]
    for h, line in lines:
        for p in promises:
            line = re.sub(re.escape(p), "", line, flags=re.I)
        low = line.lower()
        if line.lstrip().startswith(("**Creative:", "**SCORE", "**Shot notes", "**Sources:")) or (
                h == "## 6 · CAMPAIGN SETUP" and re.search(r"pixel|capi|conversion|optimi", low)):
            low_copy = ""
        else:
            low_copy = re.sub(r"event magnet™?s?|virtual_event", "", low)
        if re.search(r"(?<!virtual )\bevents?\b", low_copy):
            fail(f"Bare 'event' — say virtual event or the format: \"{line.strip()[:90]}\"")
        if re.search(r"(?<!virtual )\brooms?\b", low_copy):
            fail(f"'room' without 'virtual': \"{line.strip()[:90]}\"")
        if re.search(r"\bThe [A-Z][\w'’]*(?: [A-Z][\w'’]*)*™", line):
            warn(f"'The' in front of a ™ name: \"{line.strip()[:90]}\"")
        if h in ("## 3 · THE ADS", "## 5 · THE VIDEO ADS", "## 7 · RETARGETING", "## 8 · CLICK-TO-MESSAGE") \
                and not line.lstrip().startswith(("**Creative:", "**SCORE", "**Shot notes")):
            for sy in args.system:
                if sy.lower().rstrip("®™") in low:
                    fail(f"Names the signature system '{sy}' in an ad — the ads hook with the tool and the result; "
                         f"the system is introduced inside the virtual event: \"{line.strip()[:90]}\"")
        for t in args.tool:
            if re.search(r"\bthe\s+" + re.escape(t.lower()), low):
                fail(f"'the' in front of '{t}': \"{line.strip()[:90]}\"")
        for w in AI_WORDS:
            if re.search(rf"\b{re.escape(w)}", low):
                warn(f"AI word '{w}': \"{line.strip()[:90]}\"")
        for sent in re.split(r"(?<=[.!?…])\s+", low_copy if low_copy else ""):
            if income_aimed_at_viewer(sent):
                fail(f"Income claim aimed at the viewer — report it from I / we / they / our clients: \"{sent.strip()[:90]}\"")
        for rx, why in POLICY:
            if re.search(rx, low):
                fail(f"Policy risk — {why}: \"{line.strip()[:90]}\"")
        if re.search(r"\b(replay|recording)\b", low) and h != "## 7 · RETARGETING":
            warn(f"Mentions a replay/recording — never promised on a free virtual event: \"{line.strip()[:90]}\"")
        if re.search(r"\b(this|next|on) (mon|tues|wednes|thurs|fri|satur|sun)day\b|\b\d{1,2}(:\d{2})?\s?(am|pm)\b"
                     r"|\b\d{1,2}(st|nd|rd|th)? (jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\b", low):
            warn(f"Date/time in copy — evergreen unless the operator asked: \"{line.strip()[:90]}\"")

    for r in RETIRED:
        if r in text:
            fail(f"Retired marker {r} — the only flag is [MISSING CONTENT — …].")
    if not coach_launch and re.search(r"\$\s?24\.6|\$\s?5\.2\s?(M|million)", text, re.I):
        fail("Matthew's credentials appear in a client pack.")
    for line in body.splitlines():
        scrub = re.sub(r"Ad A\d|\|\s*A\d\s|\bA\d (Recognition|Seen|The Tool|Proof|The Door)|\[A\d\]|\bA[1-5]\b(?=[-·,)])", "", line)
        if re.search(r"\bA[345]\b|\b(letter|legal) size\b|\bA-size\b", scrub) and not re.search(r"\b(angle|lead angle)\b", scrub.lower()):
            fail(f"Paper size named — never on client-facing items: \"{line.strip()[:90]}\"")

    missing = re.findall(r"\[MISSING CONTENT[^\]]*\]", text)
    listed = section(body, "## 10 · MISSING CONTENT")
    for m in set(missing):
        if m not in listed:
            fail(f"{m} isn't listed in section 10.")

    print(f"Ads: {len(blocks)} · hooks: {len(first_lines)} · [MISSING CONTENT] flags: {len(missing)}")
    for m, c in Counter(missing).items():
        print(f"   {c} × {m}")
    for w in warns:
        print("WARN  " + w)
    for f in fails:
        print("FAIL  " + f)
    print("RESULT: " + ("PASS" if not fails else f"FAIL ({len(fails)})"))
    sys.exit(1 if fails else 0)


if __name__ == "__main__":
    main()
