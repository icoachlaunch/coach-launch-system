#!/usr/bin/env python3
"""Dragon Fire Ads(TM) Plan tools.

  calendar  — the day-by-day budget table for one cycle (markdown, paste into the map)
  check     — validates an ad-system-map.md against references/map-template.md and writes the CSV tracker

    python3 plan_tools.py calendar --event 2026-11-26 --start 19:00 --tz Australia/Melbourne \\
        --budget 1500 --currency AUD --schedule fortnightly [--attract-share 0.05] [--engage-share 0.10]
    python3 plan_tools.py check ad-system-map.md --client "Maya Reid Coaching" --tool "Empty Slot Audit" \\
        --map goliath-content-map.csv --csv ad-system-map.csv

Exit 0 = pass. 1 = at least one FAIL. WARN lines are judgement calls.
"""
import argparse
import csv
import datetime as dt
import re
import sys
from collections import Counter

# ---------------------------------------------------------------- calendar

STAGES = ["Attract", "Engage", "Convert", "Motivate"]


def build_days(budget, a, floors=True):
    """Per-day amounts for D-14..D0. Attract and Engage take their share, never below their floor."""
    fa, fe, fc, fm = a.floors
    at = max(budget * a.attract_share / 15, fa) if floors else budget * a.attract_share / 15
    en = max(budget * a.engage_share / 15, fe) if floors else budget * a.engage_share / 15
    rest = budget - 15 * (at + en)
    early = rest * a.early_share / 7                    # D-14..D-8, all Convert
    full = (rest * (1 - a.early_share) - early / 2) / 7.5  # D-6..D0; D-7 at the midpoint
    mid = (early + full) / 2
    days = []
    for d in range(14, -1, -1):
        if d >= 8:
            cv, mo = early, 0.0
        else:
            t = mid if d == 7 else full
            cv, mo = t * 0.75, t * 0.25
        days.append((d, {"Attract": at, "Engage": en, "Convert": cv, "Motivate": mo}))
    return days, rest


def floor_breaks(days, rest, a):
    fa, fe, fc, fm = a.floors
    if rest <= 0:
        return ["the budget doesn't cover Attract and Engage at their floors"]
    out = []
    for stage, floor, live in (("Convert", fc, range(0, 15)), ("Motivate", fm, range(0, 8))):
        low = [(d, v[stage]) for d, v in days if d in live and v[stage] + 1e-9 < floor]
        if low:
            worst = min(x for _, x in low)
            out.append(f"{stage} is under its {floor:g}/day floor on {len(low)} day(s) (lowest {worst:.2f})")
    return out


def minimum_budget(a):
    lo, hi = 0.0, 100000.0
    for _ in range(60):
        m = (lo + hi) / 2
        days, rest = build_days(m, a)
        if floor_breaks(days, rest, a):
            lo = m
        else:
            hi = m
    return hi


def calendar(a):
    event = dt.date.fromisoformat(a.event)
    unit = 100.0 if a.budget is None else a.budget
    days, rest = build_days(unit, a, floors=a.budget is not None)
    mn = minimum_budget(a)
    if rest <= 0:
        print(f"FAIL  {a.currency} {a.budget:,.2f} doesn't cover Attract and Engage at their floors. "
              f"Minimum cycle budget that clears every floor: {a.currency} {mn:,.0f}.")
        sys.exit(1)
    fmt = (lambda v: f"{v:.1f}%") if a.budget is None else (lambda v: f"{a.currency} {v:,.2f}")
    notes = {14: "Convert window opens · Engage week starts",
             7: "Step-up (midpoint) · Motivate on · Engage week starts",
             6: "Full rate",
             0: f"Virtual event — Convert and Motivate off at {a.start}" + (f" {a.tz}" if a.tz else "")}
    out, totals = [], Counter()
    title = "of the cycle budget" if a.budget is None else f"{a.currency} {a.budget:,.2f} cycle budget"
    out.append(f"**Virtual event:** {event.strftime('%a %d %b %Y')} · {a.start}{' ' + a.tz if a.tz else ''} · "
               f"schedule: {a.schedule} · {title}")
    out.append("")
    out.append("| Day | Date | Attract | Engage | Convert | Motivate | Day total | Note |")
    out.append("|---|---|---|---|---|---|---|---|")
    for d, v in days:
        for k in STAGES:
            totals[k] += v[k]
        day = event - dt.timedelta(days=d)
        out.append(f"| {'D-' + str(d) if d else 'D0'} | {day.strftime('%a %d %b')} | {fmt(v['Attract'])} | "
                   f"{fmt(v['Engage'])} | {fmt(v['Convert'])} | {fmt(v['Motivate']) if v['Motivate'] else '—'} | "
                   f"{fmt(sum(v.values()))} | {notes.get(d, '')} |")
    grand = sum(totals.values())
    out.append(f"| **Total** | | {fmt(totals['Attract'])} | {fmt(totals['Engage'])} | {fmt(totals['Convert'])} | "
               f"{fmt(totals['Motivate'])} | **{fmt(grand)}** | |")
    out.append("")
    out.append(f"Split: Attract {a.attract_share * 100:.0f}% and Engage {a.engage_share * 100:.0f}% flat (never under "
               f"their floors) · Convert + Motivate {a.early_share * 100:.0f}% to D-14 → D-8 and "
               f"{100 - a.early_share * 100:.0f}% to D-7 → D0 (Convert 75 / Motivate 25), stepped up through D-7.")
    fa, fe, fc, fm = a.floors
    out.append(f"Floors a day: Attract {fa:g} · Engage {fe:g} · Convert {fc:g} · Motivate {fm:g}.")
    if a.budget is not None:
        pct = totals["Attract"] / a.budget * 100
        if pct > 10.05:
            out.append(f"WARN: Attract is {pct:.1f}% of the budget (guide 3–10%) — its floor is lifting it.")
        breaks = floor_breaks(days, rest, a)
        out.append(f"Minimum cycle budget that clears every floor: {a.currency} {mn:,.0f}.")
        for br in breaks:
            out.append(f"WARN: {br}.")
    else:
        out.append("Cycle budget: [MISSING CONTENT — ad budget per cycle]")
        out.append(f"Minimum cycle budget that clears every floor: {mn:,.0f} (in the floors' currency).")
    if a.schedule == "monthly":
        out.append(f"Between cycles (before D-14): Attract + Engage only — "
                   f"{fmt(a.between_daily) + ' a day' if a.between_daily is not None and a.budget is not None else f'at their floors ({fa:g} + {fe:g} a day) unless the operator sets more'}.")
    print("\n".join(out))
    if a.budget is not None and abs(grand - a.budget) > 0.05:
        print(f"FAIL  totals {grand:.2f} ≠ budget {a.budget:.2f}", file=sys.stderr)
        sys.exit(1)


# ---------------------------------------------------------------- check

HEADINGS = ["## Revision History", "## Your to-do", "## The virtual event", "## The promise", "## The pack — 19 ads",
            "## The Engage rotation", "## The calendar", "## Audiences", "## Running it",
            "## Meta setup checklist", "## The packs, in order", "## Missing content"]
FM_KEYS = ["asset", "client", "version", "last_updated", "status", "schedule", "next_virtual_event",
           "engage_refresh_days"]
SLOTS = [f"AT{i}" for i in range(1, 5)] + [f"EN{i}" for i in range(1, 8)] + \
        [f"CV{i}" for i in range(1, 6)] + [f"MO{i}" for i in range(1, 4)]
LAYER_OF = {"AT": "Attract", "EN": "Engage", "CV": "Convert", "MO": "Motivate"}
STATUSES = ["planned", "copy", "creative", "live"]
RETIRED = ["[PROOF NEEDED]", "[CHECK WITH CLIENT]", "[PROVISIONAL]", "[VERIFY]", "UNVERIFIED"]
CITE = re.compile(r"S(\d+)·R(\d+)")
DATE = re.compile(r"\b\d{1,2}(st|nd|rd|th)? (jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\b"
                  r"|\b(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]* \d{1,2}(st|nd|rd|th)?\b|\b(tonight|tomorrow)\b"
                  r"|\b(this|next|on) (mon|tues|wednes|thurs|fri|satur|sun)day\b|\b\d{1,2}(:\d{2})?\s?(am|pm)\b"
                  r"|\b20\d\d-\d\d-\d\d\b", re.I)

fails, warns = [], []


def fail(m):
    fails.append(m)


def warn(m):
    warns.append(m)


def section(text, heading):
    i = text.find(heading)
    if i < 0:
        return ""
    rest = text[i + len(heading):]
    m = re.search(r"^## ", rest, re.M)
    return rest[: m.start()] if m else rest


def cells(line):
    return [c.strip() for c in line.strip().strip("|").split("|")]


def load_map(path):
    rows, count, titles = set(), Counter(), {}
    with open(path, encoding="utf-8-sig") as fh:
        for r in csv.DictReader(fh):
            m = re.match(r"\s*(\d+)", r.get("Section", ""))
            if m:
                n = int(m.group(1))
                count[n] += 1
                rows.add((n, count[n]))
                titles[(n, count[n])] = r.get("Working Title", "")
    return rows, titles


def copy_rules(line, where, tools, coach_launch):
    low = line.lower()
    scrub = re.sub(r"event magnet™?s?|virtual_event|dragon fire ads™?", "", low)
    if re.search(r"(?<!virtual )\bevents?\b", scrub):
        fail(f"{where}: bare 'event' — say virtual event or the format: \"{line.strip()[:90]}\"")
    if re.search(r"(?<!virtual )\brooms?\b", scrub):
        fail(f"{where}: 'room' without 'virtual': \"{line.strip()[:90]}\"")
    for t in tools:
        if re.search(r"\bthe\s+" + re.escape(t.lower()), low):
            fail(f"{where}: 'the' in front of '{t}': \"{line.strip()[:90]}\"")
    if re.search(r"\bA[345]\b|\bA-size\b|\b(letter|legal) size\b", line):
        fail(f"{where}: paper size named: \"{line.strip()[:90]}\"")
    if not coach_launch and re.search(r"\$\s?24\.6|\$\s?5\.2\s?(m|million)|matthew white", low):
        fail(f"{where}: Matthew's name or figures in a client map.")
    m = re.search(r"\b(you|you'll|you’ll|your|you're|you’re|you can|you will)\b[^.!?]{0,40}\$\s?\d", low)
    if m and not re.search(r"\$\s?[\d,.]+\s?k?\+?\s*(offers?|seats?|tickets?|vip|or more)\b", low):
        warn(f"{where}: a money result aimed at the viewer — the copy skill reframes it to I / we / they: \"{line.strip()[:90]}\"")
    if re.search(r"\b(cpl|roas|ctr|cost per (lead|registration)|show[- ]up rate)\b.{0,20}\d", low):
        fail(f"{where}: a predicted result — the plan never forecasts: \"{line.strip()[:90]}\"")


def check(a):
    text = open(a.map_file, encoding="utf-8").read()
    if not text.lstrip().startswith("---"):
        fail("No YAML frontmatter.")
        fm, body = "", text
    else:
        fm, body = text.split("---", 2)[1], text.split("---", 2)[2]
        for k in FM_KEYS:
            if not re.search(rf"^{k}:", fm, re.M):
                fail(f"Frontmatter missing '{k}:'.")
        s = re.search(r"^schedule:\s*(\S+)", fm, re.M)
        if s and s.group(1) not in ("fortnightly", "monthly"):
            fail("schedule must be fortnightly or monthly.")
        n = re.search(r"^engage_refresh_days:\s*(\d+)", fm, re.M)
        if n and int(n.group(1)) not in (7, 14):
            fail("engage_refresh_days must be 7 or 14.")
        c = re.search(r"^client:\s*(.+)$", fm, re.M)
        if a.client and c and a.client.lower() not in c.group(1).lower():
            fail(f"--client '{a.client}' doesn't match frontmatter client '{c.group(1).strip()}'.")
    for h in HEADINGS:
        if h not in body:
            fail(f"Missing heading '{h}'.")
    prom = section(body, "## The promise")
    for lab in ("Promise", "Callouts", "Page headline", "Message match"):
        if not re.search(r"^\*\*" + re.escape(lab) + r":\*\*\s*\S", prom, re.M):
            fail(f"'## The promise' needs '**{lab}:**' filled in.")
    mm = re.search(r"^\*\*Message match:\*\*(.*)$", prom, re.M)
    if mm and "✗" in mm.group(1) and "funnel" not in mm.group(1).lower():
        fail("Message match is ✗ — name the page fix (cl-cash-flow-funnel-builder) or declare a promise test.")
    if mm and "test" in mm.group(1).lower() and len(re.findall(r'"[^"]+"', prom.split("**Callouts:**")[0])) < 2:
        fail("A promise test needs two quoted variants on the '**Promise:**' line.")

    map_rows, map_titles = load_map(a.map) if a.map else (None, {})

    # the pack
    pack = [cells(l) for l in section(body, "## The pack — 19 ads").splitlines()
            if l.strip().startswith("|") and re.match(r"\|\s*(AT|EN|CV|MO)\d", l.strip())]
    ids = [r[0] for r in pack]
    for s in SLOTS:
        if ids.count(s) != 1:
            fail(f"Slot {s} appears {ids.count(s)} times in the pack (needs exactly 1).")
    extra = [i for i in ids if i not in SLOTS]
    if extra or len(pack) != 19:
        fail(f"The pack has {len(pack)} slots (needs exactly 19){' — extra: ' + ', '.join(extra) if extra else ''}.")
    used, out_rows = Counter(), []
    sec_of = {}
    for r in pack:
        if len(r) != 9:
            fail(f"{r[0]}: needs 9 columns (Slot · Stage · Format · Content type · Source · Working idea · Needs · Live · Status).")
            continue
        slot, layer, fmt, angle, src, idea, needs, live, status = r
        pre = slot[:2]
        if layer != LAYER_OF.get(pre, ""):
            fail(f"{slot}: stage should be '{LAYER_OF.get(pre)}', found '{layer}'.")
        if status not in STATUSES:
            fail(f"{slot}: status '{status}' — use {STATUSES}.")
        cites = CITE.findall(src)
        if not cites:
            if src.startswith("Spec B") and pre == "MO":
                pass
            elif "[MISSING CONTENT" in src:
                warn(f"{slot}: no source row — carries a missing-content flag.")
            else:
                fail(f"{slot}: source must cite a map row 'S#·R#' (Motivate may cite 'Spec B2'): '{src}'.")
        for sn, rn in cites:
            key = (int(sn), int(rn))
            used[key] += 1
            sec_of.setdefault(pre, set()).add(key[0])
            if map_rows is not None and key not in map_rows:
                fail(f"{slot}: S{sn}·R{rn} isn't in the map CSV.")
            base = idea.split(" · ")[0] if pre == "MO" else idea
            if map_titles.get(key) and base and map_titles[key].strip().rstrip(".!?").lower() != base.strip().rstrip(".!?").lower() \
                    and "[" not in base:
                warn(f"{slot}: working idea differs from the map title for S{sn}·R{rn}.")
        if pre != "MO" and DATE.search(idea + " " + angle):
            fail(f"{slot}: only Motivate ads carry a date: '{idea[:60]}'.")
        if pre == "MO" and not (DATE.search(idea) or "[date]" in idea):
            fail(f"{slot}: a Motivate ad carries the virtual event's date — none found in '{idea[:60]}'.")
        if pre == "MO" and "d-7" not in live.lower():
            fail(f"{slot}: Motivate ads run D-7 → D0 only, found '{live}'.")
        if "d-15" in live.lower() or re.search(r"d-(1[5-9]|[2-9]\d)", live.lower()):
            fail(f"{slot}: nothing runs more than 14 days out ('{live}').")
        copy_rules(idea, slot, a.tool, a.coach_launch)
        out_rows.append([slot, layer, fmt, angle, src, idea, needs, live, status])

    # section rules
    cv_mo = sec_of.get("CV", set()) | sec_of.get("MO", set())
    if len(cv_mo) > 1:
        warn(f"Convert and Motivate draw from more than one section ({sorted(cv_mo)}) — both should use the magnet's section.")
    if sec_of.get("AT") and sec_of["AT"] != {1}:
        warn(f"Attract draws from sections {sorted(sec_of['AT'])} — it should use Section 1 (the whole system).")
    if sec_of.get("EN") and (sec_of["EN"] & (cv_mo | {1})):
        fail("Engage reuses the magnet's section or Section 1 — Engage takes one other section per week.")

    # rotation
    rot = [cells(l) for l in section(body, "## The Engage rotation").splitlines()
           if re.match(r"\|\s*EN\d", l.strip())]
    if [r[0] for r in rot] != [f"EN{i}" for i in range(1, 8)]:
        fail("The Engage rotation needs rows EN1–EN7, in order.")
    week_secs = {1: set(), 2: set()}
    en_pack = {r[0]: r[4] for r in pack if r[0].startswith("EN") and len(r) == 9}
    for r in rot:
        if len(r) < 3:
            fail(f"{r[0]}: rotation needs Week 1 and Week 2 cells.")
            continue
        for w, cell in ((1, r[1]), (2, r[2])):
            cs = CITE.findall(cell)
            if not cs:
                fail(f"{r[0]} week {w}: cite the row 'S#·R# — title'.")
                continue
            key = (int(cs[0][0]), int(cs[0][1]))
            week_secs[w].add(key[0])
            if w == 2:
                used[key] += 1
            if map_rows is not None and key not in map_rows:
                fail(f"{r[0]} week {w}: S{key[0]}·R{key[1]} isn't in the map CSV.")
            copy_rules(cell, f"{r[0]} week {w}", a.tool, a.coach_launch)
        if r[0] in en_pack and CITE.findall(en_pack[r[0]])[:1] != CITE.findall(r[1])[:1]:
            fail(f"{r[0]}: the pack's source and rotation week 1 don't match.")
    for w in (1, 2):
        if len(week_secs[w]) > 1:
            fail(f"Engage week {w} mixes sections {sorted(week_secs[w])} — one section per week.")
    if week_secs[2] & (cv_mo | {1}):
        fail("Engage week 2 uses the magnet's section or Section 1 — Engage takes one other section per week.")
    if week_secs[1] and week_secs[1] == week_secs[2]:
        fail("Engage weeks 1 and 2 use the same section.")

    for key, c in used.items():
        if c > 1:
            fail(f"Row S{key[0]}·R{key[1]} feeds {c} slots — one row, one slot.")

    # to-do and general text
    for line in section(body, "## Your to-do").splitlines():
        if line.strip():
            copy_rules(line, "to-do", a.tool, a.coach_launch)
    for r in RETIRED:
        if r in text:
            fail(f"Retired marker {r} — the only flag is [MISSING CONTENT — …].")
    if not a.coach_launch and re.search(r"\$\s?24\.6|\$\s?5\.2\s?(M|million)", text, re.I):
        fail("Matthew's figures appear in a client map.")
    missing = re.findall(r"\[MISSING CONTENT[^\]]*\]", text)
    listed = section(body, "## Missing content")
    for m in set(missing):
        if m not in listed:
            fail(f"{m} isn't listed under '## Missing content'.")

    print(f"Slots: {len(pack)} · rotation rows: {len(rot)} · rows cited: {len(used)} · "
          f"[MISSING CONTENT] flags: {len(missing)}")
    for m, c in Counter(missing).items():
        print(f"   {c} × {m}")
    for w in warns:
        print("WARN  " + w)
    for f in fails:
        print("FAIL  " + f)
    if a.csv and not fails:
        rot_w2 = {r[0]: r[2] for r in rot if len(r) >= 3}
        with open(a.csv, "w", newline="", encoding="utf-8-sig") as fh:
            wr = csv.writer(fh, quoting=csv.QUOTE_ALL)
            wr.writerow(["Slot", "Stage", "Format", "Content type", "Source", "Working idea", "Needs", "Live",
                         "Status", "Engage week 2"])
            for r in out_rows:
                wr.writerow(r + [rot_w2.get(r[0], "")])
        print(f"CSV written: {a.csv} ({len(out_rows)} rows + header)")
    elif a.csv:
        print("CSV NOT written — fix the FAIL lines first.")
    print("RESULT: " + ("PASS" if not fails else f"FAIL ({len(fails)})"))
    sys.exit(1 if fails else 0)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    c = sub.add_parser("calendar")
    c.add_argument("--event", required=True, help="YYYY-MM-DD of the virtual event")
    c.add_argument("--start", default="[start time]")
    c.add_argument("--tz", default="")
    c.add_argument("--budget", type=float)
    c.add_argument("--currency", default="AUD")
    c.add_argument("--schedule", choices=["fortnightly", "monthly"], default="fortnightly")
    c.add_argument("--between-daily", type=float)
    c.add_argument("--attract-share", type=float, default=0.05, help="3-10%% guide (default 0.05)")
    c.add_argument("--engage-share", type=float, default=0.10)
    c.add_argument("--early-share", type=float, default=0.30, help="Convert share before D-7 (default 0.30)")
    c.add_argument("--floors", type=lambda x: [float(v) for v in x.split(",")], default=[5, 5, 50, 20],
                   help="daily floors Attract,Engage,Convert,Motivate (default 5,5,50,20)")
    k = sub.add_parser("check")
    k.add_argument("map_file")
    who = k.add_mutually_exclusive_group(required=True)
    who.add_argument("--client")
    who.add_argument("--coach-launch", action="store_true")
    k.add_argument("--tool", action="append", default=[])
    k.add_argument("--map", help="the Goliath Content(TM) Map CSV")
    k.add_argument("--csv", help="write the slot tracker here on a PASS")
    a = ap.parse_args()
    calendar(a) if a.cmd == "calendar" else check(a)


if __name__ == "__main__":
    main()
