# Calendar, budget, audiences and running it

## Contents
1. The window
2. The budget model (defaults + floors)
3. Stage settings — objectives, audiences, KPIs
4. Running it — PIXIE and FIRE
5. Meta setup checklist

---

## 1 · The window

Days count back from the virtual event: **D-14 … D-1, D0** (the day itself; Convert and Motivate stop at the
start time, so D0 underspends its amount — that's expected).

| Days | Attract | Engage | Convert | Motivate |
|---|---|---|---|---|
| Always (between cycles too) | on, small | on, 7-day rotation | — | — |
| D-14 → D-8 | on | on (new set starts D-14) | on | off |
| D-7 → D0 | on | on (new set on D-7 when refreshing every 7 days) | on, stepped up | **on** |

Convert never starts earlier than D-14 — earlier spend wastes the first week and lowers show-up. On a
fortnightly schedule one cycle's D-14 is the last one's D0, so Convert effectively never stops and the budget
pulses; its ads carry no date and point at the page that always shows the next one. On a monthly schedule
Convert is off between cycles while Attract and Engage keep running.

## 2 · The budget model (defaults — the operator can change any of them)

The **cycle budget** covers D-14 → D0 (15 days) across all four stages.

1. **Attract** — 5% of the cycle budget (range 3–10%), flat across the 15 days. Floor **$5 a day**.
2. **Engage** — 10% by default (it depends on the audience's size), flat. Floor **$5 a day**.
3. **Convert + Motivate** share the rest: **30% to D-14 → D-8, 70% to D-7 → D0**.
   - D-14 → D-8: all Convert.
   - D-7 → D0: Convert 75%, Motivate 25%.
   - Floors: Convert **$50 a day**, Motivate **$20 a day**. The upper level depends on the return and the
     business's risk appetite.
4. **Stepped, not jumped:** D-7 runs at the midpoint between the opening week's Convert rate and the final
   week's, so delivery doesn't reset. Set it ahead with Meta's budget scheduling, or raise it by hand on D-7
   and D-6.
5. **Between cycles** (monthly): Attract + Engage at their floor (or the operator's amount) a day.

`plan_tools.py calendar` does the maths, warns when any stage falls under its floor and prints the minimum
cycle budget that clears every floor. Floors are in the budget's currency — convert them for a non-AUD/USD
account and say so. Budgets are planning amounts, never predictions of what they'll return.

## 3 · Stage settings — objectives, audiences, KPIs

Platforms: Facebook and Instagram by default; YouTube and LinkedIn are options the operator turns on.
Geography and age come from the Golden Avatar™. Interest layers are suggestions — never claimed as tested.

| Stage | Objective | Audience | Exclude | KPIs to watch |
|---|---|---|---|---|
| **Attract** | Facebook: Engagement · Awareness · Traffic. YouTube: Product and Brand Consideration | Interest audiences 200k–2M, targeted layers, 6-month penetration | Current clients | Cost per video view · CPM · impressions |
| **Engage** | Facebook & YouTube: Awareness with a **frequency cap of 3–4 a week**; Engagement. LinkedIn: Community Interaction · Video Views | Custom audiences: all website visitors · registration (ticket) page visitors · Facebook & Instagram engagers · customer list · 50% video viewers of Attract · 10% video viewers of the ads | Current clients (unless upselling) | Impressions · frequency |
| **Convert** | Facebook & YouTube: Registrations (free) or Ticket Sales (paid). LinkedIn: Web Conversions | Interest audiences 200k–2M, targeted layers, 6-month penetration | This cycle's registrants · buyers | Cost per registration / ticket / VIP sold · ROAS · CPC · CTR · CPM |
| **Motivate** | Facebook & YouTube: Landing Page Views · Ticket Sales. LinkedIn: Web Conversions | Retargeting: **registration-page visitors** (last 14 days) — see the note below | Buyers of the core offer | Cost per registration / ticket / VIP sold · ROAS · CPC · CTR · CPM |

**Motivate's audience.** The ad's job is the reminder that gets people there live, and the visitors who haven't
registered yet are its highest-value target. The default is all registration-page visitors; the operator can
split it into two ad sets (registered · not yet registered) for a big list.

KPIs are what the business watches once ads are live. The plan names them; it never predicts their values.
Targets (cost per registration, ROAS) come from the Money Model, else `[MISSING CONTENT — target cost per
registration, from the Money Model]`.

## 4 · Running it — PIXIE and FIRE

Write these into the map as the running cadence, in the business's plain words.

**Pixie Dust Social™ (Attract + Engage) — PIXIE**
- **Prime content** — start from $5 a day; grow the audience on cost per view, CPM and impressions.
- **Identify targeting** — content that resonates emotionally, educates or sticks primes the algorithm cheaply.
- **Xplode authority** — retarget video viewers with awareness campaigns; change the creatives every 7–14 days.
- **Ignite growth** — increase spend and content cycles as results come in.
- **Engagement, continual** — keep the social warm and open to receive more.

**Dragon Fire Ads™ (Convert + Motivate) — FIRE**
- **Fine-tune cost controls** — once there's data, bid caps, cost caps or target ROAS for efficiency.
- **Initiate auto campaigns** — let the algorithm drive (Advantage+), no day-trading the account.
- **Run new creatives** — add or change creatives every 7–14 days; the winners earn the next ads.
- **Enter scale mode** — scale the budget on what's working.

## 5 · Meta setup checklist (in the map, ticked by the operator)

- [ ] Ad account, Facebook Page and Instagram account connected (YouTube / LinkedIn if used)
- [ ] Pixel / dataset on the registration page (page view) and the confirmation page (registration or purchase)
- [ ] Custom audiences: all website visitors · registration-page visitors (14 days) · registrants this cycle ·
      Facebook & Instagram engagers · customer list · 50% video viewers of Attract · 10% video viewers of the ads ·
      buyers / current clients (exclusions)
- [ ] Engage ad set: frequency cap 3–4 a week
- [ ] Convert budget schedule set for the D-7 step-up
- [ ] Motivate ad set scheduled to start D-7 and end at the start time on D0
- [ ] Attract and Engage content published as posts first, then promoted
- [ ] Naming: `<Stage> | <Business> | <YYYY-MM-DD of the virtual event>` (Attract / Engage: `<Stage> | <Business> | Week <n>`)
