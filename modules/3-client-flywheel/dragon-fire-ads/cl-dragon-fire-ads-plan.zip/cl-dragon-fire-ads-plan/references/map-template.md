# Ad System Map — the output contract

Write the map exactly in this shape. `scripts/plan_tools.py check` reads the headings and the table rows:
never rename, reorder or drop one. An empty section keeps its heading and says `[none]`. One blank line
between every labelled line and after every heading — the business reads this.

````markdown
---
asset: Dragon Fire Ads™ Ad System Map
client: [Business name — or Coach Launch]
version: 1
last_updated: [YYYY-MM-DD]
status: [draft | complete]
schedule: [fortnightly | monthly]
next_virtual_event: [YYYY-MM-DD]
engage_refresh_days: [7 | 14]
---

# DRAGON FIRE ADS™ AD SYSTEM MAP — [Business]

## Revision History

| Version | Date | Changes |
|---|---|---|
| 1 | [YYYY-MM-DD] | Initial build |

## Your to-do

[5–8 short lines in plain words: the filming session (what to record, roughly how long), the Engage pieces
for the next two weeks, what to send (links, budget, photos), the next step. Slot codes only in brackets.]

## The virtual event

**Format:** [free masterclass · …]

**Next date:** [Thu 26 Nov · 7pm AEDT]

**Schedule:** [fortnightly / monthly]

**Registration page:** [link — or [MISSING CONTENT — the registration page link]]

**Event Magnet™:** [name] — "[Tool Promise]" · canvas: [link or [MISSING CONTENT — …]]

**Sources:** Goliath Content™ Map v[n] (M = Section [n] · H = Section [n] · W = Section 1) · SCORE™ Card v[n] · Event Magnet™ Spec [file]

## The promise

**Promise:** "[the locked $Million Promise™, verbatim — or the test variants, labelled P1 / P2]"

**Callouts:** "[statement]" · "[question]" · "[gate]" · "[direct address]" (3–5 variants on the promise's Ideal Audience; the copy skill spreads them across the ads — winners noted here)

**Page headline:** "[the registration page's headline, verbatim]"

**Message match:** [✔ · ✗ — update the page via cl-cash-flow-funnel-builder before Convert goes live · test — P1 → page A, P2 → page B, until a winner is locked]

## The pack — 19 ads

| Slot | Stage | Format | Content type | Source | Working idea | Needs | Live | Status |
|---|---|---|---|---|---|---|---|---|
| AT1 | Attract | Posted video | Myth Busting | S1·R9 | [map title, verbatim] | record | always on | planned |
| AT2 | Attract | Posted video | Business Stories | S1·R11 | […] | record | always on | planned |
| AT3 | Attract | Posted video | Lessons Learned | S1·R4 | […] | record | always on | planned |
| AT4 | Attract | Posted images + text | Edutainment | S1·R1 | […] | build | always on | planned |
| EN1 | Engage | Posted video | Motivation | S6·R1 | […] | record | week 1 | planned |
| EN2 | Engage | Posted video | Limiting Beliefs | S6·R2 | […] | record | week 1 | planned |
| EN3 | Engage | Posted video | Motivation | S6·R3 | […] | record | week 1 | planned |
| EN4 | Engage | Posted video | Case Studies | S6·R4 | […] | record | week 1 | planned |
| EN5 | Engage | Posted video | FOMO | S6·R5 | […] | record | week 1 | planned |
| EN6 | Engage | Posted video | FOMO / Motivation | S6·R6 | […] | record | week 1 | planned |
| EN7 | Engage | Posted images + text | Testimonials | S6·R14 | […] | build | week 1 | planned |
| CV1 | Convert | Image + text | Problem / Solution | S11·R7 | […] | build | D-14 → D0 | planned |
| CV2 | Convert | Video | Credibility & Competence | S11·R10 | […] | record | D-14 → D0 | planned |
| CV3 | Convert | Image + text | Demonstration | S11·R13 | […] | build | D-14 → D0 | planned |
| CV4 | Convert | Image + text | Before / After | S11·R14 | […] | build | D-14 → D0 | planned |
| CV5 | Convert | Video | Us vs Them | S11·R19 | […] | record | D-14 → D0 | planned |
| MO1 | Motivate | Image + text | Reminder | S11·R20 | […] · [date] | build | D-7 → D0 | planned |
| MO2 | Motivate | Video | Takeaways | Spec B2 | […] · [date] | record once | D-7 → D0 | planned |
| MO3 | Motivate | Image + text | Urgency / FOMO | S11·R16 | […] · [date] | build | D-7 → D0 | planned |

## The Engage rotation

**Refresh:** every [7 / 14] days — new set on D-14 (and on D-7 when refreshing every 7 days)

| Slot | Week 1 — Section [n] | Week 2 — Section [n] |
|---|---|---|
| EN1 | S6·R1 — [title] | S2·R1 — [title] |
| EN2 | … | … |
| EN3 | … | … |
| EN4 | … | … |
| EN5 | … | … |
| EN6 | … | … |
| EN7 | … | … |

**Queue after week 2:** Section [n] → Section [n] → …

## The calendar

**Cycle budget:** [amount + currency — or [MISSING CONTENT — ad budget per cycle]] · minimum to clear every floor: [from the script]

[the table printed by plan_tools.py calendar]

## Audiences

| Stage | Objective | Audience | Exclude | KPIs to watch |
|---|---|---|---|---|
| Attract | … | … | … | … |
| Engage | … (frequency cap 3–4 a week) | … | … | … |
| Convert | … | … | … | … |
| Motivate | … | Registration-page visitors (14 days) | … | … |

## Running it

**Pixie Dust Social™ — Attract + Engage (PIXIE):** [the five lines, in plain words]

**Dragon Fire Ads™ — Convert + Motivate (FIRE):** [the four lines, in plain words]

## Meta setup checklist

- [ ] …

## The packs, in order

1. Convert (CV1–CV5) — `cl-dragon-fire-ads`
2. Motivate (MO1–MO3)
3. Attract (AT1–AT4)
4. Engage (EN1–EN7)

## Missing content

- [every [MISSING CONTENT — …] in the map — or [none]]
````

**Must NOT include:** predicted results (CPL, CTR, ROAS, reach, show-up), invented budgets, dates other than the
virtual event's, more than 19 slots, Matthew's figures in a client map, paper sizes, or notes about how the map
was made.
