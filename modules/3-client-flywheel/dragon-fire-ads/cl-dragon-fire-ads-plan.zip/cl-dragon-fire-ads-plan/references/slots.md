# The 19 slots — Attract · Engage · Convert · Motivate

## Contents
1. Where the sources live
2. The four stages
3. Each stage's slots
4. The no-reuse rule and swaps
5. The Engage rotation

---

## 1 · Where the sources live

| Asset | Usual location |
|---|---|
| Goliath Content™ Map (`.md` + `.csv`) | `Client Engine/Client Flywheel/goliath-content/` |
| Event Magnet™ Spec · Visual | `Client Engine/Offer Matrix/event-magnet/` |
| SCORE™ Card | `Client Engine/Offer Matrix/score-card/` |
| Money Model | `Client Engine/Offer Matrix/money-model/` |
| Golden Avatar™ | `Client Engine/Offer Matrix/golden-avatar/` |
| Registration page | `Client Engine/Money Magnet/cash-flow-engine/` |
| Brand Voice · Visual Style Guide | `Reference/` |

**Map rows.** Every map section has 21 rows: row 1 the Goliath Flagship™, rows 2–6 the Five Stones™
(Serendipity · Connection · Opportunity · Reality · Execution), rows 7–21 the Slingshot Hooks™ (7 Mirror · 8
Question · 9 Myth · 10 Again · 11 Turning Point · 12 Pieces · 13 Reveal · 14 Proof · 15 Difference · 16 Calendar ·
17 Snapshot · 18 Real Want · 19 Two Roads · 20 Start Here · 21 Open Door). Section 1 is the whole system;
Sections 2–10 are Steps 1–9; Section 11 onward, one per Event Magnet™. Cite a row as `S11·R7`.

Three sections matter: **M** = the Event Magnet™ section for this virtual event's magnet · **H** = the hot
step's section · **W** = Section 1, the whole system.

## 2 · The four stages

| # | Stage | System | Job | Slots | Runs |
|---|---|---|---|---|---|
| 1 | **Attract** | Pixie Dust Social™ (paid) | Awareness of the host and brand; educational, speaks to the avatar; builds the warm audiences everything else retargets | AT1–AT4 | Always on, small budget |
| 2 | **Engage** | Pixie Dust Social™ (paid) | Retarget the whole circle of influence and keep them engaged and coming back | EN1–EN7 | Always on; 7 pieces, refreshed every 7 days (14 at most) |
| 3 | **Convert** | Dragon Fire Ads™ | Fill the virtual event with people ready to act — registrations or ticket sales | CV1–CV5 | D-14 → D0, stepped up from D-7 |
| 4 | **Motivate** | Dragon Fire Ads™ | Retarget everyone who reached the registration page: remind, motivate, get them there live | MO1–MO3 | D-7 → D0 only; the only ads with a date (the virtual event's) |

Attract and Engage run as **posted content**: the piece is published on the business's page first, then budget
goes behind that post, so its likes and comments build up as social proof. Convert and Motivate run as ads
built for the job (Dragon Fire Ads™).

## 3 · Each stage's slots

### Attract — from section W

Educational, value and story based; a mix of with- and without-CTA. Sells nothing hard.

| Slot | Content type | Source | Format |
|---|---|---|---|
| AT1 | Myth Busting | W row 9 (Myth hook) or row 2 (Serendipity Stone) | Posted video, 30–90 s |
| AT2 | Business Stories | W row 11 (Turning Point) or row 3 (Connection Stone) | Posted video, 30–90 s |
| AT3 | Lessons Learned | W row 4 (Opportunity Stone) | Posted video, 30–90 s |
| AT4 | Edutainment / Brand Awareness | W row 1 (Goliath Flagship™) — the whole system on one swipe | Posted images + text (carousel, the Magic Formula™ visual) |

### Engage — one map section per week (never M or W)

Value and story based, mix of CTAs, soft invite to the next virtual event. One piece a day.

| Slot | Day | Content type | Source (the week's section) | Format |
|---|---|---|---|---|
| EN1 | 1 | Motivation | row 1 Goliath Flagship™ (a 60–90 s cut) | Posted video |
| EN2 | 2 | Limiting Beliefs | row 2 Serendipity Stone | Posted video (or images + text) |
| EN3 | 3 | Motivation | row 3 Connection Stone | Posted video (or images + text) |
| EN4 | 4 | Case Studies | row 4 Opportunity Stone (the system's proof) | Posted video (or images + text) |
| EN5 | 5 | FOMO | row 5 Reality Stone (the cost of staying put) | Posted video (or images + text) |
| EN6 | 6 | FOMO / Motivation | row 6 Execution Stone | Posted video (or images + text) |
| EN7 | 7 | Testimonials | row 14 Proof hook if the proof is real, else row 18 Real Want | Posted images + text or video |

### Convert — from section M (the five SCORE™ angles, in the sheet's content types)

High-value ads designed to get registrations or ticket sales. Execution CTAs. The plan picks the lead row;
the copy skill adds two more hooks from the same act's rows.

| Slot | Content type | SCORE™ angle | Lead row from | Format |
|---|---|---|---|---|
| CV1 | Problem / Solution | Recognition (Serendipity) | M rows 7–9 | Image + text (pain call-out) |
| CV2 | Credibility & Competence | Seen (Connection) | M rows 10–12 | Video — host to camera, 45–75 s |
| CV3 | Demonstration | The Tool (Opportunity) | M row 13 (Reveal) | Image + text (tool hero) |
| CV4 | Before / After | Two Futures (Reality) | M row 14 if the proof is real, else rows 16–17 | Image + text (proof / two roads) |
| CV5 | Us vs Them | The Door (Execution) | M row 19 (Two Roads) | Video — hook reel with the tool, 15–30 s |

No section M yet → Convert and Motivate use H, Engage week 1 moves to the next step after H, and the plan says
so. The copy skill takes its extra hooks only from rows no other slot uses (never Motivate's rows).

### Motivate — from section M + the Event Magnet™ Spec

Retargeting only. Reminders, urgency, FOMO, takeaways. Each carries **one date: the virtual event's**. Scarcity
only if it's genuine (a real cap or a real closing cart) — never a manufactured one.

| Slot | Content type | Source | Format |
|---|---|---|---|
| MO1 | Reminder — "It's on [date]" with the tool | M row 20 (Start Here), else 21 (Open Door) | Image + text (+ date) |
| MO2 | Takeaways — what they'll walk away with, live on [date] | Event Magnet™ Spec B2 (cite `Spec B2`) | Video, 15–20 s — recorded once without a date; Descript adds the date as on-screen text and captions each cycle |
| MO3 | Urgency / FOMO — the cost of missing it + date | an unused M Reality row (16–18) | Image + text (+ date) |

## 4 · The no-reuse rule and swaps

- A map row feeds **one** slot. Attract takes W; Convert and Motivate take M; Engage takes one other section per
  week.
- A row carrying `[MISSING CONTENT — …]` can't feed a slot: take the next row of the same act in the same
  section; none left → the slot carries the flag and is listed.
- **Swapping a tired ad** (new cycle): the next unused row of the same act in the same section.

## 5 · The Engage rotation

- **Week 1 = section H** (the hot step, closest to the virtual event's topic) — unless H is standing in for a
  missing M, then the next step after H. Then Steps 1 → 9 in order, skipping the sections already used; then any
  other Event Magnet™ sections — 8+ weeks before a section repeats.
- The map fills **weeks 1 and 2** in full (14 pieces) and writes the queue for the rest; each new cycle moves
  it on.
- Refresh every **7** days by default, or every **14** — the business decides, the map records it
  (`engage_refresh_days`). On 7, a new week starts on D-14 and on D-7; on 14, a new set starts on D-14 only.
- With the 3–4-a-week frequency cap, each person sees 3–4 of the week's 7 pieces — different people see
  different pieces, which is why the set rotates.
