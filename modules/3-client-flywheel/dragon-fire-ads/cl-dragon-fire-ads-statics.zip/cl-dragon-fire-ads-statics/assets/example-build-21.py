"""WORKED EXAMPLE — Coach Launch's Convert pack, 21 statics (7 concepts x dark / white / photo).

Copy the structure (CSS kit, root(), tool/tool_fill/tool_zoom, photoback, the 7 concept builders), never the
copy, the asset ids or the images, for any other business. SRC points at one existing board on the business's
Dragon Fire Ads canvas (its <head>, <helmet> fonts link and logic <script> are reused verbatim).
Tool placements in CV1 dark/white and promise-led dark are Matthew's own hand edits (the tool breaks the frame).
"""
import re, json, pathlib
S = pathlib.Path(__file__).parent
SRC = (S / "base.dc.html").read_text()  # any existing board from the ad canvas
OUT = S / "project"
TOOL = "/_blob/b72649442413111d18b255808fc796f7"
IMG = dict(empty="/_blob/79ef40a9c397c2b51a3f04e5a19fc0b0", fslides="/_blob/6de3af3c90fc70074d1106784f4aada3",
           fsq="/_blob/37e151aa499ce5c55f469aa85712e8f3", jres="/_blob/634d3a935a1927df19a415af9fd9d6bb",
           jsq="/_blob/0df9d82b0a38b90cd97336cb4b76e221", live="/_blob/a5c64c4b3cf1c8c2a3f138a9bd4a9b57",
           mjoy="/_blob/eb7d68cce35a320c99c46ff34f09cd58", mlive="/_blob/cbeecf0cabd6588f751deb550d07447f")
PROMISE = "We help coaches and experts with a proven $3K+ offer close <b>3–5 high-ticket clients</b> from their next live event in 7 weeks — without one-to-one selling."
CALLOUTS = ["Are you a coach or expert with a $3K+ offer?", "This is only for coaches and experts with a $3K+ offer.",
            "If you’re a coach, consultant or expert with an offer of $3,000 or more", "Coaches and experts with a proven $3K+ offer:"]
LEGAL = "Results not typical. Individual results vary."

CSS = """
body{margin:0;-webkit-font-smoothing:antialiased}
.co{align-self:flex-start;text-wrap:balance;font:700 26px/1.25 var(--font-body);padding:14px 22px;border-radius:10px;background:var(--co-bg);color:var(--co-ink);max-width:100%;box-sizing:border-box}
.h{font-family:var(--font-display);font-weight:800;letter-spacing:-.025em;font-size:80px;line-height:1.02;color:var(--t)}
.h span{color:var(--acc)}
.h.m{font-size:68px}.h.s{font-size:58px;line-height:1.08}
.h b{color:var(--acc);font-weight:800}
.pr{font:600 30px/1.32 var(--font-body);color:var(--t);background:var(--pr-bg);border-left:10px solid var(--brand);border-radius:0 14px 14px 0;padding:24px 28px}
.pr b{color:var(--acc);font-weight:800}
.btn{display:flex;align-items:center;justify-content:center;height:104px;border-radius:14px;background:#d3004e;color:#fff;font:800 40px/1 var(--font-display);letter-spacing:-.01em;text-transform:uppercase;text-decoration:none;box-shadow:0 14px 30px -10px rgba(211,0,78,.55);flex:none}
.vis{flex:1;min-height:0;position:relative}
.ph{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;border-radius:18px;display:block}
.tw{position:absolute;overflow:hidden;border-radius:14px;box-shadow:0 30px 60px -18px rgba(0,0,0,.55),0 0 0 1px rgba(0,0,0,.06);background:#fff}
.tag{display:inline-block;font:800 24px/1 var(--font-body);letter-spacing:.04em;text-transform:uppercase;padding:12px 16px;border-radius:8px;color:#fff}
.neg{background:#d92d3a}.pos{background:#1f9d57}
.li{display:flex;gap:14px;align-items:flex-start;font:600 27px/1.25 var(--font-body);color:var(--t)}
.li i{flex:none;width:38px;height:38px;border-radius:50%;display:flex;align-items:center;justify-content:center;font:900 24px/1 var(--font-body);font-style:normal;color:#fff;margin-top:-2px}
.stat{font-family:var(--font-display);font-weight:900;letter-spacing:-.04em;line-height:.95;color:var(--acc)}
.cap{font:600 26px/1.3 var(--font-body);color:var(--t2)}
.legal{font:500 20px/1.2 var(--font-body);color:var(--t2);text-align:center;margin-top:-10px}
.stars{color:#F2B21B;font-size:34px;letter-spacing:4px}
.bg{position:absolute;inset:0;width:100%;height:100%;object-fit:cover}
.shade{position:absolute;inset:0}
.z{position:relative;z-index:1;display:flex;flex-direction:column;gap:26px;flex:1;min-height:0}
.card{border-radius:18px;padding:26px 28px}
"""

VARS = re.search(r'<div ref="\{\{rootRef\}\}" style="(--canvas:.*?--font-mono:[^;]+;)', SRC).group(1)
LOOK = {
 "dark":  "--t:#ffffff;--t2:#c9cad1;--acc:#ff4d97;--pr-bg:rgba(255,255,255,.08);--co-bg:#ff4d97;--co-ink:#101014;--card:rgba(255,255,255,.07);background:#101014;",
 "white": "--t:#111111;--t2:#4a4b50;--acc:#d3004e;--pr-bg:#fff0f6;--co-bg:#111111;--co-ink:#ffffff;--card:#f5f5f7;background:#ffffff;",
 "photo": "--t:#ffffff;--t2:#e4e4ea;--acc:#ff6aa8;--pr-bg:rgba(16,16,20,.78);--co-bg:#ffffff;--co-ink:#101014;--card:rgba(16,16,20,.72);background:#101014;",
}

def root(look, inner):
    st = VARS + LOOK[look] + "width:1080px;height:1350px;box-sizing:border-box;padding:56px;color:var(--t);font-family:var(--font-body);display:flex;flex-direction:column;gap:26px;overflow:hidden;position:relative"
    return f'<div ref="{{{{rootRef}}}}" style="{st}">\n{inner}\n</div>'

def tool(left, top, w, rot=0, bottom=None, z=""):
    """the tool as a card over a photo: width w, height from the tool's own proportions. Break the frame:
    let it overhang the photo's edge (negative top, or bottom below the frame) in the corner away from faces."""
    v = f"bottom:{bottom}px" if bottom is not None else f"top:{top}px"
    return (f'<div class="tw" style="left:{left}px;{v};width:{w}px;height:{round(w * 1123 / 1587)}px;transform:rotate({rot}deg);z-index:2{z}">'
            f'<img src="{TOOL}" alt="Sniper Close Roadmap" style="width:100%;height:100%;display:block"></div>')

def tool_fill(pos="center 15%", radius=18):
    """the tool fills the visual area edge to edge (cropped, no white space around it)"""
    return f'<img class="ph" src="{TOOL}" alt="Sniper Close Roadmap" style="object-fit:cover;object-position:{pos};border-radius:{radius}px">'

def tool_zoom(w, left, top, radius=18):
    """a zoomed-in crop of the tool (the four columns) filling the visual area"""
    return (f'<div style="position:absolute;inset:0;overflow:hidden;border-radius:{radius}px;background:#fff">'
            f'<img src="{TOOL}" alt="Sniper Close Roadmap" style="position:absolute;width:{w}px;left:{left}px;top:{top}px;display:block"></div>')

def photo(key, style="", pos="center"):
    return f'<img class="ph" src="{IMG[key]}" alt="" style="object-position:{pos};{style}">'

co = lambda i: f'<div class="co">{CALLOUTS[i % 4]}</div>'
pr = lambda: f'<div class="pr">{PROMISE}</div>'
btn = lambda: '<a href="#get" class="btn">Grab your $27 seat →</a>'
legal = lambda: f'<div class="legal">{LEGAL}</div>'
def photoback(key, pos="center", shade="linear-gradient(180deg,rgba(10,10,14,.92) 0%,rgba(10,10,14,.35) 38%,rgba(10,10,14,.35) 52%,rgba(10,10,14,.94) 76%)"):
    return f'<img class="bg" src="{IMG[key]}" alt="" style="object-position:{pos}"><div class="shade" style="background:{shade}"></div>'

def li(ok, t):
    return f'<div class="li"><i style="background:{"#1f9d57" if ok else "#d92d3a"}">{"✓" if ok else "✕"}</i><span>{t}</span></div>'

OLD = ["Rebuild the slides the night before", "Rush the offer in the last 5 minutes", "Chase sales calls for weeks"]
NEW = ["Your whole close on one page", "The offer lands as the next step", "Yeses in the chat, live"]

B = {}
# 1 · PAIN
H1 = '<div class="h m">Sunday night. 40 slides open. <span>The offer’s still on the last one.</span></div>'
for look in ("dark", "white"):
    pos_ = dict(dark=(523, -49), white=(559, 301))[look]   # Matthew's placements: the tool breaks the frame
    B[f"Ad-CV1-pain-{look}"] = ("CV1 · Pain · " + look, root(look, co(0) + H1 + '<div class="vis">' + photo("fslides", pos="center 35%") +
        tool(pos_[0], pos_[1], 450, 4) + '</div>' + pr() + btn()))
B["Ad-CV1-pain-photo"] = ("CV1 · Pain · photo", root("photo", photoback("fslides", "center 30%") + '<div class="z">' + co(0) + H1 + '<div class="vis">' + tool(560, 150, 420, 4) + '</div>' + pr() + btn() + '</div>'))

# 2 · HOST (CV2)
H2 = '<div class="h s">15 minutes in, my MC messaged: <span>“I think everybody has left.”</span></div>'
B["Ad-CV2-host-dark"] = ("CV2 · Host · dark", root("dark", co(1) + H2 +
    '<div class="vis" style="display:flex;gap:18px">'
    '<div style="flex:1;position:relative">' + photo("empty") + '<div class="tag neg" style="position:absolute;left:18px;top:18px">Then</div></div>'
    '<div style="flex:1;position:relative">' + photo("mjoy", pos="40% center") + '<div class="tag pos" style="position:absolute;left:18px;top:18px">Now</div></div>'
    + tool(274, None, 420, -3, bottom=14) + '</div>' + pr() + btn()))
B["Ad-CV2-host-white"] = ("CV2 · Host · white", root("white", co(1) + '<div class="vis">' + photo("mlive", pos="center 0%") + tool(570, -36, 400, 4) + '</div>' + H2 + pr() + btn()))
B["Ad-CV2-host-photo"] = ("CV2 · Host · photo", root("photo", photoback("mjoy", "45% center") + '<div class="z">' + co(1) + H2 + '<div class="vis">' + tool(-10, None, 420, -4, bottom=20) + '</div>' + pr() + btn() + '</div>'))

# 3 · TOOL
H3 = '<div class="h">Your whole close <span>on one page.</span></div>'
B["Ad-CV3-tool-dark"] = ("CV3 · Tool · dark", root("dark", co(2) + H3 + '<div class="vis" style="margin:0 -56px">' + tool_fill("center 12%", 0) + '</div>' + pr() + btn()))
B["Ad-CV3-tool-white"] = ("CV3 · Tool · white", root("white", co(2) + H3 +
    '<div class="vis" style="margin:0 -56px">' + tool_zoom(1500, -392, -192, 0) + '</div>' + pr() + btn()))
B["Ad-CV3-tool-photo"] = ("CV3 · Tool · photo", root("photo", photoback("live", "center 60%", "linear-gradient(180deg,rgba(10,10,14,.9) 0%,rgba(10,10,14,.55) 40%,rgba(10,10,14,.92) 78%)") +
    '<div class="z">' + co(2) + H3 + '<div class="vis">' + tool(-30, 0, 520, -3) + '</div>' + pr() + btn() + '</div>'))

# 4 · PROOF
H4 = '<div class="h m">How Vincent closed <span>$28,000 in 7 weeks.</span></div>'
def proofcard(bg="var(--card)"):
    return (f'<div class="card" style="background:{bg};display:flex;align-items:center;gap:28px">'
            '<div class="stat" style="font-size:132px">$28K</div>'
            '<div style="display:flex;flex-direction:column;gap:8px"><div class="cap" style="color:var(--t)"><b>Vincent Holthouse</b></div>'
            '<div class="cap">coach for real estate investors</div><div class="stars">★★★★★</div></div></div>')
for look in ("dark", "white"):
    B[f"Ad-CV4-proof-{look}"] = ("CV4 · Proof · " + look, root(look, co(3) + H4 + proofcard() + '<div class="vis">' + tool_zoom(1400, -380, -178) + '</div>' + pr() + btn() + legal()))
B["Ad-CV4-proof-photo"] = ("CV4 · Proof · photo", root("photo", photoback("live", "center 55%") + '<div class="z">' + co(3) + H4 + proofcard("rgba(16,16,20,.8)") + '<div class="vis">' + tool(-40, 10, 470, -3) + '</div>' + pr() + btn() + legal() + '</div>'))

# 5 · TWO ROADS
H5 = '<div class="h m">2 ways to run <span>your next masterclass.</span></div>'
def road(ok, key, title, lines, look):
    bd = "#1f9d57" if ok else "#d92d3a"
    bg = ("rgba(31,157,87,.12)" if ok else "rgba(217,45,58,.12)") if look != "white" else ("#ecf8f1" if ok else "#fdeeee")
    return (f'<div style="flex:1;display:flex;flex-direction:column;border-radius:18px;border:4px solid {bd};background:{bg}">'
            f'<div style="height:300px;position:relative"><img src="{IMG[key]}" alt="" style="width:100%;height:100%;object-fit:cover;display:block;border-radius:14px 14px 0 0">'
            f'<div class="tag {"pos" if ok else "neg"}" style="position:absolute;left:16px;bottom:16px">{title}</div>'
            + (tool(226, -26, 230, 5) if ok else '') + '</div>'
            '<div style="padding:22px 20px;display:flex;flex-direction:column;gap:16px">' + "".join(li(ok, t) for t in lines) + '</div></div>')
for look in ("dark", "white"):
    B[f"Ad-CV5-two-roads-{look}"] = ("CV5 · Two Roads · " + look, root(look, co(0) + H5 +
        '<div class="vis" style="display:flex;gap:20px">' + road(False, "fsq", "The old way", OLD, look) + road(True, "jsq", "The new way", NEW, look) + '</div>' + pr() + btn()))
B["Ad-CV5-two-roads-photo"] = ("CV5 · Two Roads · photo", root("photo",
    f'<img src="{IMG["fsq"]}" alt="" style="position:absolute;left:0;top:300px;width:540px;height:460px;object-fit:cover"><img src="{IMG["jsq"]}" alt="" style="position:absolute;left:540px;top:300px;width:540px;height:460px;object-fit:cover">'
    '<div class="shade" style="background:linear-gradient(180deg,#101014 0%,#101014 22%,rgba(10,10,14,0) 26%,rgba(10,10,14,0) 48%,#101014 57%)"></div>'
    '<div style="position:absolute;left:538px;top:300px;width:4px;height:460px;background:#fff"></div>'
    + tool(800, 560, 240, 5) +
    '<div class="z">' + co(0) + H5 + '<div style="flex:1"></div>'
    '<div style="display:flex;gap:20px"><div style="flex:1;display:flex;flex-direction:column;gap:14px"><div><span class="tag neg">The old way</span></div>' + "".join(li(False, t) for t in OLD) + '</div>'
    '<div style="flex:1;display:flex;flex-direction:column;gap:14px"><div><span class="tag pos">The new way</span></div>' + "".join(li(True, t) for t in NEW) + '</div></div>'
    + pr() + btn() + '</div>'))

# 6 · PROMISE-LED (alternate for any Convert slot)
H6 = f'<div class="h s">{PROMISE}</div>'
B["Ad-CVx-promise-dark"] = ("Promise-led · dark", root("dark", co(1) + H6 + '<div class="vis">' + photo("jres", pos="center 30%") + tool(526, 369, 470, 3) + '</div>' + btn()))
B["Ad-CVx-promise-white"] = ("Promise-led · white", root("white", co(1) + H6 + '<div class="vis" style="margin:0 -56px">' + tool_fill("center 10%", 0) + '</div>' + btn()))
B["Ad-CVx-promise-photo"] = ("Promise-led · photo", root("photo", photoback("jres", "center 25%", "linear-gradient(180deg,rgba(10,10,14,.75) 0%,rgba(10,10,14,0) 26%,rgba(10,10,14,0) 40%,rgba(10,10,14,.92) 62%)") +
    '<div class="z">' + co(1) + '<div class="vis">' + tool(600, 60, 380, 4) + '</div>' + H6.replace('class="h s"', 'class="h s" style="font-size:56px"') + btn() + '</div>'))

# 7 · STATS (alternate)
H7 = '<div class="h">127 $100K+ days. <span>$27.9M in sales.</span></div>'
SUB7 = '<div class="cap" style="font-size:32px;color:var(--t);font-weight:700;margin-top:-8px">One close behind every one of them.</div>'
B["Ad-CVx-stats-dark"] = ("Stats · dark", root("dark", co(2) + H7 + SUB7 + '<div class="vis">' + photo("mlive", pos="center 0%") + tool(600, None, 400, 4, bottom=-44) + '</div>' + pr() + btn() + legal()))
B["Ad-CVx-stats-white"] = ("Stats · white", root("white", co(2) + H7 + SUB7 + '<div class="vis">' + tool_zoom(1400, -380, -178) + '</div>' + pr() + btn() + legal()))
B["Ad-CVx-stats-photo"] = ("Stats · photo", root("photo",
    f'<img class="bg" src="{IMG["mlive"]}" alt="" style="top:330px;height:calc(100% - 330px);object-position:center 0%">'
    '<div class="shade" style="background:linear-gradient(180deg,#101014 0%,#101014 24%,rgba(10,10,14,0) 30%,rgba(10,10,14,0) 52%,rgba(10,10,14,.94) 66%)"></div>'
    '<div class="z">' + co(2) + H7 + SUB7 + '<div class="vis">' + tool(624, 120, 360, 4) + '</div>' + pr() + btn() + legal() + '</div>'))

head = SRC[:SRC.index("<style>") + 7] + CSS + SRC[SRC.index("</style>"):SRC.index("</helmet>") + 9]
tail = SRC[SRC.index("</x-dc>"):]
OUT.mkdir(exist_ok=True)
for name, (title, body) in B.items():
    h = head.replace("<title>Ad CV3 · Tool Hero (4:5)</title>", f"<title>{title}</title>")
    (OUT / f"{name}.dc.html").write_text(h + "\n" + body + "\n" + tail)
json.dump({k: v[0] for k, v in B.items()}, open(S / "titles.json", "w"), indent=1)
print(len(B), "boards")
