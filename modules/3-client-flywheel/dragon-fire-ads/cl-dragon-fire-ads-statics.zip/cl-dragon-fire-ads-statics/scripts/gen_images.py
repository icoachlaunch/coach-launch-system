#!/usr/bin/env python3
"""Generate the ad set's supporting images with Kie.ai (cl-image-gen's runner, plus the edit model).

    KIE_KEY="<from kie.env.claude>" python3 gen_images.py spec.json results.json

spec.json:
  {"model": "google/nano-banana", "variations": 1, "images": [
     {"name": "frustration-slides", "aspect_ratio": "4:5", "prompt": "... <house style>, no words on any screen"},
     {"name": "host-live", "model": "google/nano-banana-edit", "image_urls": ["<uploaded real photo url>"],
      "image_size": "4:5", "prompt": "the man from the reference photo, same face, ..."}]}

The key is read from the drive (see cl-image-gen) and passed only as an environment variable. Writes
results.json = {name: [url, ...]}. The image CDN is reachable from the operator's computer, not the sandbox:
download there (cl-image-gen step 6), then stage the files.
"""
import json, os, sys, time, urllib.request
B="https://api.kie.ai/api/v1/jobs"; K=os.environ.get("KIE_KEY","").strip()
if not K: sys.exit("KIE_KEY missing")
H={"Authorization":"Bearer "+K,"Content-Type":"application/json"}
def post(p,b): return json.load(urllib.request.urlopen(urllib.request.Request(B+p,data=json.dumps(b).encode(),headers=H),timeout=30))
def get(p): return json.load(urllib.request.urlopen(urllib.request.Request(B+p,headers=H),timeout=25))
spec=json.load(open(sys.argv[1])); out=sys.argv[2] if len(sys.argv)>2 else "results.json"
model=spec.get("model","google/nano-banana"); ar=spec.get("aspect_ratio","1:1"); dv=int(spec.get("variations",1))
tasks={}
for im in spec["images"]:
    for i in range(1,int(im.get("variations",dv))+1):
        inp={"prompt":im["prompt"]}
        m=im.get("model",model)
        if "image_urls" in im: inp["image_urls"]=im["image_urls"]; inp["image_size"]=im.get("image_size","4:5"); inp["output_format"]="png"
        else: inp["aspect_ratio"]=im.get("aspect_ratio",ar)
        r=post("/createTask",{"model":m,"input":inp})
        if r.get("code")!=200: print("!",im["name"],r.get("code"),r.get("msg")); continue
        tasks[r["data"]["taskId"]]=(im["name"],i); print("submitted",im["name"],i)
order={}; pend=set(tasks)
for _ in range(60):
    if not pend: break
    time.sleep(7)
    for t in list(pend):
        n,i=tasks[t]
        try:
            d=get("/recordInfo?taskId="+t)["data"]; s=d.get("state")
            if s=="success": order.setdefault(n,{})[i]=json.loads(d["resultJson"])["resultUrls"][0]; pend.discard(t); print("OK",n,i)
            elif s=="fail": pend.discard(t); print("FAIL",n,i,d.get("failMsg"))
        except Exception as e: print("poll err",n,e)
for t in pend: print("TIMEOUT",tasks[t])
json.dump({n:[v[k] for k in sorted(v)] for n,v in order.items()},open(out,"w"),indent=2); print("wrote",out)
