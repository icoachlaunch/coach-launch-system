#!/usr/bin/env python3
"""Build the Ad Preview page — every ad in a pack laid out in sequence as it will look in the feed.

    python3 build_preview.py ad-pack-<slug>.md --out preview.html \
        --img A1=pngs/Ad-CV1-pain-callout.png --img A3=pngs/Ad-CV3-tool-hero.png ... \
        --img A1=dark.png,white.png,photo.png  (several looks get a switch) \
        --extra "Promise-led=a.png,b.png" (concepts not tied to one ad, shown as a gallery) \
        --video A2=poster.jpg --video A5=poster.jpg --brand "Coach Launch" [--logo logo.png] [--domain "[registration page]"]

Reads the pack written to cl-dragon-fire-ads' ad-pack-template.md: the brief (Promise P1/P2, Callouts, Message
match), each "### Ad A# · …" block (hooks, short and long primary text, headline, description, CTA, creative,
SCORE™) and, for a promise test, the "Ad set B swaps" table. Images are embedded (JPEG, 1080 wide), so the page
is one self-contained file for the Artifact tool. The output is page content only (no <html>/<body>): the
Artifact tool adds the skeleton.
"""
import argparse
import base64
import html
import io
import pathlib
import re

try:
    from PIL import Image
except ImportError:  # pragma: no cover
    Image = None


def section(text, heading):
    i = text.find(heading)
    if i < 0:
        return ""
    rest = text[i + len(heading):]
    m = re.search(r"^## ", rest, re.M)
    return rest[: m.start()] if m else rest


def field(block, label):
    m = re.search(r"^\*\*" + re.escape(label) + r":\*\*[ \t]*(.*)$", block, re.M)
    return m.group(1).strip() if m else ""


def jpeg_uri(path, width=1080, crop45=False):
    p = pathlib.Path(path)
    if Image is None:
        return "data:image/png;base64," + base64.b64encode(p.read_bytes()).decode()
    im = Image.open(p).convert("RGB")
    if crop45:
        w, h = im.size
        tw = min(w, int(h * 4 / 5))
        th = int(tw * 5 / 4)
        left = (w - tw) // 2
        im = im.crop((left, max(0, (h - th) // 3), left + tw, max(0, (h - th) // 3) + th))
    if im.width > width:
        im = im.resize((width, int(im.height * width / im.width)))
    buf = io.BytesIO()
    im.save(buf, "JPEG", quality=82, optimize=True)
    return "data:image/jpeg;base64," + base64.b64encode(buf.getvalue()).decode()


def esc(s):
    return html.escape(s, quote=True)


def parse(pack):
    text = pathlib.Path(pack).read_text(encoding="utf-8")
    fm = text.split("---", 2)[1] if text.startswith("---") else ""
    meta = dict(re.findall(r"^(\w+):\s*(.*)$", fm, re.M))
    body = text.split("---", 2)[2] if fm else text
    brief = section(body, "## 1 · THE CAMPAIGN BRIEF")
    promise_line = field(brief, "Promise")
    promises = re.findall(r'"([^"]+)"', promise_line)
    labels = re.findall(r'\b(P\d)\s+"', promise_line) or [f"P{i + 1}" for i in range(len(promises))]
    callouts = re.findall(r'"([^"]+)"', field(brief, "Callouts"))
    ads = []
    for b in re.split(r"^### ", section(body, "## 3 · THE ADS"), flags=re.M)[1:]:
        if not b.startswith("Ad "):
            continue
        title = b.splitlines()[0].strip()
        code = title.split()[1]
        hooks = re.findall(r"^\d\.\s+(.+?)\s+—\s+\*Map\s+([^*]+)\*\s*$", b, re.M)
        lm = re.search(r"\*\*Primary text \(long\):\*\*(.*?)\*\*Headline:", b, re.S)
        paras = [p.strip() for p in re.split(r"\n\s*\n", lm.group(1).strip())] if lm else []
        ads.append(dict(code=code, title=title[len("Ad " + code):].strip(" ·"), hooks=hooks,
                        short=field(b, "Primary text (short)"), long=paras, headline=field(b, "Headline"),
                        desc=field(b, "Description"), cta=field(b, "CTA button"), creative=field(b, "Creative"),
                        score=field(b, "SCORE™")))
    swaps = {}
    setup = section(body, "## 6 · CAMPAIGN SETUP")
    for row in re.findall(r"^\|\s*(A\d)\s*\|(.+)\|(.+)\|\s*$", setup, re.M):
        swaps[row[0]] = dict(short=row[1].strip(), headline=row[2].strip())
    videos = {}
    for vb in re.split(r"^### ", section(body, "## 5 · THE VIDEO ADS"), flags=re.M)[1:]:
        head = vb.splitlines()[0].strip()
        lines = [l.strip() for l in vb.splitlines()[1:] if l.strip().startswith("[0:")]
        if lines:
            videos[head] = lines
    return meta, promises, labels, callouts, ads, swaps, videos


CSS = """
:root{
  /* layout: one narrow feed column of ad cards, a slim notes rail beside each on wide screens */
  --bg:#eef0f3; --card:#ffffff; --fg:#1c1e21; --muted:#65676b; --line:#dadde1;
  --brand:#d3004e; --brand-ink:#ffffff; --chip:#f0f2f5; --ok:#1f9d57;
  --display:'Montserrat',system-ui,sans-serif; --body:system-ui,-apple-system,'Segoe UI',Roboto,sans-serif;
  --mono:'JetBrains Mono',ui-monospace,monospace;
}
@media (prefers-color-scheme: dark){:root:not([data-theme="light"]){--bg:#101113;--card:#1c1d20;--fg:#e4e6eb;--muted:#a8abb1;--line:#34363a;--chip:#2a2b2f;--brand:#ff3d7f;color-scheme:dark}}
:root[data-theme="dark"]{--bg:#101113;--card:#1c1d20;--fg:#e4e6eb;--muted:#a8abb1;--line:#34363a;--chip:#2a2b2f;--brand:#ff3d7f;color-scheme:dark}
[hidden]{display:none!important}
body{background:var(--bg);color:var(--fg);font-family:var(--body);font-size:15px;line-height:1.45}
.wrap{max-width:1040px;margin:0 auto;padding-block:32px 64px;padding-left:max(16px,env(safe-area-inset-left,0px));padding-right:max(16px,env(safe-area-inset-right,0px));display:flex;flex-direction:column;gap:28px}
h1{font-family:var(--display);font-weight:800;font-size:clamp(26px,4vw,38px);letter-spacing:-.02em;margin:0;text-wrap:balance}
.lede{color:var(--muted);max-width:65ch;margin:0}
.eyebrow{font:600 12px/1 var(--mono);letter-spacing:.14em;text-transform:uppercase;color:var(--brand)}
.top{display:flex;flex-direction:column;gap:10px}
.stages{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:8px}
.stage{background:var(--card);border:1px solid var(--line);border-radius:10px;padding:10px 12px;display:flex;flex-direction:column;gap:2px}
.stage b{font-family:var(--display);font-size:15px}
.stage span{font-size:12.5px;color:var(--muted)}
.stage.on{border-color:var(--brand);box-shadow:inset 0 0 0 1px var(--brand)}
.controls{display:flex;flex-wrap:wrap;gap:10px;align-items:center}
.seg{display:inline-flex;border:1px solid var(--line);border-radius:999px;overflow:hidden;background:var(--card)}
.seg button{all:unset;cursor:pointer;padding:8px 14px;font-weight:600;font-size:13.5px;color:var(--muted)}
.seg button[aria-pressed="true"]{background:var(--brand);color:var(--brand-ink)}
.seg button:focus-visible{outline:2px solid var(--brand);outline-offset:-2px}
.promise{background:var(--card);border:1px solid var(--line);border-radius:10px;padding:12px 14px;font-size:14px;max-width:72ch}
.promise b{font-family:var(--display)}
.row{display:grid;grid-template-columns:minmax(0,500px) minmax(0,1fr);gap:24px;align-items:start}
.seq{font:600 12px/1 var(--mono);letter-spacing:.12em;text-transform:uppercase;color:var(--muted);grid-column:1/-1;display:flex;gap:10px;align-items:center}
.seq::after{content:"";flex:1;height:1px;background:var(--line)}
.ad{background:var(--card);border:1px solid var(--line);border-radius:12px;overflow:hidden;min-width:0}
.ad-head{display:flex;gap:10px;align-items:center;padding:12px 14px 8px}
.av{width:40px;height:40px;border-radius:50%;background:var(--brand);color:var(--brand-ink);display:grid;place-items:center;font-family:var(--display);font-weight:800;font-size:14px;flex:none;overflow:hidden}
.av img{width:100%;height:100%;object-fit:cover}
.who b{display:block;font-size:14.5px}.who span{font-size:12.5px;color:var(--muted)}
.copy{padding:0 14px 12px;white-space:pre-line}
.copy details summary{list-style:none;cursor:pointer;color:var(--muted);font-weight:600;display:inline}
.copy details summary::-webkit-details-marker{display:none}
.copy details[open] summary{display:none}
.copy .more p{margin:.7em 0 0}
.lk{color:#1877f2;font-weight:600;text-decoration:none;word-break:break-all}
.lk.miss{word-break:normal;color:#c0392b;background:rgba(192,57,43,.08);border-radius:4px;padding:0 3px}
.media{position:relative;aspect-ratio:4/5;background:#000}
.media img{width:100%;height:100%;object-fit:cover;display:block}
.play{position:absolute;inset:0;display:grid;place-items:center;background:linear-gradient(transparent 40%,rgba(0,0,0,.65))}
.play i{width:72px;height:72px;border-radius:50%;background:rgba(255,255,255,.92);display:grid;place-items:center}
.play small{position:absolute;left:14px;right:14px;bottom:14px;color:#fff;font-weight:600;font-size:14px}
.bar{display:flex;gap:12px;align-items:center;justify-content:space-between;padding:10px 14px;background:var(--chip)}
.bar .t{min-width:0}.bar .d{font-size:12px;color:var(--muted);text-transform:uppercase;letter-spacing:.04em}
.bar .h{font-weight:700;font-size:15px}.bar .s{font-size:13px;color:var(--muted)}
.cta{flex:none;background:var(--card);border:1px solid var(--line);border-radius:6px;padding:8px 14px;font-weight:600;font-size:14px}
.notes{display:flex;flex-direction:column;gap:10px;min-width:0;font-size:14px}
.notes h2{font-family:var(--display);font-size:19px;margin:0;letter-spacing:-.01em;text-wrap:balance}
.chips{display:flex;flex-wrap:wrap;gap:6px}
.chip{background:var(--chip);border-radius:999px;padding:4px 10px;font-size:12.5px}
.chip.score{color:var(--ok);font-weight:700}
.notes ol{margin:0;padding-left:20px;display:flex;flex-direction:column;gap:4px}
.notes .cite{font:500 11.5px/1 var(--mono);color:var(--muted)}
.notes details{background:var(--card);border:1px solid var(--line);border-radius:10px;padding:10px 12px}
.notes details summary{cursor:pointer;font-weight:600}
.script{font-size:13.5px;display:flex;flex-direction:column;gap:6px;margin-top:8px}
.foot{color:var(--muted);font-size:13px}
.looks{margin:10px 14px 12px;display:flex;width:max-content}
.extras{display:flex;flex-direction:column;gap:18px}
.ex h2{font-family:var(--display);font-size:19px;margin:0 0 10px}
.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:12px}
.grid figure{margin:0;background:var(--card);border:1px solid var(--line);border-radius:12px;overflow:hidden}
.grid img{width:100%;aspect-ratio:4/5;object-fit:cover;display:block}
.grid figcaption{padding:8px 12px;font-size:13px;color:var(--muted);font-weight:600}
@media (max-width:820px){.row{grid-template-columns:minmax(0,1fr)}.stages{grid-template-columns:repeat(2,minmax(0,1fr))}}
@media (prefers-reduced-motion:no-preference){.seg button{transition:background .15s}}
"""


LINK_RX = re.compile(r"(https?://[^\s<]+|\[MISSING CONTENT[^\]]*link[^\]]*\])", re.I)


def linkify(html):
    """the 👉 call to action on its own line, its URL (or the missing-link flag) as a tappable link"""
    html = re.sub(r"\s*👉", "\n👉", html).lstrip("\n")
    return LINK_RX.sub(lambda m: (f'<a class="lk" href="{m.group(1)}" target="_blank" rel="noopener">{m.group(1)}</a>'
                                  if m.group(1).startswith("http") else f'<a class="lk miss">{m.group(1)}</a>'), html)


def looks_of(spec):
    """'a.png,b.png' or 'Dark:a.png,White:b.png' -> [(label, path)]; label defaults to the file's last word"""
    out = []
    for item in spec.split(","):
        lab, sep, path = item.partition(":")
        if not sep:
            path, lab = lab, pathlib.Path(lab).stem.rsplit("-", 1)[-1].capitalize()
        out.append((lab, path))
    return out


def build(a):
    meta, promises, labels, callouts, ads, swaps, videos = parse(a.pack)
    imgs = dict(x.split("=", 1) for x in a.img)
    vids = dict(x.split("=", 1) for x in a.video)
    logo = f'<img src="{jpeg_uri(a.logo, 120)}" alt="">' if a.logo else esc("".join(w[0] for w in a.brand.split()[:2]))
    out = [f"<title>{esc(a.title)}</title>", '<meta name="claude:viewport-fit-sides" content="cover">',
           '<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Montserrat:wght@700;800&family=JetBrains+Mono:wght@500;600&display=swap">',
           f"<style>{CSS}</style>", '<main class="wrap">', '<header class="top">',
           f'<div class="eyebrow">Dragon Fire Ads™ · {esc(a.stage)} pack</div>',
           f"<h1>{esc(meta.get('campaign', a.title).split(' — ')[0])} · {esc(a.stage)} ads</h1>",
           f'<p class="lede">Every ad in the order it runs, as it shows in the feed. Tap "See more" for the long text. '
           f'{"Switch the promise to see ad set B. " if len(promises) > 1 else ""}Notes beside each ad show its hooks, map rows and score.</p>',
           '<div class="stages">']
    for st, n, note in (("Attract", 4, "always on"), ("Engage", 7, "7-day rotation"), ("Convert", 5, "D-14 → D0"),
                        ("Motivate", 3, "D-7 → D0")):
        on = " on" if st == a.stage else ""
        out.append(f'<div class="stage{on}"><b>{st} · {n}</b><span>{note}{" · this pack" if on else ""}</span></div>')
    out.append("</div>")
    if len(promises) > 1:
        out.append('<div class="controls"><div class="seg pseg" role="group" aria-label="Promise">')
        for i, lab in enumerate(labels):
            out.append(f'<button type="button" id="p{i}" data-set="{i}" aria-pressed="{"true" if i == 0 else "false"}">'
                       f'Ad set {"AB"[i] if i < 2 else i + 1} · {esc(lab)}</button>')
        out.append("</div></div>")
    for i, p in enumerate(promises):
        out.append(f'<div class="promise" data-show="{i}"{"" if i == 0 else " hidden"}><b>{esc(labels[i])} promise:</b> {esc(p)}</div>')
    out.append("</header>")
    for n, ad in enumerate(ads, 1):
        code, sw = ad["code"], swaps.get(ad["code"])
        out.append('<section class="row">')
        out.append(f'<div class="seq">Ad {n} of {len(ads)} · {esc(code)}</div>')
        out.append('<article class="ad">')
        out.append(f'<div class="ad-head"><div class="av">{logo}</div><div class="who"><b>{esc(a.brand)}</b><span>Sponsored</span></div></div>')
        for i in range(max(1, len(promises))):
            short = ad["short"] if i == 0 or not sw else sw["short"]
            longp = list(ad["long"])
            if i > 0 and len(promises) > i:
                longp = [p.replace(promises[0], promises[i].rstrip(".") + ".") for p in longp]
            more = "".join(f"<p>{linkify(esc(p))}</p>" for p in longp)
            out.append(f'<div class="copy" data-show="{i}"{"" if i == 0 else " hidden"}>{linkify(esc(short))} '
                       f'<details><summary>…See more</summary><div class="more">{more}</div></details></div>')
        if code in vids:
            out.append(f'<div class="media"><img src="{jpeg_uri(vids[code], 1080, True)}" alt="Video poster for {esc(code)}">'
                       '<div class="play"><i><svg width="28" height="28" viewBox="0 0 24 24" aria-hidden="true"><path d="M8 5v14l11-7z" fill="#1c1e21"/></svg></i>'
                       '<small>Video ad · script ready to film</small></div></div>')
        elif code in imgs:
            looks = looks_of(imgs[code])
            for j, (lab, path) in enumerate(looks):
                out.append(f'<div class="media" data-look="{code}-{j}"{"" if j == 0 else " hidden"}>'
                           f'<img src="{jpeg_uri(path)}" alt="{esc(ad["creative"])} · {esc(lab)}"></div>')
            if len(looks) > 1:
                out.append(f'<div class="looks seg" role="group" aria-label="Look">' + "".join(
                    f'<button type="button" data-ad="{code}" data-j="{j}" aria-pressed="{"true" if j == 0 else "false"}">{esc(lab)}</button>'
                    for j, (lab, _) in enumerate(looks)) + "</div>")
        for i in range(max(1, len(promises))):
            head = ad["headline"] if i == 0 or not sw else sw["headline"]
            out.append(f'<div class="bar" data-show="{i}"{"" if i == 0 else " hidden"}><div class="t"><div class="d">{esc(a.domain)}</div>'
                       f'<div class="h">{esc(head)}</div><div class="s">{esc(ad["desc"])}</div></div>'
                       f'<div class="cta">{esc(ad["cta"])}</div></div>')
        out.append("</article>")
        out.append('<aside class="notes">')
        out.append(f"<h2>{esc(ad['title'])}</h2>")
        out.append(f'<div class="chips"><span class="chip">{esc(ad["creative"])}</span><span class="chip score">{esc(ad["score"])}</span></div>')
        out.append("<div><b>Hooks to test</b><ol>" + "".join(
            f'<li>{esc(h)} <span class="cite">{esc(c)}</span></li>' for h, c in ad["hooks"]) + "</ol></div>")
        slot = ad['title'].split('(')[-1].split(' ·')[0].strip(" )")
        if slot:
            for vh, lines in videos.items():
                if f"({slot})" in vh:
                    out.append(f"<details><summary>{esc(vh)}</summary><div class='script'>" +
                               "".join(f"<div>{esc(l)}</div>" for l in lines) + "</div></details>")
        out.append("</aside></section>")
    if a.extra:
        out.append('<section class="extras"><div class="seq">More concepts · pair with any ad in this pack</div>')
        for ex in a.extra:
            name, _, paths = ex.partition("=")
            out.append(f'<div class="ex"><h2>{esc(name)}</h2><div class="grid">' + "".join(
                f'<figure><img src="{jpeg_uri(pth)}" alt="{esc(name)} · {esc(lab)}" loading="lazy"><figcaption>{esc(lab)}</figcaption></figure>'
                for lab, pth in looks_of(paths)) + "</div></div>")
        out.append("</section>")
    out.append(f'<p class="foot">Built from {esc(pathlib.Path(a.pack).name)} · images exported from the design canvas · '
               'results shown are real and attributed; results not typical, individual results vary.</p>')
    out.append("</main>")
    out.append("""<script>
(function(){document.querySelectorAll('.looks button').forEach(function(b){b.addEventListener('click',function(){
var ad=b.dataset.ad;document.querySelectorAll('.looks button[data-ad="'+ad+'"]').forEach(function(x){x.setAttribute('aria-pressed',String(x===b));});
document.querySelectorAll('[data-look^="'+ad+'-"]').forEach(function(m){m.hidden=m.dataset.look!==ad+'-'+b.dataset.j;});});});})();
</script>""")
    if len(promises) > 1:
        out.append("""<script>
(function(){var btns=document.querySelectorAll('.pseg button');
function show(n){btns.forEach(function(b){b.setAttribute('aria-pressed',String(b.dataset.set===n));});
document.querySelectorAll('[data-show]').forEach(function(el){el.hidden=el.dataset.show!==n;});}
btns.forEach(function(b){b.addEventListener('click',function(){show(b.dataset.set);});});})();
</script>""")
    pathlib.Path(a.out).write_text("\n".join(out), encoding="utf-8")
    print(f"wrote {a.out} ({pathlib.Path(a.out).stat().st_size // 1024} KB, {len(ads)} ads)")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("pack")
    ap.add_argument("--out", required=True)
    ap.add_argument("--img", action="append", default=[],
                    help="A#=path to the ad's PNG; several looks comma-separated (A1=dark.png,white.png,photo.png) get a look switch")
    ap.add_argument("--extra", action="append", default=[],
                    help="'Concept name=a.png,b.png' — extra concepts shown as a gallery after the ads")
    ap.add_argument("--video", action="append", default=[], help="A#=poster image for a video ad")
    ap.add_argument("--brand", required=True)
    ap.add_argument("--logo")
    ap.add_argument("--title", default="Ad Preview")
    ap.add_argument("--stage", default="Convert")
    ap.add_argument("--domain", default="Registration page")
    build(ap.parse_args())


if __name__ == "__main__":
    main()
