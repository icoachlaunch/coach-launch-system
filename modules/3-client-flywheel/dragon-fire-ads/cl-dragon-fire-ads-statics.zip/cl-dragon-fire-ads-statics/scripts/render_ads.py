#!/usr/bin/env python3
"""Render Dragon Fire Ads(TM) ad boards (.dc.html from the Design canvas) to PNGs for Ads Manager.

    python3 render_ads.py board1.dc.html [board2.dc.html ...] --out pngs/ \
        --blob <tool asset id>=tool.png --blob <photo asset id>=host.jpg --fonts fontdir/ [--scale 1]

- Boards on the Dragon Fire Ads(TM) canvas place the tool and photos as canvas assets,
  <img src="/_blob/<id>">. Each --blob id=path swaps that asset for the local file (the exported tool PNG,
  the photo). An unmapped /_blob/ src is listed and drawn blank.
- Every <dc-import> (older boards that import a live tool page) (the live Event Magnet(TM) tool page) is swapped for --tool, the exported tool PNG,
  drawn at 1587 x 1123 so the board's own wrapper scales and tilts it exactly as on the canvas.
- Google Fonts can't be reached from every sandbox, so fonts come from --fonts: a folder of
  <family>-<weight>.woff2 files (e.g. Montserrat-800.woff2, JetBrains Mono-600.woff2). Missing families fall
  back to system fonts and are listed. `npm i @fontsource/<family>` gives them (see SKILL.md).
- Every board is checked: text under --min-px (default 18, the mobile floor) and text pushed off the
  board are listed under the board's line. With --keep-clear (each photo's faces and subject, recorded when
  the images are made), any face that text, a band or the tool covers, or that its frame crops, is listed too.
  Fix them before the PNGs go anywhere.
- Board size is read from the board's data-props "$preview" (default 1080 x 1350).
Needs Playwright with Chromium (preinstalled in Cowork; else pip install playwright && playwright install chromium).
"""
import argparse
import asyncio
import base64
import json
import mimetypes
import pathlib
import re
import sys


def data_uri(path):
    mime = mimetypes.guess_type(str(path))[0] or "application/octet-stream"
    return f"data:{mime};base64," + base64.b64encode(pathlib.Path(path).read_bytes()).decode()


def font_faces(font_dir):
    faces, fams = [], set()
    if not font_dir:
        return "", fams
    for f in sorted(pathlib.Path(font_dir).glob("*.woff2")):
        m = re.match(r"(.+)-(\d{3})$", f.stem)
        if not m:
            continue
        fam, wt = m.group(1), m.group(2)
        fams.add(fam)
        faces.append(f"@font-face{{font-family:'{fam}';font-weight:{wt};font-style:normal;"
                     f"src:url({data_uri(f)}) format('woff2')}}")
    return "<style>" + "".join(faces) + "</style>", fams


def standalone(src, tool_uri, faces, blobs):
    html = src
    unmapped = set()

    def blob(m):
        bid = m.group(2)
        if bid in blobs:
            return f'data-blob="{bid}" ' + m.group(1) + blobs[bid] + m.group(3)
        unmapped.add(bid)
        return m.group(1) + "data:," + m.group(3)
    html = re.sub(r'(src=["\'])/_blob/([A-Za-z0-9]+)(["\'])', blob, html)
    size = (1080, 1350)
    m = re.search(r"data-props='(\{.*?\})'", html, re.S)
    if m:
        try:
            p = json.loads(m.group(1).replace("&#39;", "'"))
            pv = p.get("$preview", {})
            size = (int(pv.get("width", 1080)), int(pv.get("height", 1350)))
        except json.JSONDecodeError:
            pass
    html = html.replace('<script src="./support.js"></script>', "")
    html = re.sub(r'<script type="text/x-dc".*?</script>', "", html, flags=re.S)
    html = re.sub(r'<link href="https://fonts.googleapis.com[^>]*>', "", html)
    html = html.replace("<x-dc>", "").replace("</x-dc>", "").replace("<helmet>", "").replace("</helmet>", "")
    html = html.replace('ref="{{rootRef}}"', "")
    img = (f'<img src="{tool_uri}" alt="" style="width:1587px;height:1123px;display:block">'
           if tool_uri else '<div style="width:1587px;height:1123px;background:#fff"></div>')
    html = re.sub(r"<dc-import\b[^>]*>\s*</dc-import>", img, html)
    html = re.sub(r"\{\{[^}]+\}\}", "", html)
    html = html.replace("</head>", faces + "<style>html,body{margin:0;background:#000}</style></head>", 1)
    return html, size, unmapped


CHECK_JS = """(minPx) => {
  const W = innerWidth, H = innerHeight, out = [], seen = new Set();
  const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
  let n;
  while ((n = walker.nextNode())) {
    const t = n.textContent.trim(); if (!t) continue;
    const el = n.parentElement; if (!el || seen.has(el)) continue; seen.add(el);
    if (el.closest('.tw')) continue;               // text inside the tool image window is the tool's own
    const cs = getComputedStyle(el); if (cs.visibility === 'hidden' || cs.display === 'none') continue;
    const fs = parseFloat(cs.fontSize), r = el.getBoundingClientRect();
    if (fs < minPx) out.push(`text under ${minPx}px (${fs}px): "${t.slice(0, 40)}"`);
    if (r.width && (r.right > W + 1 || r.bottom > H + 1 || r.left < -1 || r.top < -1))
      out.push(`text off the board: "${t.slice(0, 40)}"`);
  }
  // a tool card (or any image card) must never sit on words
  const cards = [...document.querySelectorAll('.tw')].map(e => e.getBoundingClientRect());
  const w2 = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
  while ((n = w2.nextNode())) {
    const t = n.textContent.trim(); if (!t || !n.parentElement || n.parentElement.closest('.tw')) continue;
    const rg = document.createRange(); rg.selectNodeContents(n);
    for (const r of rg.getClientRects()) for (const c of cards) {
      const ix = Math.min(r.right, c.right) - Math.max(r.left, c.left), iy = Math.min(r.bottom, c.bottom) - Math.max(r.top, c.top);
      if (ix > 0 && iy > 0 && ix * iy > .15 * r.width * r.height) { out.push(`the tool covers words: "${t.slice(0, 40)}"`); break; }
    }
  }
  return [...new Set(out)];
}"""


KEEP_CLEAR_JS = """(clear) => {
  // map each photo's keep-clear boxes (faces, the subject) from image fractions to board pixels,
  // honouring object-fit / object-position, then list the text, bands and tool cards that sit on them
  const covers = [...document.querySelectorAll('.co,.h,.pr,.btn,.tw,.card,.legal,.li,.tag,.cap,.stat')];
  const name = e => ({tw: 'the tool', pr: 'the promise', co: 'the callout', h: 'the headline', btn: 'the button'})[e.classList[0]] || e.classList[0];
  const out = [];
  for (const img of document.querySelectorAll('img[data-blob]')) {
    const boxes = clear[img.dataset.blob]; if (!boxes || !img.naturalWidth) continue;
    const r = img.getBoundingClientRect(), cs = getComputedStyle(img);
    const nw = img.naturalWidth, nh = img.naturalHeight;
    let s = 1, sx = r.width / nw, sy = r.height / nh;
    if (cs.objectFit === 'cover') s = Math.max(sx, sy); else if (cs.objectFit === 'contain') s = Math.min(sx, sy);
    const rw = cs.objectFit === 'fill' || cs.objectFit === '' ? r.width : nw * s;
    const rh = cs.objectFit === 'fill' || cs.objectFit === '' ? r.height : nh * s;
    const pos = cs.objectPosition.split(' ').map(v => v.endsWith('%') ? parseFloat(v) / 100 : null);
    const ox = r.left + (r.width - rw) * (pos[0] ?? .5), oy = r.top + (r.height - rh) * (pos[1] ?? .5);
    for (const [fx, fy, fw, fh, label] of boxes) {
      const F = {x: ox + fx * rw, y: oy + fy * rh, w: fw * rw, h: fh * rh};
      // only the part of the box that is actually visible inside the image's own frame
      const vx = Math.max(F.x, r.left), vy = Math.max(F.y, r.top), vw = Math.min(F.x + F.w, r.right) - vx, vh = Math.min(F.y + F.h, r.bottom) - vy;
      if (vw <= 0 || vh <= 0) continue;
      if (vw * vh < .9 * F.w * F.h) out.push(`${label || 'face'} in ${img.dataset.blob.slice(0, 6)} is cropped by its frame`);
      const hit = new Set();
      for (const c of covers) {
        if (c.contains(img)) continue;
        const b = c.getBoundingClientRect();
        const ix = Math.min(vx + vw, b.right) - Math.max(vx, b.left), iy = Math.min(vy + vh, b.bottom) - Math.max(vy, b.top);
        if (ix > 0 && iy > 0 && ix * iy > .12 * vw * vh) hit.add(name(c));
      }
      if (hit.size) out.push(`${label || 'face'} in ${img.dataset.blob.slice(0, 6)} covered by ${[...hit].join(', ')}`);
    }
  }
  return out;
}"""


async def render(boards, out, tool, font_dir, scale, blob_args=(), min_px=18, keep_clear=None):
    from playwright.async_api import async_playwright
    faces, fams = font_faces(font_dir)
    tool_uri = data_uri(tool) if tool else ""
    blobs = {}
    for arg in blob_args:
        bid, _, path = arg.partition("=")
        blobs[bid.strip()] = data_uri(path.strip())
    out.mkdir(parents=True, exist_ok=True)
    async with async_playwright() as p:
        b = await p.chromium.launch()
        for path in boards:
            src = pathlib.Path(path).read_text(encoding="utf-8")
            html, (w, h), unmapped = standalone(src, tool_uri, faces, blobs)
            used = set(re.findall(r"'([A-Z][A-Za-z ]+)'\s*,", html))
            missing = sorted(used - fams)
            page = await b.new_page(viewport={"width": w, "height": h}, device_scale_factor=scale)
            await page.set_content(html, wait_until="load")
            await page.wait_for_timeout(400)
            issues = await page.evaluate(CHECK_JS, min_px) if min_px else []
            if keep_clear:
                issues += await page.evaluate(KEEP_CLEAR_JS, keep_clear)
            dest = out / (pathlib.Path(path).name.replace(".dc.html", "") + ".png")
            await page.screenshot(path=str(dest), clip={"x": 0, "y": 0, "width": w, "height": h})
            await page.close()
            note = f"  (no font file for: {', '.join(missing)})" if missing else ""
            for i in issues:
                note += f"\n    ! {i}"
            if unmapped:
                note += f"  (no --blob for asset: {', '.join(sorted(unmapped))})"
            print(f"wrote {dest}  {w * scale}x{h * scale}{note}")
        await b.close()


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("boards", nargs="+")
    ap.add_argument("--out", required=True)
    ap.add_argument("--tool", help="exported Event Magnet tool PNG (stands in for <dc-import>)")
    ap.add_argument("--blob", action="append", default=[], metavar="ID=PATH",
                    help="local file for a canvas asset /_blob/<ID> (repeat for each asset)")
    ap.add_argument("--fonts", help="folder of <family>-<weight>.woff2 files")
    ap.add_argument("--min-px", type=int, default=18,
                    help="flag any text smaller than this (mobile floor; 0 = off) and text pushed off the board")
    ap.add_argument("--keep-clear", help="JSON {asset id: [[x, y, w, h, label], ...]} — the faces and subject of each "
                    "photo as fractions of the image; any text, band or tool card on them is listed")
    ap.add_argument("--scale", type=int, default=1, help="1 = Ads Manager size; 2 = retina")
    a = ap.parse_args()
    asyncio.run(render(a.boards, pathlib.Path(a.out), a.tool, a.fonts, a.scale, a.blob, a.min_px,
                      json.loads(pathlib.Path(a.keep_clear).read_text()) if a.keep_clear else None))


if __name__ == "__main__":
    sys.exit(main())
