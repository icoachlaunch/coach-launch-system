# Concepts, sizes and boards — built around the Event Magnet™ tool

## Contents
1. Where the creatives are built
2. The first set — 7 concepts × 3 looks
2b. AI images
3. Readable on a phone — the type and size floor
4. Building the boards
5. The creative rules
6. Concepts for the other stages

---

## 1 · Where the creatives are built — the business's own Dragon Fire Ads™ canvas

The ads live on **their own canvas**, never on the Event Magnet™ canvas: one Design canvas per business,
titled **"<Business> — Dragon Fire Ads"**, where every pack is built, managed and reworked apart from the tool.
The Event Magnet™ canvas keeps only the tool pages and its own opt-in ad (`cl-event-magnet-visual`); this
skill never adds, moves or edits a board there.

- **First run for the business:** create the canvas from the Design type
  (https://claude.ai/artifact/QKN21svewxgyPb6SYRqWnd) with `type_url`, title "<Business> — Dragon Fire Ads",
  and install the business's design system (`designSystems` in `canvas.json`, tokens copied to
  `project/ds/<namespace>/tokens.json`):
  - **a client** → Event Magnet Panels (https://claude.ai/artifact/TyCy1Cak6vg7kvjYWKztej), worn in their Kit;
  - **Coach Launch** → its own default design system (the account default is Coach Launch's — correct here and
    only here). When the canvas creation offers the default "use it without asking", ignore it for a client.
- **Every later run:** the canvas link is in the business's `CONTEXT.md` (Dragon Fire Ads row) — `read` it
  first and build on it. Never start a second canvas for the same business.
- **The tool and photos come in as assets**, not imports (a `dc-import` only reaches boards on the same
  canvas): upload the exported tool PNG (from `cl-event-magnet-visual`) and each real photo with
  `asset: true` (`file_paths` for several in one call), and place them as `<img src="/_blob/<id>">` exactly as
  the result gives the url. Record the asset ids in `CONTEXT.md` so later packs reuse them. When the tool page
  changes, export it again, upload the new PNG and swap the one src on every board.
- **Layout = one row per pack, in run order.** Each pack sits under a `title1` note
  ("Convert pack · <Campaign>", "Motivate pack · <event date>", "Attract pack", "Engage · week <n>"), the
  boards in slot order (CV1 → CV5, MO1 → MO3 …) at `x = i × 1160`, video slots as poster boards in their
  place, a second row under the pack for its 9:16 and 1:1 versions. Packs stack down the canvas with the
  newest at the bottom; an old cycle's row stays as the record (retitle its note "… · ran <dates>").

In one message, `read` from the design system: `project/README.md`, `project/kits.json`,
`project/templates/ad-4x5.dc.html`. Every concept below starts from the ad template's `<helmet>` block, its
logic `<script>` (the six Kits, `apply()`, `renderVals()`) and its classes (`.ad-eyebrow .ad-pill .ad-h
.ad-sub .ad-btn .ad-who`), copied verbatim; only the body changes.

## 2 · The first set — 7 concepts × 3 looks = 21 statics

A pack's first build is **21 statics**, so the operator has real choice and Meta has real variety: seven
concepts, each in three looks. Later cycles add to the winners rather than starting again.

**Every board carries, top to bottom:** the avatar callout (a callout variant from the brief, rotated across
the set) · the headline (the angle's lead hook, ≤ 12 words, one phrase in the accent) · the visual · **the
$Million Promise™** in its own band · the button. Nothing else — no lockup, no names in the corner, no
eyebrow labels, no sub-lines in small type. The promise is the default on every image; a page-headline test
runs in the copy and on the page, never by dropping the promise off the image.

| # | Concept | Slot | Visual |
|---|---|---|---|
| 1 | **Pain** | CV1 · A1 Recognition | An AI frustration scene (the avatar stuck in the struggle line) with the tool as a tilted card over it |
| 2 | **Host** | CV2 · A2 Seen | The host's turning-point line as the headline; *Then / Now* photos (the empty virtual room · the host celebrating), or one full photo of the host. Real photos first; AI scenes of the host only from their real photo and with the operator's OK |
| 3 | **Tool** | CV3 · A3 The Tool | The tool filling the visual edge to edge (full bleed, or zoomed into the columns that matter) — no white margin around it |
| 4 | **Proof** | CV4 · A4 Proof | A big stat card (the real client result, their name, what they do, five gold stars) over a zoomed tool crop; legal line |
| 5 | **Two Roads** | CV5 · A5 The Door | An AI frustration image over **The old way** (red tag, red ✕ lines) and an AI joy image over **The new way** (green tag, green ✓ lines), side by side |
| 6 | **Result-led** | any Convert slot | The $Million Promise™'s core result *is* the headline — "How coaches close 3–5 high-ticket clients from their next virtual event"; an AI joy scene and/or the tool |
| 7 | **Stats** | any Convert slot | The result as the business's own ("How we close 3–5 high-ticket clients in our virtual events"), the track record under it (from the Card or page); the host photo or the tool; legal line |

**The three looks:**

- **Dark** — the Kit's dark band ground, white type, the accent for the highlight phrase.
- **White** — white ground, ink type, the brand colour for the highlight; the callout pill flips to ink.
- **Photo** — an AI (or real) photo full bleed, a dark gradient top and bottom so the type reads, white type.

No real proof → concept 4 is skipped and its row carries `[MISSING CONTENT — one real client result]`.
No track record on the Card or page → concept 7 is skipped the same way. Generated people are never named
and never stand in for a testimonial; a named result never sits beside an AI face.

## 2b · AI images (Nano Banana via `cl-image-gen`)

The tool alone doesn't give enough to work with, so each first set comes with its own images:

1. List what the seven concepts need — usually: 2 frustration scenes (one 4:5, one 1:1 for two roads), 2 joy
   scenes (the same pair), an empty virtual room, a full virtual room (a gallery of engaged faces on a
   laptop), and 1–2 host scenes (presenting live, celebrating).
2. Generate with `scripts/gen_images.py` (the `cl-image-gen` runner plus the edit model): generic people
   with `google/nano-banana`; the host from their real photo with `google/nano-banana-edit` and
   `image_urls` (upload the real photo first from the operator's computer — the sandbox can't reach Kie's
   upload host). Prompts describe the avatar's world (age, setting, the struggle or the win); end every
   prompt with the `cl-image-gen` house-style suffix plus "no words on any screen".
3. The image CDN is reachable only from the operator's computer: download there into the business's images
   folder (Coach Launch: `Reference/images/dragon-fire-ads/`; a client: their `brand-kit/images/dragon-fire-ads/`),
   stage them, resize to 1200 px JPEGs, upload them to the ad canvas as assets.
4. Record each image's keep-clear boxes (faces, subject) in `keep-clear.json` (SKILL.md Stage 1b) — the
   render check maps them onto every board that uses the image.
5. Guided: show the images and wait for a yes before building. Fast: build with them and show them with the
   set; the operator swaps any in the canvas.

## 3 · Readable on a phone — the type and size floor

A 1080 px ad shows about 390 px wide on a phone, so:

| Element | Size |
|---|---|
| Any text on the image | **never under 18 px** (the legal line is 20 px; nothing else that small) |
| Callout pill | 26 px bold, padded 14 × 22, balanced over two lines when long |
| Headline | 80 px (68 px for 3 lines, 58 px for a promise-length headline) — never under 56 px |
| $Million Promise™ band | 30 px semibold, 10 px brand rule on the left, the outcome phrase bold in the accent |
| Two-roads lines | 27 px, with 38 px red ✕ / green ✓ discs; tags 24 px on solid red `#d92d3a` / green `#1f9d57` |
| Button | full width, 104 px tall, 40 px uppercase display face |

`render_ads.py` checks every board: any text under 18 px or pushed off the board is listed. Fix them all
before the PNGs leave the session.

| Size | Board | Use | Rule |
|---|---|---|---|
| **4:5 · 1080 × 1350** | every concept | Feed (Facebook, Instagram) | Main size. 56 px margins; photo and tool visuals may bleed to the edges |
| **9:16 · 1080 × 1920** | the winners | Stories, Reels | Keep text and button out of the top 270 px and the bottom 670 px, 65 px from each side |
| **1:1 · 1080 × 1080** | the winners | Right column, some placements | Promise band stays; headline ≤ 9 words |

## 4 · Building the boards

1. Scratchpad folder, one file per board, named by the plan's slot and the concept:
   `project/Ad-CV1-pain-callout.dc.html`, `project/Ad-CV3-tool-hero.dc.html`, `project/Ad-MO1-reminder.dc.html`,
   sizes as suffixes (`-9x16`, `-1x1`). Each root sets its own `width`/`height` and `$preview`.
2. **Set the Kit exactly as `cl-event-magnet-visual` Step 3 does** — the Kit id in the root's inline
   variables, the `kit` default in `data-props`, and every `??` fallback; OVERRIDES via `useOwnHero` / `hero` /
   `inkOnHero`; font overrides on the root and the Google Fonts link. Copy the Kits table verbatim (it is
   JSON; retyping it breaks the script). Keep SVG attributes camelCase.
3. The tool is placed three ways, all as the canvas asset `<img src="/_blob/<tool id>">`:
   **fill** (`object-fit:cover` across the whole visual area, cropped not shrunk), **zoom** (the image at
   1400–1500 px wide, offset so the columns that matter fill the box) and **card** (a tilted card over a
   photo, its height set from the tool's own proportions, breaking the frame). Never a small tool floating in
   white space; on every concept, including host, proof, stats, promise-led and two roads (a small card
   breaking out of the new way's image).
   `assets/example-build-21.py` is a worked generator for the whole set (Coach Launch's Convert pack —
   copy its structure, never its copy, for a client).
4. Photos: `<img src="/_blob/<photo id>">` (upload a 1080 px JPEG; crop with `object-fit:cover`).
5. Add the boards to the Dragon Fire Ads canvas's `project/canvas.json` (read it first; never drop existing
   boards or older packs): the pack's `title1` note, then its row 300 px below the note at `x = i × 1160`,
   the 9:16 and 1:1 row under it; the next pack starts 600 px under the last row. Board titles:
   `CV1 · Pain Call-out · 4:5` — never a paper size, never "draft".
6. **Before every publish, `read` the canvas back** and diff it against what you last published — the
   operator may have edited by hand between boards; their edits win and their changed values (sizes,
   weights, spacing) become rules for the next boards. Then publish to the canvas `url` with `root` = the
   folder, `file_path` = `project/canvas.json`, `files` = the new or changed boards only (existing files are
   kept). A refused publish means someone saved meanwhile: re-read and re-apply.
7. Render and look (Stage 3): the visual area is the flexible part, so text never collides — but check the
   contact sheet for a tool or photo overlapping the promise or button, a crop that cuts a face, and the
   size report. Too tall → cut words first, never the type below the floor in §3.
8. Lay the set out as one row per concept and one column per look (dark · white · photo), under the pack's
   title note.

## 5 · The creative rules

- The creative sells the outcome; the tool is proof that there's a real, visual thing behind the promise.
- One CTA bar, matching the destination's button word ("Save my free seat", "Message us", "Join live").
- No date, weekday, time or price baked into a creative — it would go stale or mismatch the page. "Free"
  is fine.
- No fake UI (play buttons, notification badges, close-Xs), no before/after body imagery.
- Client icons suit the client's niche (Streamline when connected, recoloured to the Kit) — never the
  hand-drawn Coach Launch style on a client creative.
- Every result shown carries the legal line.
- Red means the old way, green the new — never decoration.
- The $Million Promise™ is on every image, readable at a glance (§3), and its core result is the driving force:
  it leads the result-led and stats headlines and is bolded in every promise band. Keep the result phrase on one
  line (`white-space:nowrap` on "3–5 high-ticket").
- **Never the signature system's name on an image** (Coach Launch: the $100K Day Engine®). It's introduced inside
  the virtual event. Where the tool page itself prints it (a "where this fits" strip), crop it out of fills and
  zooms (`object-position: center 0%`); on small cards it's unreadable — and the cleaner fix is an ad export of
  the tool without that strip from `cl-event-magnet-visual`.
- No small print: if a line can't be 18 px or more, it comes off the image (it belongs in the primary text).
- **Faces are never covered** — not by the callout, headline, promise band, button or tool card — and never
  cropped at the frame. On a full-bleed photo, move the photo (anchor it below the headline, `object-position`)
  rather than the type; on a framed photo, use `object-position` so the whole head is in.
- **The system on every ad.** It drives the curiosity: a process people can see. Every board carries the tool —
  fill, zoom, or a card. Cards **break the frame**: they overhang the photo's top-right or bottom-right corner
  (≈ 40–60 px past the edge), tilted 3–5°, in the corner away from the face. They never sit on words.

## 6 · Concepts for the other stages

| Slot type | Concept | Composition |
|---|---|---|
| **Motivate** (MO1, MO3) | **Reminder** | The date badge is the hero: a large `band-accent` block with the virtual event's day and date (the audience's own dates when they differ — e.g. "Wed 25 Nov (US) · Thu 26 Nov (AU)"), the format and "live online", the tool at 45 % beside it, the button. The only creatives that carry a date. A new board (or a date edit on the canvas) every cycle |
| **Attract** (AT4) | **Carousel** | 5–7 cards at 1080 × 1080: card 1 the hook (the map title), cards 2–6 one phase or idea each (the Magic Formula™ visual cropped per phase, or a short line per card), last card the soft next step. Board per card: `Ad-AT4-1.dc.html` … |
| **Engage** (static days) | **Quote card** / **Proof card** | Quote card: the map title as a pull quote in the display face, the host's round photo and name. Proof card: as the Convert proof concept, with the testimonial as written and the results line |
| **Video slots** | **Statics in their place** | The video skills make the cut; until then the slot runs its static concept (CV2 Host, CV5 Two Roads) |
