#!/usr/bin/env python3
"""Turn a canvas artboard (.dc.html) into a self-contained HTML page that opens in any browser and
prints to PDF (landscape, scaled to fit Letter or A4).

Usage:  standalone_html.py <board.dc.html> <out.html> [--pdf] [--paper letter|a4]

--pdf also writes <out>.pdf when Playwright + Chromium are installed (pip install playwright;
python -m playwright install chromium). Without them the HTML alone is written and the browser's own
Print → Save as PDF does the rest.
"""
import re, sys, pathlib

args = [a for a in sys.argv[1:] if not a.startswith('--')]
flags = [a for a in sys.argv[1:] if a.startswith('--')]
if len(args) < 2:
    sys.exit(__doc__)
src_path, out_path = pathlib.Path(args[0]), pathlib.Path(args[1])
paper = 'letter'
for f in flags:
    if f.startswith('--paper='):
        paper = f.split('=', 1)[1].lower()
if '--paper' in flags:
    i = sys.argv.index('--paper'); paper = sys.argv[i + 1].lower()

html = src_path.read_text(encoding='utf-8')
html = html.replace('<script src="./support.js"></script>', '')
html = re.sub(r'<script type="text/x-dc".*?</script>', '', html, flags=re.S)
html = html.replace('<x-dc>', '<div class="page-wrap">').replace('</x-dc>', '</div>')
html = html.replace('<helmet>', '').replace('</helmet>', '')
html = html.replace('ref="{{rootRef}}"', '')

size = '11in 8.5in' if paper == 'letter' else '297mm 210mm'
pw, ph = (11 * 96, 8.5 * 96) if paper == 'letter' else (297 / 25.4 * 96, 210 / 25.4 * 96)
zoom = min(pw / 1587, ph / 1123) * 0.995   # fit both ways, with a hair of slack so nothing spills to page 2
print_css = f"""<style>
@page{{size:{size};margin:0}}
html,body{{margin:0;background:#e6e7ea}}
.page-wrap{{display:inline-block;transform-origin:top left}}
@media print{{html,body{{background:#fff}}.page-wrap{{zoom:{zoom:.4f}}}}}
</style>"""
html = html.replace('</head>', print_css + '\n</head>', 1)
out_path.parent.mkdir(parents=True, exist_ok=True)
out_path.write_text(html, encoding='utf-8')
print(f'wrote {out_path}')

if '--pdf' in flags:
    try:
        import asyncio
        from playwright.async_api import async_playwright
    except ImportError:
        print('Playwright not installed — HTML only. Print → Save as PDF from any browser.')
        sys.exit(0)
    pdf_path = out_path.with_suffix('.pdf')

    async def main():
        async with async_playwright() as p:
            b = await p.chromium.launch()
            pg = await b.new_page(viewport={'width': 1587, 'height': 1123})
            await pg.goto(out_path.resolve().as_uri())
            await pg.wait_for_timeout(1500)
            await pg.pdf(path=str(pdf_path), landscape=True,
                         width='11in' if paper == 'letter' else '297mm',
                         height='8.5in' if paper == 'letter' else '210mm',
                         print_background=True, prefer_css_page_size=True)
            await b.close()
    asyncio.run(main())
    print(f'wrote {pdf_path}')
