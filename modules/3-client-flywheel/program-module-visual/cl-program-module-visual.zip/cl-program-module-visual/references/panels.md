# Panels — the page design system

The module page is a one-page tool built from panels, in the user's own Brand Kit. The anatomy, the nine
layouts, the three structures, the sizes and the fill mechanisms are fixed here. The copy comes from the
Module Spec. The colours, fonts and corners come from the BRAND KIT block. The page tells a story:
*where you're stuck → the work → the result → done when + proof → where this fits → the closing bar.*

## The design layer (every page)

1. **Kit display fonts everywhere a headline sits**: title, panel labels, result titles, the belief line.
   No marker or novelty face. The mono face (`JetBrains Mono`, `--font-mono`) carries eyebrows, zone labels,
   phase labels, section headers and sticky labels.
2. **An icon on every panel and every named row.** Panel icons top-right in a brand-tinted tile (`.em-ico`);
   row icons in a `.em-rowico` square. Geometric stroke glyphs on a 24-unit grid, stroke 2, round caps, drawn
   for the *object* of the row. The templates' `ICONS` table holds ~60 to copy the style from. No emoji, no
   clip art.
3. **One hero visual per layout** (gauge · progress bar · gap bars · finished card · timeline · picks card ·
   speech bubble · mini quadrant · big dollar field + multiplier), drawn in HTML/SVG from band tokens so it
   scales to its slot (≈ 330px in a rail, 290px in the C band).
4. **The sticky** (`.em-sticky`): the one answer on a `highlight` note with two fill lines side by side. The
   only warm tint on the page.
5. **Section definition**: every core block has a 1px `line` border and a soft tight shadow
   (`0 6px 16px -6px rgba(0,0,0,.14)`); dark blocks a slightly deeper one. 12px of vertical air between zones.
6. **The fill rule**: the work panel always fills its zone. Rows don't stretch; `.em-spare` (a ruled notes
   area with a small mono label) takes whatever height is left and disappears when there is none.
7. **Five gold stars** (`#F2B21B`, fixed across Kits) bottom-right of every testimonial card.
8. **Mechanisms any row can borrow**: a **rank box** (`.em-rank`) at the end of a row so the member has to
   decide the #1; **stage colours** (`.em-stagecolor` on the root paints the phase labels and chip rails in
   `--s1/--s2/--s3`); **hatched cells** (`.em-na`) where a column doesn't apply; the **multiplier line**
   (`.em-mult`) under any headline number that scales by weeks, clients or units. Use them when the spec's
   Result asks for a rank, a lifetime figure or a sectioned score — not as decoration.
9. **Phase colours on the progress tracker**: each phase has its own colour (`--p1/--p2/--p3`); later
   modules carry a 3px phase top border, this module is filled, earlier modules are tinted with a ✓.
10. **The closing bar is quiet.** Belief line · commitment · one Next button. No offer, no price, no QR.

## Word budgets (characters, incl. spaces) — cut to fit, never shrink type

| Slot | Budget | Slot | Budget |
|---|---|---|---|
| Title (the step name — never shortened; drop to 54px if > 28) | 28 at 60px | Subtitle (the promise) | 95 |
| Struggle title | 34 | Struggle body | 120 (110 in B/C columns) |
| Panel label | 32 | Teaching line | 110 |
| Row name | 22 | Row descriptor | 36 (Checklist/Audit 44) |
| Result title | 24 | Band: bold name 18 + tail 28 | (C band: 2 lines allowed) |
| Sticky label (each) | 22 | Done-when item | 48 (3–4 items; merge rather than add a fifth) |
| Quote 90 · attribution 40 | | Belief line | 40 |
| System name | 28 | Step chip | full name on two lines (leading "The" dropped) |
| You-are-here line | 110 | Cheat-sheet entry: name 22 · when 36 · say 95 | |
| Script beat: title 24 · words ≤ 30 · bubble line 110 | | Matrix: quadrant name 10 · meaning 55 · axis label 32 | |
| Audit: setup tile label 32 · section band title 16 + sub 32 + formula 36 · row name 20 · descriptor 44 · band 18 + 28 | | | |

## Fit rules (landscape page, 1587 × 1123 internal)

- Type floors: body 15–17px; chips, bands and mono labels 13–14px; nothing under 13px except the 10.5px
  legal line.
- **Height budget:** banner ≈ 150 · struggles row ≈ 150 (A) · Done when + proof ≈ 110 · fits ≈ 150 · closing
  bar ≈ 100 · gaps 5 × 12 · padding 48 → **≈ 390px for the work zone in A**; ≈ 540px in B; ≈ 375px in C
  (the Result band sits inside C's right column).
- Heights: struggle card 140 · panel chrome 70 · scale row 44 · section header 44 · table header 60, row 38 ·
  checkbox row 42 · field 48 · stage card 180 · result rail: visual 90–100, band row 36, sticky 75 ·
  horizontal band 150.
- Per layout: Audit → structure B only, five rows in three sections or six in two. Cheat Sheet → nine entries
  at ≈ 92px each is the ceiling in A. Script → five beats of ≤ 30 words; a sixth needs B or C. Matrix → eight
  items in A; quadrant meanings ≤ 55.
- If it doesn't fit: shorten copy to the budgets first, then drop a blank writing row (keep at least 2 plus
  the example), then fold a second panel into the Result. Never shrink type below the floors; never cut spec
  content without saying so. `.em-card{overflow:hidden}` (in the templates) clips a tall panel rather than
  letting it overlap the next zone.

## The Kits

Six Kits, named on the first line of the BRAND KIT block: **Crimson · Ink · Ember · Sovereign · Voltage ·
Meadow**. Each is a theme in `assets/tokens.json`; `assets/kits.json` holds the exact values the template's
logic writes onto the root (`static KITS`, JSON — double quotes always). Voltage is a dark Kit; the files
carry its light print variant.

- **Set the Kit three ways so they agree:** the root's inline CSS variables, the `kit` default in
  `data-props`, and the `?? 'kit'` fallback in `apply()`. The canvas's **Kit** tweak then switches the whole
  page live.
- **OVERRIDES** (`--brand: #… · --ink-on-brand: #…`): `useOwnHero` default `true`, the `hero`/`inkOnHero`
  defaults set. `apply()` does the contrast work: the hero fills tile, numerals, the on-chip and the button;
  it becomes accent text only if ≥ 4.5:1 on paper and ≥ 1.6:1 from the ink; it goes on the dark band only
  if ≥ 3:1 there. Mid-brightness heroes (gold, green, cyan) carry dark `ink-on-brand`; never white on them.
- **Colour budget:** canvas, paper and ink carry ~80 %; the banner, Result, testimonial and belief line are
  the dark blocks; the hero marks the reading path; `highlight` appears on the sticky and the middle gauge
  arc; `pos`/`neg` only inside visuals, calculated fields and the struggle numerals.

## Content rules

- Every word comes from the spec. Tighten for fit; never change a meaning, name, price or number.
- Content the spec marks `[MISSING CONTENT — …]` stays on the page, naming what is missing, and is listed in the reply. `[PHOTO]` stays until
  a headshot is supplied.
- The user's names keep their own ™/® exactly as written. Nobody else's names, figures or branding appear.
- Spelling follows the user's documents.
