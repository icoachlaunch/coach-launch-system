# Page build — from a Module Spec to the finished page

Read `panels.md` first (anatomy, word budgets, fit rules, Kits). This file is the procedure.

The pages are built from the templates in `assets/templates/`. Each template is a complete artboard for
one layout: the same `<helmet>` CSS block (every class the pages use), the same logic script (all six Kits),
and a worked example for a **fictional** business. Use a template for its structure, classes and CSS only —
never its copy, names, colours or icons.

## 1 · Map the spec to the eight zones

Every module page, whatever its layout or structure, has these zones in this order.

| Zone | From the spec | On the page |
|---|---|---|
| **1 Banner** (dark, full-bleed) | header + A1 + A7 | mono eyebrow `Module 0N of 9 · [Phase name]`; the step's **icon tile (84px) left of the title and subtitle**, the eyebrow above both; title = the step name in the Kit display face, one word in `band-accent`, ™ as `<sup class="em-tm">™</sup>`; subtitle = the chosen promise; lockup top-right: program name · user's name · business, then the **headshot** (84px circle, `band-accent` ring) — right column 340px |
| **2 Where you're stuck · 3 struggles** | B1 | three numbered cards: title (≤ 34) + one or two sentences (≤ 120; 110 in B/C) |
| **3 The work · do this in one session** | A3 | the working panel(s): numbered brand square + Kit-display label, teaching line, the fill mechanism, coined rows with icons, the `.em-spare` notes area with the spec's label |
| **4 The result** | A4 | dark Result block: eyebrow `The result`, title, the hero visual, bands/fields, the sticky (two fill lines side by side) |
| **5 Done when + proof** | B4 + B5 | the **Done when** card (3–4 tick items, two columns) beside the dark testimonial card with five gold stars. No stat tiles. Missing proof → the quote card carries the spec's `[MISSING CONTENT — a member result for this step]` |
| **6 Where this fits** | A5 | the system name™, nine step chips in three phases in **phase colours** (below), then ONE line: *You are here → Module N of 9. [what you made]. **Next: Module 0N+1 · [Step name]** [uses it to…].* Module 9's line names the member's ongoing rhythm instead |
| **7 The closing bar** | A6 | `.em-foot`: left, the **belief line** on a dark band with the user's name; middle, **My commitment** — "Completed on ___ · Signed ___" and "☐ Reviewed with [name] on our next call"; right, one button reading **Next →** (literal text, so it can be retyped on the canvas). No offer, price or QR |
| **8 Legal line** | — | `© [Business]` right, 10.5px, at the page foot; the left line *Results not typical. Individual results vary.* only when a real member result is printed |

Copy rules: the spec's words, tightened only to the word budgets in `panels.md`; never a changed name,
number or claim. The spec is verified content. Any `[MISSING CONTENT — …]` in it stays visible on the page,
naming what is missing; a missing headshot is the `[PHOTO]` circle. Both are listed in the reply.

## 2 · Layout and structure

**Layout** comes from the spec's Layout line:

| Layout · template | The member… | Work panel(s) | Hero visual in the Result |
|---|---|---|---|
| **Worksheet** · `worksheet.dc.html` | builds it | fields + a tension table / formula + a fill-in sentence | the finished card, tilted |
| **Matrix** · `matrix.dc.html` | places it | a lettered list of their items (`.em-plot`) beside a ruled 2 × 2 (`.em-quad`) with axis labels and a one-line meaning per quadrant | the mini quadrant with a dot |
| **Calculator** · `calculator.dc.html` | counts it | input table (example row + 3 blank) with a calculated column and printed formula, beside a checklist panel | gap bars + THE GAP |
| **Checklist** · `checklist.dc.html` | ticks it | named rows with tick boxes ("Tick if true") in two sections | 8-segment progress bar + the count |
| **Script** · `script.dc.html` | says it | five `.em-beat` frames left → right: beat header, title, the words with blanks, "My version" | the speech bubble with the one line |
| **Workflow** · `workflow.dc.html` | sequences it | a Start-here row (now vs target = gap) above three stage cards with arrows | a timeline with a flag — in the program's own time |
| **Cheat Sheet** · `cheat-sheet.dc.html` | references it | a 3 × 3 grid of `.em-entry` cards: numbered name, icon, tick, a "when" line, the line to use | the picks card "This week I'll use 1 · 2 · 3" |
| **Scorecard** · `scorecard.dc.html` | scores it | named rows with 1–5 circles in two sections | gauge with the bands as arcs + the total |
| **Audit** · `audit-B-sidebar.dc.html` | scores it AND prices it | setup strip (two inputs → one derived number), stage-coloured section bands with the formula, rows with 0–3 grip boxes · your number · tinted cost cell (hatched where no cost) · rank box | the big dollar field + the multiplier line |

Per-layout limits: Cheat Sheet nine entries, "say" line ≤ 95; Script five beats of ≤ 30 words (a sixth
needs B or C); Matrix eight items, quadrant meaning ≤ 55; **Audit is structure B only** (five rows in three
sections, or six in two).

**Structure** comes from the module number: 1 · 4 · 7 → **A Classic** (struggles in a row under the banner;
work panel left with the vertical Result rail to its right; Done when + proof beneath); 2 · 5 · 8 → **B
Sidebar** (dark left column: struggles stacked, then the Result rail; work panel full width right, Done when
+ proof beneath it); 3 · 6 · 9 → **C Split** (light left column: struggles stacked, Done when + proof
beneath; work panel right with the Result as a horizontal band under it). `scorecard-B-sidebar.dc.html` and
`scorecard-C-split.dc.html` carry the B and C markup to copy from. Override with a reason only: B gives the
work panel the most height; C has the tightest Result.

**Fit it to this spec** — the design layer every time (`panels.md`): Kit display fonts on every headline;
mono eyebrows and labels; an icon on every panel and every named row (geometric stroke glyphs on a 24-unit
grid, stroke 2, round caps, drawn for the object of the row — copy the style from the templates' `ICONS`
table, never an emoji); the hero visual redrawn for this module's result; the sticky with the one answer;
five gold stars on the testimonial; 1px borders with the soft shadow; the `.em-spare` fill rule. Cut copy
to the budgets before anything else. **Budget heights before writing:** the work zone is ≈ 390px in A,
≈ 540px in B, ≈ 375px in C (the closing bar takes ≈ 100px). Type floors: body 15–17px, labels 13–14px,
nothing under 13px except the legal line. If it doesn't fit: cut copy, then a blank writing row (keep ≥ 2
plus the example), then fold a second panel into the Result. Never shrink type below the floors; never cut
spec content silently. **Step names are never shortened**: a banner title over 28 characters drops to 54px
first; progress chips drop a leading "The" and show the rest in full on two lines.

## 3 · Set the Kit

From the BRAND KIT block (values in `assets/kits.json`):

1. `kit` = the Kit id. Set it in **three places** so they agree: the root's inline CSS variables (that
   Kit's values), the `kit` default in `data-props`, and the `?? '<kit>'` fallback in `apply()`.
2. **OVERRIDES** `--brand` / `--ink-on-brand`: set `useOwnHero` default `true` and the `hero` / `inkOnHero`
   defaults (same values in every `??` fallback). `apply()` does the contrast decisions — the Kit's accent
   text stays when the hero fails on paper; the Kit's hero stays on the dark band when the user's would
   disappear there. Mirror the result in the root's inline variables and say which roles the colour took.
3. **Font overrides:** `--font-display` / `--font-body` on the root, and the family added to the Google
   Fonts link.
4. Mid-brightness heroes (gold, green, cyan) take dark `ink-on-brand`. Never white on them.
5. **The Kits table in the logic script is JSON** (double quotes). A single-quoted font name inside a
   single-quoted string breaks the whole artboard ("Unexpected identifier"). Copy the table verbatim.

**Phase colours** (`--p1/--p2/--p3`, each with `-ink` and `-text`): use the Kit's if the BRAND KIT block
gives them. Otherwise Sovereign → `#b8912f/#0f1c33/#7d611c` · `#27406b/#fff/#27406b` · `#8c2f45/#fff/#8c2f45`;
any other Kit → p1 = `brand`, p2 and p3 = two hues from the user's Visual Style Guide (if the guide gives none, the Kit's `neg` and `pos-text`).
Every hue must pass 4.5:1 as text on paper and differ in lightness from its neighbours. Declare them on the
root's inline style.

## 4 · Write the artboard

For module N, in a scratch folder `project/`:

1. Start from the layout template; take the structure's outer markup from the matching scorecard template
   if the structure isn't A. Keep the `<head>`, the `support.js` line, the fonts link, the whole `<helmet>`
   CSS block, `ref="{{rootRef}}"`, and the logic `<script>` with all six Kits **verbatim** from the file you
   read; write the new body between them. Set `<title>` to `Module 0N · [Step name]`. Root stays
   1587 × 1123 (an internal size — never named), `$preview` the same.
2. **Append the module CSS** (below) to the end of the `<helmet>` `<style>` block.
3. Rebuild every zone from the map in §1. Zone 5 markup: a two-column grid (`minmax(0,1.3fr) minmax(0,1fr)`
   in A; stacked in the B/C column) of
   `<div class="em-done"><div class="em-proof-lbl"><b>Done when</b><span>tick to finish</span></div><div class="em-done-list">`
   + one `<div class="em-done-item"><i class="em-dbox"></i><span>…</span></div>` per item `</div></div>`,
   beside the template's `em-quote` card unchanged. Zone 7 replaces the template's `em-cta` with
   `<div class="em-foot"><div class="em-belief"><div class="em-belief-q">"…"</div><div class="em-belief-by">— [Name]</div></div><div class="em-commit"><div class="em-commit-lbl">My commitment</div><div class="em-commit-row"><span>Completed on</span><i></i><span>Signed</span><i></i></div><div class="em-commit-chk"><i class="em-dbox"></i>Reviewed with [Name] on our next call</div></div><a class="em-nextbtn" href="#next">Next →</a></div>`.
   Zone 6 chips: `<div class="em-step em-ph-next" style="--p:var(--p2);--p-ink:var(--p2-ink)"><i>5</i><span>[Step]</span></div>`;
   this module `em-ph-on`; earlier modules `em-ph-past` with `<i>✓</i>`; phase label
   `style="color:var(--p2-text);font-weight:700"`. Zone 1: the icon tile, title and subtitle sit in
   `<div style="display:flex;gap:20px;align-items:center;margin-top:8px">` with the tile first; the headshot is
   `<img class="em-headshot" src="data:image/jpeg;base64,…" alt="[Name]">` after the name block — the photo
   resized to 240px square and embedded as a JPEG data URI (so it shows in every export). No photo → keep the
   `[PHOTO]` circle and list it.
4. Keep all copy as literal markup; SVG attributes camelCase (`viewBox`).

### Module CSS (append verbatim)

```css
.em-done{display:grid;grid-template-columns:auto minmax(0,1fr);gap:14px;align-items:center;background:var(--paper);border:1px solid var(--line);border-radius:var(--r-md);padding:8px 14px;box-shadow:0 6px 16px -6px rgba(0,0,0,.14),0 1px 3px rgba(0,0,0,.06)}
.em-done-list{display:grid;grid-template-columns:1fr 1fr;gap:6px 18px}
.em-done-item{display:flex;gap:9px;align-items:flex-start;font-size:15px;line-height:1.3;color:var(--ink)}
.em-dbox{flex:none;width:18px;height:18px;border:1.5px solid var(--ink);border-radius:3px;margin-top:1px}
.em-step.em-ph-next{border-top:3px solid var(--p)}
.em-step.em-ph-next i{background:var(--p);color:var(--p-ink)}
.em-step.em-ph-on{background:var(--p);border:1.5px solid var(--p);color:var(--p-ink);font-weight:700;box-shadow:0 0 0 3px color-mix(in oklab,var(--p),transparent 78%)}
.em-step.em-ph-on i{background:var(--p-ink);color:var(--p)}
.em-step.em-ph-past{background:color-mix(in oklab,var(--p),var(--paper) 86%);border:1px solid color-mix(in oklab,var(--p),var(--paper) 55%);border-top:3px solid var(--p);color:var(--ink)}
.em-step.em-ph-past i{background:var(--p);color:var(--p-ink)}
.em-foot{display:grid;grid-template-columns:minmax(0,1.15fr) minmax(0,1fr) auto;gap:16px;align-items:stretch;background:var(--paper);border:1px solid var(--line);border-radius:var(--r-md);padding:10px;box-shadow:0 6px 16px -6px rgba(0,0,0,.14),0 1px 3px rgba(0,0,0,.06)}
.em-belief{background:var(--band);color:var(--band-ink);border-radius:var(--r-md);padding:12px 20px;display:flex;flex-direction:column;justify-content:center}
.em-belief-q{font-family:var(--font-display);font-weight:var(--weight-display);letter-spacing:var(--track-display);font-size:28px;line-height:1.1;color:var(--band-accent)}
.em-belief-by{font:600 12px/1 var(--font-mono);letter-spacing:.16em;text-transform:uppercase;color:var(--band-soft);margin-top:7px}
.em-commit{display:flex;flex-direction:column;justify-content:center;gap:8px;padding:4px}
.em-commit-lbl{font:600 12px/1 var(--font-mono);letter-spacing:.16em;text-transform:uppercase;color:var(--brand-text)}
.em-commit-row{display:grid;grid-template-columns:auto 1fr auto 1fr;gap:10px;align-items:end;font-size:15px;color:var(--ink-soft)}
.em-commit-row i{border-bottom:1.5px solid var(--ink);height:18px}
.em-commit-chk{display:flex;gap:9px;align-items:center;font-size:15px;color:var(--ink)}
.em-nextbtn{align-self:center;display:flex;align-items:center;gap:12px;background:var(--brand);color:var(--ink-on-brand);font:900 26px/1 var(--font-body);letter-spacing:.08em;text-transform:uppercase;text-decoration:none;padding:20px 34px;border-radius:var(--r-xs);border-bottom:4px solid var(--brand-deep);white-space:nowrap}
.em-tm{font-size:.42em;vertical-align:.95em;margin-left:3px;font-weight:600;color:var(--band-accent)}
.em-headshot{width:84px;height:84px;border-radius:50%;object-fit:cover;flex:none;border:3px solid var(--band-accent);box-shadow:0 6px 16px -6px rgba(0,0,0,.45)}
```

## 5 · Publish — the Design canvas (preferred) or standalone pages (fallback)

**Canvas.** If the Artifact tool is available and its type listing includes a **Design** type:

- One canvas for the whole program, titled "<System name™> Modules — <Business>", created from the Design
  type on Module 1 (`auto_open: "after_first_write"`); later modules are added to the same canvas.
- Boards: `Main.dc.html` for Module 1, then `Step02-<slug>.dc.html` … `Step09-<slug>.dc.html`; rows of three,
  80px apart, 120px between rows, in step order; every board `"w":1587,"h":1123,"print":"flow"` and
  `"paper":"letter"` for a US user, `"a4"` otherwise; title `Module 0N · [Step name]`.
- `project/canvas.json`:
  `{"v":3,"createdOnFiles":{"v":1,"at":"<now>"},"title":"<System name> Modules — <Business>","launch":{"view":"canvas"},"pages":[],"boards":{…},"order":[…],"notes":{},"designSystems":[]}`
- One publish per module: `root` = the scratch folder, `file_path` = `project/canvas.json`, `files` = the
  new artboard plus, on the first publish, `"project/ds/eventmagnet/tokens.json"` from `assets/tokens.json`.
- **Hand edits:** before every change, read the artboard back, diff it against what was last published, and
  keep the user's edits. Change only what's asked. A refused publish means someone saved meanwhile: re-read
  and re-apply.

**Standalone pages.** If there is no Design type (or the user asks for files): run
`python3 scripts/standalone_html.py project/<board>.dc.html out/module-0N-<slug>.html` for each board. It
strips the canvas wrapper and writes a self-contained HTML page (fonts from Google Fonts) that opens in any
browser and prints to PDF at landscape Letter/A4, scaled to fit. Deliver the HTML files (and PDFs if a
renderer is available: `--pdf` adds one when Playwright is installed). Say which route was used.

## 6 · Deliver each module

One line (module, layout, structure, Kit and any override), the placeholders left on the page, anything cut
to fit, and — on the last module — the export route.
