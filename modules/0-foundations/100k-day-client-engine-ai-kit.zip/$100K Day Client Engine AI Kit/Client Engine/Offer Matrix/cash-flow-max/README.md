# Cash Flow Max™
**Step 3 · Cash Flow Max™ · Offer Matrix™**

## What goes here
`cash-flow-max.md` — your paid cash-flow assets — the VIP upsell and the order bumps that raise cart value.

One canonical file, updated over time. Bump the version and add a revision-history row when it changes. Never a `-v2` or `-FINAL`.

## How it gets built
Run **the Cash Flow Max™ Builder** from Coach Launch Academy™ — download it from your Training Portal, paste it into a fresh chat, and answer one question at a time. When it finishes, save the output here as `cash-flow-max.md`.

## Needs first
Your locked Money Model (and Magic Formula™ — every asset is pulled from it).

## Feeds
The Cash Flow Engine™ funnel — its VIP and bump pages.

## Memory
`NOTES.md`, beside the asset — the decisions and why, what was rejected, what's still open, one line per session. Claude reads it before touching this asset and adds to it after every save (it makes the file the first time). Only the status line goes in `CONTEXT.md`; the reasoning stays here.

## File shape
```
---
asset: Cash Flow Max™
version: 1
last_updated: [date]
status: draft | complete
phase: [n/a | Launch | Execute | Growth | Mastery]
---
```
