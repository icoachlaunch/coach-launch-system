# Step 6 · Genie X Converter™
**Money Magnet™ · Pillar 2** — back-end follow-up messaging

When this step's builder ships in Coach Launch Academy™, its output is saved here. Nothing to do yet.

Builders are in **Coach Launch Academy™** — download from your Training Portal, paste into a fresh chat, run. Save each finished asset in its folder here as the one canonical file. Never a -v2.

## Memory
`NOTES.md`, beside the asset — anything you already know you want from this step, kept here until its builder ships; then the decisions and why, what was rejected, what's still open, one line per session. Claude reads it before touching this folder and adds to it after. Only the status line goes in `CONTEXT.md`.
