# Money Magnet™ — Pillar 2 · Steps 4–6
**Making the money** — fill the room, close it, and get paid before anyone shows up.

Each folder's `README.md` says what goes in it, which builder makes it, what it needs first and what
it feeds.

## Step 4 · The Sniper Close™ — the audience closes themselves
Three parts, built in order:
- `pass-instrument/` — your PASS™ Instrument (Part 1 · The Strategy Close), with a `sessions/`
  folder inside it for one client report per session you run
- `sniper-presentation/` — the Sniper Presentation™ Script (Part 2)
- `sniper-presentation-slides/` — the deck built from that Script (Part 3 — a skill in `skills/`)

**Needs first:** the whole Offer Matrix™ (Steps 1–3).

## Step 5 · Cash Flow Engine™ — profit before anyone shows up
- `cash-flow-engine/` — your self-liquidating event funnel, built in GHL AI Studio with the Cash
  Flow Engine™ Funnel Builder (a skill in `skills/`). One folder per phase, made as you build it.
- `authority-detonator/` — your Authority Detonator™ scripts: the show-up video on your thank-you page and the
  VIP video on your VIP upsell page. The Builder writes them; you record them.

**Needs first:** Step 3 (Event Magnet™, Money Model, Cash Flow Max™) and Step 4.

## Step 6 · Genie X Converter™ — close sales while you sleep
- `genie-x-converter/` — back-end follow-up messaging. *In development* — nothing to do yet.

---

Builders are in **Coach Launch Academy™** — download from your Training Portal, paste into a fresh
chat, run. Save each finished asset in its folder here as the one canonical file. Never a -v2.

**Feeds:** `Client Flywheel/` — traffic needs a proven close to send people to.
