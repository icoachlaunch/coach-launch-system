# The $100K Day AI Workspace

**Coach Launch · The $100K Day Engine™**

Welcome. This is your AI workspace — the single source of truth about your business, built so that
every AI tool you use builds in YOUR voice, for YOUR offer, using YOUR system. Set it up once. It
works everywhere.

---

## What's inside

```
README.md          ← you are here. How to set this up.
CLAUDE.md          The map. Tells Claude where everything lives and how each folder is used. Short on purpose.
CONTEXT.md         The index. Your business at a glance — what's locked, what's next — one line per fact.
                   Claude reads it first every session and keeps it current.

Reference/         Your five Foundation documents — the truth everything reads from.
                   Plus brand-kit/ — your ONE installed Brand Kit (the look every asset uses).

Client Engine/     Three folders — Offer Matrix, Money Magnet, Client Flywheel — and inside each,
                   one folder per asset. Every README says what goes in it. It grows as you do.

skills/            The delivered tools Claude runs from here — slides, funnel pages, your
                   Magic Formula™ graphic.
```

Every folder has a `README.md`. If you ever wonder where something goes, open the README of the
folder you think it belongs in.

## How your workspace remembers

Three layers, each with one job, so nothing is written twice and no single file ever gets heavy:

1. **`CONTEXT.md` — the index.** Your business at a glance: one line per fact, what's built, what's
   next, how you like to work. Claude reads it first every session. It stays short.
2. **`NOTES.md` — the memory beside each asset.** Every asset folder gets one the first time Claude
   saves there: the decisions and why, what you turned down, what's still open, a line per session.
   Claude reads it only when it's working on that asset — so the memory grows with every build, but
   your sessions never start by reading all of it.
3. **The asset file itself.** The finished thing, with its version history at the top.

You don't maintain any of this. Claude writes it as you build. You just get an AI that already knows.

## Where the builders are

The builder prompts — the guided interviews that build each document and asset — are **not** in this
folder. They live in **Coach Launch Academy™**, your Training Portal, where they're kept up to date.
When Claude says it's time to build something, download that builder from the portal, paste it into
the chat, and answer one question at a time. Claude saves the result into the right folder here.

That way your folders never go stale when a builder improves.

## The order you build in

1. **Reference first** (about an hour for all five):
   Business Brand Profile → Visual Style Guide (and install your Brand Kit) → Brand Voice
   → Products & Pricing → Competitive Landscape
2. **Then your Client Engine™**, pillar by pillar — **Offer Matrix** (Steps 1 to 3) builds your
   offer, **Money Magnet** (4 to 6) makes the money, **Client Flywheel** (7 to 9) brings the
   traffic. Each asset folder's README tells you what it needs first.

One rule to remember: **one file per asset.** You update the same file over time — never a "-v2" or
"-FINAL." Claude handles the versioning for you.

---

## Set it up in Claude (pick one)

### Option A — Claude Code / Cowork (recommended — Claude can save files for you)

1. Unzip this folder somewhere easy to find (your Documents folder is perfect).
2. Open Claude and point it at the unzipped folder.
3. Start a new chat and type exactly this:

   > "I just set up my $100K Day AI Workspace. Read the CLAUDE.md file in this folder and walk me
   > through the setup."

Claude reads the map, checks your Reference docs, and starts building with you — one step at a
time. When a builder finishes, Claude writes the file straight into the right folder, adds the
decisions to that folder's `NOTES.md`, and updates `CONTEXT.md`.

### Option B — Claude Projects (claude.ai)

1. Go to claude.ai and create a new Project.
2. Open `CLAUDE.md` in any text editor, copy ALL of it, and paste it in as the Project's instructions.
3. Upload every other file from this folder into the Project.
4. Start a new chat and type exactly this:

   > "I just set up my $100K Day AI Workspace. Use the instructions and walk me through the setup."

Claude outputs each finished document in the chat — and the folder's `NOTES.md` and the updated
`CONTEXT.md` with it. You copy each one, paste it over the matching file, and re-upload it to the
Project.

---

## Your Brand Kit — one look, installed once

Your look isn't a list of colours you try to remember. It's a **Brand Kit** — one real file that
every slide, page, ad and post reads from. You pick one of six in your Visual Style Guide, save its
file into `Reference/brand-kit/tokens/`, and never pick a colour again. One Kit installed at a time;
you can change it later, but you replace it — never keep two. `Reference/brand-kit/README.md` has
the how-to.

---

## The full guide

The complete walkthrough — the why behind it and the step-by-step — lives in Coach Launch Academy™:
**https://portal.coachlaunch.com**
